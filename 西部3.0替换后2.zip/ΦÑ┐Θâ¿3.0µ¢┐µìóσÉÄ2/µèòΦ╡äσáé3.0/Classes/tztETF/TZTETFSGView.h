//
//  TZTETFSGView.h
//  tztMobileApp_XCSC_iPad
//
//  Created by 在琦中 on 13-10-30.
//
//

#import "tztETFCrashRGView.h"

@interface TZTETFSGView : tztETFCrashRGView

@end
