
/**
 *    @author yinjp
 *
 *    @brief  盘口
 */
#import <tztHqBase/tztHqBase.h>

@interface tztHandicapView : tztHqBaseView

@end
