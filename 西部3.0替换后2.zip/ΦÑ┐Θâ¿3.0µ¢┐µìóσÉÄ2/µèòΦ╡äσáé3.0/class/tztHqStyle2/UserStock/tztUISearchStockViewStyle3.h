//
//  tztUISearchStockViewStyle3.h
//  tztMobileApp_ZSSC
//
//  Created by King on 15-3-14.
//  Copyright (c) 2015年 ZZTZT. All rights reserved.
//

#import <tztHqBase/tztHqBase.h>

@interface tztUISearchStockViewStyle3 : tztHqBaseView
{
}

-(void)RequestStock:(NSString*)strCode;
@end
