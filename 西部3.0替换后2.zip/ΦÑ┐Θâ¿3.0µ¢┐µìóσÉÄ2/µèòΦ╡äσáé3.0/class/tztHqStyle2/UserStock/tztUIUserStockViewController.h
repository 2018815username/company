//
//  tztUIUserStockViewController.h
//  tztMobileApp_GJUserStock
//
//  Created by King on 14-9-22.
//
//
#import "tztGJBaseViewController.h"
@interface tztUIUserStockViewController : tztGJBaseViewController

@end
