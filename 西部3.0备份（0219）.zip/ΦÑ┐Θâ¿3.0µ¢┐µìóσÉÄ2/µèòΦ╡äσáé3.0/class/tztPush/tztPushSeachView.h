//
//  tztPushSeachView.h
//  tztMobileApp_HTSC
//
//  Created by King on 14-3-7.
//
//

#import "tztTradeSearchView.h"

@interface tztPushSeachView : tztTradeSearchView

@end
