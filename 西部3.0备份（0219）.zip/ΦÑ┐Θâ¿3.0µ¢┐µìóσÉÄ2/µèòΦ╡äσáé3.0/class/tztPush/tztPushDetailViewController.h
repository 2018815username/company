//
//  tztPushDetailViewController.h
//  tztMobileApp_HTSC
//
//  Created by King on 14-3-6.
//
//

#import "tztWebViewController.h"

@interface tztPushDetailViewController : tztWebViewController

@end
