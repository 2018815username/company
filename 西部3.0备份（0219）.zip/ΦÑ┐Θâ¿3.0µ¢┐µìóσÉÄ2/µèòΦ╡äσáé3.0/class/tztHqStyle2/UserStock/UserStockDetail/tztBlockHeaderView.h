//
//  tztBlockHeaderView.h
//  tztMobileApp_ZSSC
//
//  Created by King on 15-3-17.
//  Copyright (c) 2015年 ZZTZT. All rights reserved.
//

#import <tztHqBase/tztHqBase.h>

@interface tztBlockHeaderView : tztHqBaseView

@end
