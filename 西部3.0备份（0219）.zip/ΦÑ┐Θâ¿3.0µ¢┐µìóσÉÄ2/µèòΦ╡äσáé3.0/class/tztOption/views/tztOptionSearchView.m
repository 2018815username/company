
#import "tztOptionSearchView.h"

@implementation tztOptionSearchView

//增加特殊处理字段
-(void)AddSearchInfo:(NSMutableDictionary *)pDict
{
    
}



@end
