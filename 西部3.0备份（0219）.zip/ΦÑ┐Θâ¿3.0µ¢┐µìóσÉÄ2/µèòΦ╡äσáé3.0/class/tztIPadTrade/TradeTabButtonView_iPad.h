//
//  TradeTabButtonView_iPad.h
//  tztMobileApp_HTSC
//
//  Created by 在琦中 on 13-8-21.
//
//

#import <UIKit/UIKit.h>

@interface TradeTabButtonView_iPad : UIView

@property(nonatomic,retain) UIButton *btnTabButton;
@property(nonatomic,retain) UIButton *btnClose;
@property(nonatomic,assign) BOOL isSelect;
@property(nonatomic,retain) NSString *strTabName;

@end
