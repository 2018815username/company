//
//  tztStockReportView.h
//  tztMobileApp_HTSC
//
//  Created by King on 14-9-26.
//
//

#import <UIKit/UIKit.h>

@interface tztStockReportView : UIView

-(void)onSetViewRequest:(BOOL)bRequest;

-(void)OnRequestData;
@end
