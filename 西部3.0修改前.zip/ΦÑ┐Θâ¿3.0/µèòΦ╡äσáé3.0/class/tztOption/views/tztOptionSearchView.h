

#import "tztTradeSearchView.h"
/**
 *    @author yinjp
 *
 *    @brief  期权查询基类
 */
@interface tztOptionSearchView : tztTradeSearchView

@end
