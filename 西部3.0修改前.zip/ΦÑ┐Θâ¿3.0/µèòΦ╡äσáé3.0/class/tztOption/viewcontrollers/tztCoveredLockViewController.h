
#import "TZTUIBaseViewController.h"

/**
 *    @author yinjp
 *
 *    @brief  备兑券解锁 锁定 显示vc
 */
@interface tztCoveredLockViewController : TZTUIBaseViewController

@property(nonatomic,retain)NSString* CurStockCode;
@end
