
#import "TZTUIBaseViewController.h"

/**
 *    @author yinjp
 *
 *    @brief  期权查询显示vc
 */
@interface tztOptionSearchViewController : TZTUIBaseViewController


@property(nonatomic,retain)NSString*    nsBeginDate;
@property(nonatomic,retain)NSString*    nsEndDate;
@end
