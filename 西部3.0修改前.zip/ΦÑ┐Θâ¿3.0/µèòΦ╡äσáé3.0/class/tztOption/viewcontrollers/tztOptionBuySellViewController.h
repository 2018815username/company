
#import "TZTUIBaseViewController.h"

/**
 *    @author yinjp
 *
 *    @brief  期权委托 买入开平仓，卖出开平仓 备兑开平仓显示vc
 */
@interface tztOptionBuySellViewController : TZTUIBaseViewController

@property(nonatomic,retain)NSString *CurStockCode;
@end
