//
//  TZTHXCalcCommDigestHash.m
//  tztAjaxApp
//
//  Created by 在琦中 on 14-3-13.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import <CommonCrypto/CommonDigest.h>
#import "TZTHXCalcCommDigestHash.h"

@implementation TZTHXCalcCommDigestHash

FILEMD5HASH_EXTERN CFStringRef StringCommDigestHashCreate(const char* hashString,
                                                          HXCommDigestType commDigestType)
{
    CFStringRef result = NULL;
    if (hashString == NULL || strlen(hashString) < 1)
    {
        return result;
    }
    
    // Compute the hash digest. use the max length
    size_t szHashLen = CC_MD5_DIGEST_LENGTH;
    unsigned char digest[CC_SHA512_DIGEST_LENGTH];
    
    memset(digest, 0x00, CC_SHA512_DIGEST_LENGTH);
    
    switch (commDigestType) {
        default:
        case HXCommDigestMD5:
            szHashLen = CC_MD5_DIGEST_LENGTH;
            CC_MD5(hashString, strlen(hashString), digest);
            break;
        case HXCommDigestSHA1:
            szHashLen = CC_SHA1_DIGEST_LENGTH;
            CC_SHA1(hashString, strlen(hashString), digest);
            break;
        case HXCommDigestSHA256:
            szHashLen = CC_SHA256_DIGEST_LENGTH;
            CC_SHA256(hashString, strlen(hashString), digest);
            break;
        case HXCommDigestSHA224:
            szHashLen = CC_SHA224_DIGEST_LENGTH;
            CC_SHA224(hashString, strlen(hashString), digest);
            break;
        case HXCommDigestSHA512:
            szHashLen = CC_SHA512_DIGEST_LENGTH;
            CC_SHA512(hashString, strlen(hashString), digest);
            break;
        case HXCommDigestSHA384:
            szHashLen = CC_SHA384_DIGEST_LENGTH;
            CC_SHA384(hashString, strlen(hashString), digest);
            break;
    }
    
    // Compute the string result
    char hash[2 * szHashLen + 1];
    for (size_t i = 0; i < szHashLen; ++i)
    {
        snprintf(hash + (2 * i), 3, "%02x", (int)(digest[i]));
    }
    
    result = CFStringCreateWithCString(kCFAllocatorDefault,
                                       (const char *)hash,
                                       kCFStringEncodingUTF8);
    
    return result;
}

+(NSString*) HXCalcStringCommHash:(NSString*) nsHashString
                         hashType:(HXCommDigestType) hashType
{
    NSString* nsReturn = NULL;
    if (nsHashString == NULL || nsHashString.length < 1)
    {
        return nsReturn;
    }
    
    CFStringRef executableHash =
    StringCommDigestHashCreate([nsHashString UTF8String],
                               hashType);
    
    if (executableHash)
    {
        nsReturn = [NSString stringWithString:(NSString*)executableHash];
        
        CFRelease(executableHash);
    }
    
    return nsReturn;
}

@end
