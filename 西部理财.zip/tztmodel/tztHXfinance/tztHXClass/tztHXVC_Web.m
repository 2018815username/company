//
//  tztHXVC_Web.m
//  tztmodel
//
//  Created by yangares on 14-9-10.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztHXVC_Web.h"
#import "UPayViewController.h"
#import "TZTCerInfo.h"

@interface tztHXVC_Web ()

@end

@implementation tztHXVC_Web

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)OnAjaxMsg:(int)nAction withParams:(NSString*)strParams
{
    NSMutableDictionary* pDict = nil;
    if(strParams && [strParams length] > 0)
    {
        pDict = (NSMutableDictionary*)[strParams tztNSMutableDictionarySeparatedByString:@"&&" decodeurl:TRUE];
    }
    switch (nAction) {
        case TZT_MENU_UPayControl: // 10070 调用银联支付控件
        {
#ifdef TZTUPay
            if (pDict == NULL)
                return;
            UPayViewController *pVC = [[UPayViewController alloc] init];
            pVC.tztDelegate = g_navigationController.topViewController;
            pVC.uPayDic = (NSMutableDictionary*)pDict;
            g_bChangeNav = FALSE;
            [g_navigationController pushViewController:pVC animated:UseAnimated];
            [pVC release];
            return;
#else
            tztAfxMessageBox(@"暂不支持银联支付功能!");
#endif
        }
            break;
        case TZT_MENU_CreateP10:
        {
            
#if TARGET_IPHONE_SIMULATOR
            return;
#else
            if (!g_pCer) {
                [TZTCerInfo shareCer];
            }
            g_pCer.dataDic = pDict;
            g_pCer.tztDelegate = g_navigationController.topViewController;
            [[TZTCerInfo shareCer] createP10];
#endif
            return;
        }
            break;
        case TZT_MENU_RequestCER:
        {
            
#if TARGET_IPHONE_SIMULATOR
            return;
#else
            if (pDict == NULL)
                return;
            if (!g_pCer) {
                [TZTCerInfo shareCer];
            }
            g_pCer.dataDic = pDict;
            [[TZTCerInfo shareCer] send];
#endif
            return;
        }
            break;
    }
    [super OnAjaxMsg:nAction withParams:strParams];
}

@end
