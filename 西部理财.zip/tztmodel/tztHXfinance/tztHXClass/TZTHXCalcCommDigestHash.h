//
//  TZTHXCalcCommDigestHash.h
//  tztAjaxApp
//
//  Created by 在琦中 on 14-3-13.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum HXCommDigestType{
    HXCommDigestMD5 = 0,
    HXCommDigestSHA1,
    HXCommDigestSHA256,
    HXCommDigestSHA224,
    HXCommDigestSHA512,
    HXCommDigestSHA384,
}HXCommDigestType;


#ifndef FILEMD5HASH_H
#define FILEMD5HASH_H

//---------------------------------------------------------
// Includes
//---------------------------------------------------------

// Core Foundation
#include <CoreFoundation/CoreFoundation.h>

// General imports for Objective-C
#ifdef __OBJC__
#if TARGET_OS_IPHONE
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#elif TARGET_OS_MAC
#import <Cocoa/Cocoa.h>
#endif
#endif


//---------------------------------------------------------
// Macros
//---------------------------------------------------------

// Extern
#if defined(__cplusplus)
#define FILEMD5HASH_EXTERN extern "C"
#else
#define FILEMD5HASH_EXTERN extern
#endif

//---------------------------------------------------------
// Constant declaration
//---------------------------------------------------------

// In bytes
#define FileHashDefaultChunkSizeForReadingData 4096


//---------------------------------------------------------
// Function declaration
//---------------------------------------------------------

//typedef short int HXCommDigestType;

FILEMD5HASH_EXTERN CFStringRef FileCommDigestHashCreateWithPath(CFStringRef filePath,
                                                                HXCommDigestType commDigestType,
                                                                size_t chunkSizeForReadingData);

FILEMD5HASH_EXTERN CFStringRef StringCommDigestHashCreate(const char* hashString,
                                                          HXCommDigestType commDigestType);

#endif

@interface TZTHXCalcCommDigestHash : NSObject

+(NSString*) HXCalcStringCommHash:(NSString*) nsHashString
                         hashType:(HXCommDigestType) hashType;

@end

