//
//  TZTCerInfo.m
//  tztAjaxApp
//
//  Created by 在琦中 on 14-2-28.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import <CommonCrypto/CommonDigest.h>
#import <zlib.h>
#import "TZTHXCalcCommDigestHash.h"
#import "TZTCerInfo.h"
#import "TKCertLib.h"
#import "TBXML.h"

TZTCerInfo *g_pCer;

@implementation TZTCerInfo

@synthesize pkcs10, strCertSN, dataDic;

+(TZTCerInfo*)shareCer
{
    if (g_pCer == NULL)
    {
        g_pCer = NewObject(TZTCerInfo);
        [g_pCer tztMainInit];
    }
    return g_pCer;
}

- (id)init
{
    self = [super init];
    if(self)
    {
        [[tztMoblieStockComm getShareInstance] addObj:self];
    }
    return self;
}

- (void)tztMainInit
{
//    pkcs10 = [NSMutableString string];
}

- (void)createP10
{
#if defined(__GNUC__) && !TARGET_IPHONE_SIMULATOR && ( defined(__APPLE_CPP__) || defined(__APPLE_CC__) || defined(__MACOS_CLASSIC__) )
    // 第一次需要加载License
    if (self.pkcs10 == NULL || self.pkcs10.length < 1)
    {
        //Test
#ifdef DEUBG
        [TKCertLib loadLicense:@"5FC35BF40FF544B01AFCFCB61CE52BAF7B6B2BACC45AEF1C4B288D2C63D34B2823950A3A73DF6B841C8B969F4F3221B853FCC9024842DB24"];
#else
        //Product
        [TKCertLib loadLicense:@"5FC35BF40FF544B06A37D74727D9F9E31FA9072A980B09BB0AEA90F30AA401626508561E62B713E31317A7C98504A269"];
#endif
//        [TKCertLib loadLicense:@"5FC35BF40FF544B01AFCFCB61CE52BAF7B6B2BACC45AEF1C4B288D2C63D34B2823950A3A73DF6B841C8B969F4F3221B853FCC9024842DB24"];
    }
    // 每次都重新请求
    NSMutableString *p10 = [NSMutableString string];
    int ret =[[TKCertLib share] createPKCS10:p10 pwd:@"123456"];
    if (ret != -1)
    {
        NSString* newP10 = [p10 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        NSLog(@"Remove \\r \\n::\r\n%@", newP10);
        newP10 = [newP10 stringByReplacingOccurrencesOfString:@"\r" withString:@""];
        NSLog(@"Remove \\r \\n::\r\n%@", newP10);
        
        self.pkcs10 = [[NSMutableString stringWithString:newP10] retain];
        
        [self send];
    }
#endif
}

/*请求数据，流水号等，这些需要放到外面去请求，由外部请求成功后传递进来
 ，此处固定数据，仅做测试*/
- (void)send
{
    NSString* strAction     = @"25002";
    
    NSString *sendString = [self getCertificateApplyReq];
    
    if (sendString.length == 0) {
        return;
    }
    
    NSMutableDictionary *pDict = NewObject(NSMutableDictionary);
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [pDict setTztValue:strReqno forKey:@"Reqno"];
    
    [pDict setTztValue:@"3" forKey:@"ZLib"];
    [pDict setTztValue:@"3" forKey:@"MobileType"];
    [pDict setTztValue:@"" forKey:@"CheckKEY"];
    
    [pDict setTztValue:sendString forKey:@"grid"];
    
    [[tztMoblieStockComm getShareInstance] onSendDataAction:strAction withDictValue:pDict];
    
    DelObject(pDict);
}

-(NSString*) getCertificateApplyReq
{
    if (self.pkcs10.length == 0) {
        return nil;
    }
    
    NSString *reqXMLData = @"";
//    if (![self isValidAccountInfo])
//    {
//        return reqXMLData;
//    }
    
    NSMutableString *strXML = [[[NSMutableString alloc] init] autorelease];
    
    [strXML appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>"];
    [strXML appendString:@"\r<extinfo>"];
    
    [strXML appendFormat:@"\r<func_id>%@</func_id>", @"501307"];
    [strXML appendFormat:@"\r<user_id>%@</user_id>", [self.dataDic tztObjectForKey:@"user_id"]];
    [strXML appendFormat:@"\r<pkcs10>%@</pkcs10>", self.pkcs10];
    [strXML appendString:@"\r</extinfo>"];
    
    reqXMLData = strXML;
    
    return reqXMLData;
}

-(NSString*) getSignedRiskProtocolReq:(NSString*)nsInfo
{
    NSString *reqXMLData = @"";
#if defined(__GNUC__) && !TARGET_IPHONE_SIMULATOR && ( defined(__APPLE_CPP__) || defined(__APPLE_CC__) || defined(__MACOS_CLASSIC__) )
//    if (![self isValidAccountInfo])
//    {
//        return reqXMLData;
//    }
    
    @try
    {
        //NSString* nsBaseInfo = [GTMBase64 stringByEncodingData:[nsInfo dataUsingEncoding:NSASCIIStringEncoding]];
        NSString* nsBaseInfo = [TZTHXCalcCommDigestHash HXCalcStringCommHash:nsInfo
                                                                 hashType:HXCommDigestMD5];
        
        NSString* signedText =  [[TKCertLib share] sign:nsBaseInfo signType:1];
        
        NSMutableString *strXML = [[[NSMutableString alloc] init] autorelease];
        
        [strXML appendString:@"<?xml version=\"1.0\" encoding=\"utf-8\"?>"];
        [strXML appendString:@"\r<extinfo>"];
        
        [strXML appendFormat:@"\r<func_id>%@</func_id>", /*OTCSignedRiskProtocol*/@"501311"];
        [strXML appendFormat:@"\r<plain_text>%@</plain_text>", nsBaseInfo];
        [strXML appendFormat:@"\r<signed_text>%@</signed_text>", signedText];
        //[strXML appendFormat:@"\r\n<x509cert>%@</x509cert>", self.openAccountInfo.x509Cert];
        [strXML appendFormat:@"\r<need_cert>%@</need_cert>", @"true"];
        [strXML appendString:@"\r</extinfo>"];
        
        reqXMLData = strXML;
    }
    @catch (NSException *exception) {
        reqXMLData = @"";
        NSLog(@"GetSignedRiskProtocolReq::****%@", exception.description);
    }
    @finally {
        // NULL
    }
#endif
    return reqXMLData;
}

- (void)sendSign
{
    NSString* strAction     = @"25002";
    NSString *sendString = [self getSignedRiskProtocolReq:@"Test"];
    
    NSMutableDictionary *pDict = NewObject(NSMutableDictionary);
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [pDict setTztValue:strReqno forKey:@"Reqno"];
    
    [pDict setTztValue:@"3" forKey:@"ZLib"];
    [pDict setTztValue:@"3" forKey:@"MobileType"];
    [pDict setTztValue:@"" forKey:@"CheckKEY"];
    
    [pDict setTztValue:sendString forKey:@"grid"];
    
    [[tztMoblieStockComm getShareInstance] onSendDataAction:strAction withDictValue:pDict];
    
    DelObject(pDict);
}

-(UInt32)OnCommNotify:(UInt32)wParam lParam_:(UInt32)lParam
{
    tztNewMSParse *pParse = (tztNewMSParse*)wParam;
    if (pParse == NULL)
        return 0;
    if (![pParse IsIphoneKey:(long)self reqno:_ntztReqno])
        return 0;
    
    TZTLogInfo(@"接收数据：%@", [pParse GetJsonData]);
    
    /*此部分代码也应该和发送对应，放到外面处理数据，数据接收成功，解析完成后调用支付功能*/
    /*由于调用的是25002转发功能，不需要处理我们自己的errorNo，而是要解析出Grid中的errorno字段作为成功与否的判断标示*/
    //    if ([pParse GetErrorNo] < 0)
    //    {
    //        NSString* strErrMsg = [pParse GetErrorMessage];
    //
    //        tztAfxMessageTitle(strErrMsg, @"登录提示");
    //        return 0;
    //    }
    
    /*接收成功示例数据：
     ACTION = 25002;
     ERRORNO = 25002;
     GRID0 =     (
     "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
     "<extinfo>",
     "  <func_id>501302</func_id>",
     "  <errorno>0</errorno>",
     "  <errormsg></errormsg>",
     "  <row>",
     "    <transstat>000</transstat>",
     "    <merordertime>20140226225334</merordertime>",
     "    <respmsg>\U4e0b\U5355\U6210\U529f</respmsg>",
     "    <mersign>98A6CC0F5733D477D5129C20979E868522A3A8910EE796D2B97CBF917A67A5EBB2701FA80366BB44082EFE9C9C8C1DFDA5CB63060721AF500C0598C338E99007A7F1F39B7F572EE8ED3A28FBA70392CA17D214BEF9FAF1602A934AEFAC95179A956DEFACA0A5BB353CB6D6E838726BB90849EDAD60C33B5A438AD772CAB69BFA</mersign>",
     "    <merchantid>201401039900001</merchantid>",
     "    <orderkey>2014022600004152</orderkey>",
     "    <merorderid>20140226225334194</merorderid>",
     "  </row>",
     "</extinfo>"
     );
     IPHONEKEY = 208452832;
     REQNO = "208452832=1=0=0=0=53614.283";
     */
    /*首先要解析转发的25002功能号*/
    if ([pParse IsAction:@"25002"])
    {
        //获取grid数据，返回的grid应该是一个xml格式的字符串
        NSString* strGrid = [pParse GetByName:@"Grid"];
        //格式化成xml格式
        TBXML *xml = [[TBXML alloc] initWithXMLString:strGrid];
        //获得根节点（此处根据返回的数据，应该是extinfo对应的节点）
        TBXMLElement *root = [xml rootXMLElement];
        //errorno节点位于root下，属于他的子节点
        TBXMLElement *name = [TBXML childElementNamed:@"errcode" parentElement:root];
        NSString *strErrorno = [TBXML textForElement:name];
        int nError = 0;
        if (ISNSStringValid(strErrorno))
            nError = [strErrorno intValue];
        //上面获取到处理的错误号
        
        //类似获取功能号
        name = [TBXML childElementNamed:@"func_id" parentElement:root];
        NSString* func_id = [TBXML textForElement:name];// valueOfAttributeNamed:@"func_id" forElement:root];
        
        //根据功能号判断处理
        if ([func_id intValue] == 501307)
        {
            if (nError == 0)//根据文档，错误码为0 是标示处理成功
            {
                //取root下的row子节点，以下的数据都是在row子节点下获取的
                TBXMLElement *row = [TBXML childElementNamed:@"row" parentElement:root];
                name = [TBXML childElementNamed:@"p7cert" parentElement:row];
                NSString* x509cert = [TBXML textForElement:name];//valueOfAttributeNamed:@"merchantid" forElement:root];
                self.strCertSN = x509cert;
#if defined(__GNUC__) && !TARGET_IPHONE_SIMULATOR && ( defined(__APPLE_CPP__) || defined(__APPLE_CC__) || defined(__MACOS_CLASSIC__) )
                [[TKCertLib share] importCert:x509cert];
#endif
//                NSString *ret1 =[[TKCertLib share] sign:@"thinkive1000" target:nil signType:1];
//                NSLog(@"----------ret-----------\n%@",ret1);
//                [self sendSign];
                
                NSString *strUrl = [self.dataDic tztObjectForKey:@"urltrue"];
                if (strUrl && strUrl.length > 0)
                {
                    strUrl = [strUrl tztdecodeURLString];
                    //不要这样跳转
                    /*
                     NSString* str = [NSString stringWithFormat:@"10061/?url=%@&&fullscreen=1&&secondType=9", strUrl] ;
                     [TZTUIBaseVCMsg OnMsg:ID_MENU_ACTION wParam:(UInt32)str lParam:0];
                     */
                    NSString* str = [tztlocalHTTPServer getLocalHttpUrl:strUrl];//跳转到原来的界面打开，否则页面的返回存在问题
                    if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(setWebURL:)])
                    {
                        [_tztDelegate setWebURL:str];
                    }
                }
                else
                {
                    strUrl = [strUrl tztdecodeURLString];
                    strUrl = [self.dataDic tztObjectForKey:@"jsfuntrue"];
                    if (strUrl && strUrl.length > 0)
                    {
                        if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(tztStringByEvaluatingJavaScriptFromString:)])
                        {
                            [_tztDelegate tztStringByEvaluatingJavaScriptFromString:strUrl];
                        }
                    }
                }
            }
            else
            {
                TBXMLElement *name = [TBXML childElementNamed:@"errmsg" parentElement:root];
                NSString *strError = [TBXML textForElement:name];
                if (strError.length>0) {
                    tztAfxMessageBox(strError);
                }
                NSString *strUrl = [self.dataDic tztObjectForKey:@"urlfalse"];
                if (strUrl && strUrl.length > 0)
                {
                    //不要这样跳转
                    /*
                     NSString* str = [NSString stringWithFormat:@"10061/?url=%@&&fullscreen=1&&secondType=9", strUrl] ;
                     [TZTUIBaseVCMsg OnMsg:ID_MENU_ACTION wParam:(UInt32)str lParam:0];
                     */
                    strUrl = [strUrl tztdecodeURLString];
                    NSString* str = [tztlocalHTTPServer getLocalHttpUrl:strUrl];//跳转到原来的界面打开，否则页面的返回存在问题
                    if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(setWebURL:)])
                    {
                        [_tztDelegate setWebURL:str];
                    }
                    
                }
                else
                {
                    strUrl = [self.dataDic tztObjectForKey:@"jsfunfalse"];
                    if (strUrl && strUrl.length > 0)
                    {
                        strUrl = [strUrl tztdecodeURLString];
                        if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(tztStringByEvaluatingJavaScriptFromString:)])
                        {
                            [_tztDelegate tztStringByEvaluatingJavaScriptFromString:strUrl];
                        }
                    }
                }
            }
            
            
        }
        //根据功能号判断处理
        else if ([func_id intValue] == 501311)
        {
            if (nError == 0)//根据文档，错误码为0 是标示处理成功
            {
                //取root下的row子节点，以下的数据都是在row子节点下获取的
                TBXMLElement *row = [TBXML childElementNamed:@"row" parentElement:root];
                name = [TBXML childElementNamed:@"x509cert" parentElement:row];

            }
            else
            {
                TBXMLElement *name = [TBXML childElementNamed:@"errmsg" parentElement:root];
                NSString *strError = [TBXML textForElement:name];
                tztAfxMessageBox(strError);
                //                [g_navigationController popViewControllerAnimated:YES];
            }
            
            
        }
    }
    
    return 1;
}

@end

@implementation tztHTTPData (tztkhInfosec)

//根据dict字典，对各个key所对应的value单独进行签名，并存放到字典中返回
-(NSDictionary*)tztHttpGetSignatureData:(NSMutableDictionary*)dict
{
    NSArray * ayKey = [dict allKeys];
    NSMutableDictionary * pDict = NewObjectAutoD(NSMutableDictionary);
#if defined(__GNUC__) && !TARGET_IPHONE_SIMULATOR && ( defined(__APPLE_CPP__) || defined(__APPLE_CC__) || defined(__MACOS_CLASSIC__) )
    // Modify by dsw 2014.09.01 增加异常检测
    @try
    {
        for (int i = 0; i < [ayKey count]; i++)
        {
            NSString * StrKey = [ayKey objectAtIndex:i];
            if (StrKey && [StrKey length] > 0)
            {
                NSString * SignaData = [dict objectForKey:StrKey];
                if (SignaData && [SignaData length] > 0)
                {
                    NSString* strSign = [[TKCertLib share] sign:SignaData signType:TK_SIGN_TYPE_ATTACH];;
                    if (strSign && [strSign length] > 0)
                    {
                        [pDict setTztObject:strSign forKey:StrKey];
                    }
                }
            }
        }
    }
    @catch(NSException* e)
    {
        NSLog(@"黑呵呵哈哈哈：：%@", e);
        [pDict removeAllObjects];
    }
#endif
    return pDict;
}

-(NSDictionary *)tztSignatureData:(NSString*)strData
{
    if (g_pCer == nil)
    {
        [TZTCerInfo shareCer];
    }
    
    NSMutableData *data = [NSMutableData data];
    [data appendData:[strData dataUsingEncoding:(NSUTF8StringEncoding)]];
    
    
    
    NSString* strbase64 =[data tztbase64EncodedString];
    if (strbase64 == NULL || strbase64.length <= 0)
    {
        return NULL;
    }
    NSString* strSign = @"";
#if defined(__GNUC__) && !TARGET_IPHONE_SIMULATOR && ( defined(__APPLE_CPP__) || defined(__APPLE_CC__) || defined(__MACOS_CLASSIC__) )
    NSString* nsBaseInfo = [TZTHXCalcCommDigestHash HXCalcStringCommHash:strData
                                                                hashType:HXCommDigestMD5];
    
    strSign =  [[TKCertLib share] sign:nsBaseInfo signType:TK_SIGN_TYPE_ATTACH];
    if(strSign == NULL || strSign.length <= 0)
    {
        //        dispatch_async (dispatch_get_main_queue(), ^
        //                        {
        //                            tztAfxMessageBox(@"签名失败!");
        //                        });
        return NULL;
    }
    
#endif
    NSMutableDictionary* pDict = NewObject(NSMutableDictionary);
    [pDict setTztValue:strSign forKey:tztIphoneSignature];
    
    /*
     原文做base64编码
     tztIphoneOriginal
     */
    [pDict setTztValue:strbase64 forKey:tztIphoneOriginal];
    
    return (NSDictionary*)[pDict autorelease];
}

-(id)tztReplaceData:(NSMutableDictionary*)pDict
{
    if (pDict == NULL)
        return 0;
    
    NSArray *ayKey = [pDict allKeys];
    
    for (int i = 0; i < [ayKey count]; i++)
    {
        NSString* nsKey = [ayKey objectAtIndex:i];
        if ([[nsKey lowercaseString] isEqualToString:@"tztfiledata"])//需要替换文件数据
        {
            NSString* nsValue = [pDict tztObjectForKey:nsKey];
            NSArray *ay = [nsValue componentsSeparatedByString:@"|"];
            if (ay == NULL || [ay count] <= 0)
                return 0;
            
            NSString* nsSubKey = [ay objectAtIndex:0];
            
            //文件路径，需要读取文件数据
            NSString* nsSubValue = [ay objectAtIndex:1];
            nsSubValue = [nsSubValue tztHttpfilepath];
            
            NSData* data = [NSData dataWithContentsOfFile:nsSubValue];
            
            NSString* strbase64 = [data tztbase64EncodedString];
            //            strbase64 = [strbase64 stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            //            NSData * baseData = [strbase64 dataUsingEncoding:NSUTF8StringEncoding];
            
            [pDict setTztObject:strbase64 forKey:nsSubKey];
            [pDict removeObjectForKey:nsKey];
            
            uLong value = 0;
            value = crc32(value, (const Bytef*)data.bytes, [data length]);
            NSString *ContactID = [NSString stringWithFormat:@"%lu",value];
            
            [pDict setTztObject:[NSString stringWithFormat:@"%d",[data length]] forKey:@"Volume"];
            [pDict setTztObject:@"1" forKey:@"StartPos"];
            [pDict setTztObject:ContactID forKey:@"ContactID"];
            [pDict setTztObject:[NSString stringWithFormat:@"%d",[data length]] forKey:@"MaxCount"];
        }
    }
    
    return 0;
}

- (NSString *)getlocalOtherValue:(NSString*)strKey withJyLoginInfo:(id)logininfo
{
    NSString* strValue = nil;
    if ([strKey caseInsensitiveCompare:@"x509cert"] == NSOrderedSame)
    {
        strValue = [TZTCerInfo shareCer].strCertSN;
    }
    return strValue;
}

@end

//@implementation TZTUIMessageBox(tztPrivate)
//
//-(NSMutableDictionary*)tztMsgBoxSetProperties:(TZTUIMessageBox*)msgBox
//{
//    NSMutableDictionary *pDict = NewObjectAutoD(NSMutableDictionary);
//    [pDict setTztObject:@"235,235,235,0.95" forKey:tztMsgBoxBackColor];
//    [pDict setTztObject:@"1-A.png" forKey:tztMsgBoxBtnOKImg];
//    [pDict setTztObject:@"28,149,238" forKey:tztMsgBoxBtnOKTitleColor];
//    [pDict setTztObject:@"1" forKey:tztMsgBoxBtnCancelImg];
//    [pDict setTztObject:@"28,149,238" forKey:tztMsgBoxBtnCancelTitleColor];
//    [pDict setTztObject:@"center" forKey:tztMsgBoxTitleAlignment];
//    [pDict setTztObject:@"top" forKey:tztMsgBoxSepLinePos];
//    
//    msgBox.m_TitleFont = tztUIBaseViewTextBoldFont(19.0);
//    msgBox.m_nType = TZTBoxTypeButtonBoth;
//    msgBox.m_nsTitle = @"随便填，你管不着";
//    
//    return pDict;
//}
//
//@end
