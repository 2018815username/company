//
//  TZTCerInfo.h
//  tztAjaxApp
//
//  Created by 在琦中 on 14-2-28.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TZTCerInfo : NSObject <tztSocketDataDelegate>
{
    UInt32 _ntztReqno;
    id     _tztDelegate;
}

@property (nonatomic,retain) NSString* strCertSN;
@property (nonatomic,retain) NSMutableString* pkcs10;
@property (nonatomic, retain)NSDictionary *dataDic;
@property (nonatomic, assign)id     tztDelegate;

+(TZTCerInfo*)shareCer;
- (void)createP10;
- (void)send;


@end

extern TZTCerInfo *g_pCer;

@interface tztHTTPData (tztkhInfosec)
-(NSDictionary *)tztSignatureData:(NSString*)strData;
//根据dict字典，对各个key所对应的value单独进行签名，并存放到字典中返回
-(NSDictionary*)tztHttpGetSignatureData:(NSMutableDictionary*)dict;
-(id)tztReplaceData:(NSMutableDictionary*)pDict;
@end