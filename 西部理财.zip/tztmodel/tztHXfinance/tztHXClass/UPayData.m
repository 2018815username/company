//
//  UPayData.m
//  tztAjaxApp
//
//  Created by 在琦中 on 14-2-27.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import "UPayData.h"

@implementation UPayData

@synthesize uPayDic = _uPayDic;

- (id)init
{
    if (self = [super init])
    {
        _uPayDic = NewObject(NSMutableDictionary);
        [[tztMoblieStockComm getShareInstance] addObj:self];
    }
    return self;
}

-(void)dealloc
{
    DelObject(_uPayDic);
    [[tztMoblieStockComm getShareInstance] removeObj:self];
    [super dealloc];
}

/*请求数据，流水号等，这些需要放到外面去请求，由外部请求成功后传递进来
 ，此处固定数据，仅做测试*/
- (void)send
{
    NSString* strAction     = @"25002";
    NSString* strFunc_Id    = @"501302";
    NSString* strCustName   = @"何闵";
    NSString* strId_No      = @"511081198207300015";
    NSString* strUser_Id    = @"194";
    NSString* strIdType     = @"01";//
    NSString* strBankCode   = @"6227003811740456744";
    NSString* strEmail      = @"123@123.com";
    NSString* strVersion    = @"20040616";
    NSString* strMobileNo   = @"13588888888";
    
    NSString *sendString = [NSString stringWithFormat:@"<\?xml version=\"1.0\" encoding=\"utf-8\"\?>\r\
                            <extinfo>\r\
                            <func_id>%@</func_id>\r\
                            <user_id>%@</user_id>\r\
                            <mobileno>%@</mobileno>\r\
                            <custname>%@</custname>\r\
                            <bankcode>%@</bankcode>\r\
                            <idno>%@</idno>\r\
                            <idtype>%@</idtype>\r\
                            <email>%@</email>\r\
                            <version>%@</version>\r\
                            </extinfo>", strFunc_Id, strUser_Id, strMobileNo, strCustName, strBankCode, strId_No, strIdType, strEmail, strVersion];
    
    NSMutableDictionary *pDict = NewObject(NSMutableDictionary);
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [pDict setTztValue:strReqno forKey:@"Reqno"];
    
    [pDict setTztValue:@"3" forKey:@"ZLib"];
    [pDict setTztValue:@"3" forKey:@"MobileType"];
    [pDict setTztValue:@"" forKey:@"CheckKEY"];
    
    [pDict setTztValue:sendString forKey:@"grid"];
    
    [[tztMoblieStockComm getShareInstance] onSendDataAction:strAction withDictValue:pDict];
    
    DelObject(pDict);
}

- (NSUInteger)OnCommNotify:(NSUInteger)wParam lParam_:(NSUInteger)lParam
{
    tztNewMSParse *pParse = (tztNewMSParse*)wParam;
    if (pParse == NULL)
        return 0;
    if (![pParse IsIphoneKey:(long)self reqno:_ntztReqno])
        return 0;
    
    TZTLogInfo(@"接收数据：%@", [pParse GetJsonData]);
    
    /*此部分代码也应该和发送对应，放到外面处理数据，数据接收成功，解析完成后调用支付功能*/
    /*由于调用的是25002转发功能，不需要处理我们自己的errorNo，而是要解析出Grid中的errorno字段作为成功与否的判断标示*/
    if ([pParse GetErrorNo] < 0)
    {
        NSString* strErrMsg = [pParse GetErrorMessage];

        tztAfxMessageTitle(strErrMsg, @"登录提示");
        return 0;
    }
    
    /*接收成功示例数据：
     ACTION = 25002;
     ERRORNO = 25002;
     GRID0 =     (
     "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
     "<extinfo>",
     "  <func_id>501302</func_id>",
     "  <errorno>0</errorno>",
     "  <errormsg></errormsg>",
     "  <row>",
     "    <transstat>000</transstat>",
     "    <merordertime>20140226225334</merordertime>",
     "    <respmsg>\U4e0b\U5355\U6210\U529f</respmsg>",
     "    <mersign>98A6CC0F5733D477D5129C20979E868522A3A8910EE796D2B97CBF917A67A5EBB2701FA80366BB44082EFE9C9C8C1DFDA5CB63060721AF500C0598C338E99007A7F1F39B7F572EE8ED3A28FBA70392CA17D214BEF9FAF1602A934AEFAC95179A956DEFACA0A5BB353CB6D6E838726BB90849EDAD60C33B5A438AD772CAB69BFA</mersign>",
     "    <merchantid>201401039900001</merchantid>",
     "    <orderkey>2014022600004152</orderkey>",
     "    <merorderid>20140226225334194</merorderid>",
     "  </row>",
     "</extinfo>"
     );
     IPHONEKEY = 208452832;
     REQNO = "208452832=1=0=0=0=53614.283";
     */
    /*首先要解析转发的25002功能号*/
    if ([pParse IsAction:@"25002"])
    {
        //获取grid数据，返回的grid应该是一个xml格式的字符串
        NSString* strGrid = [pParse GetByNameUnicode:@"Grid"];
        //格式化成xml格式
        TBXML *xml = [[TBXML alloc] initWithXMLString:strGrid];
        //获得根节点（此处根据返回的数据，应该是extinfo对应的节点）
        TBXMLElement *root = [xml rootXMLElement];
        //errorno节点位于root下，属于他的子节点
        TBXMLElement *name = [TBXML childElementNamed:@"errcode" parentElement:root];
        NSString *strErrorno = [TBXML textForElement:name];
        int nError = 0;
        if (ISNSStringValid(strErrorno))
            nError = [strErrorno intValue];
        //上面获取到处理的错误号
        
        //类似获取功能号
        name = [TBXML childElementNamed:@"func_id" parentElement:root];
        NSString* func_id = [TBXML textForElement:name];// valueOfAttributeNamed:@"func_id" forElement:root];
        
        //根据功能号判断处理
        if ([func_id intValue] == 501302)
        {
            //取root下的row子节点，以下的数据都是在row子节点下获取的
            TBXMLElement *row = [TBXML childElementNamed:@"row" parentElement:root];
            //获取商户号
            name = [TBXML childElementNamed:@"merchantid" parentElement:row];
            NSString* merchantid = [TBXML textForElement:name];//valueOfAttributeNamed:@"merchantid" forElement:root];
            //获取CP特征码
            name = [TBXML childElementNamed:@"orderkey" parentElement:row];
            NSString* orderkey = [TBXML textForElement:name];//valueOfAttributeNamed:@"orderkey" forElement:root];
            //获取订单号
            name = [TBXML childElementNamed:@"merorderid" parentElement:row];
            NSString* merorderid = [TBXML textForElement:name];//valueOfAttributeNamed:@"merorderid" forElement:root];
            //获取订单时间
            name = [TBXML childElementNamed:@"merordertime" parentElement:row];
            NSString* merordertime = [TBXML textForElement:name];//valueOfAttributeNamed:@"merordertime" forElement:root];
            //获取响应码，返回000标示下单成功，其他的都是失败
            name = [TBXML childElementNamed:@"transstat" parentElement:row];
            NSString* transstat = [TBXML textForElement:name];//valueOfAttributeNamed:@"transstat" forElement:root];
            //签名(文档中写的是sign字段，实际返回的是mersign)
            name = [TBXML childElementNamed:@"mersign" parentElement:row];
            NSString* mersign = [TBXML textForElement:name];
            
            if ([transstat isEqualToString:@"000"]) {
                if (nError == 0)//根据文档，错误码为0 是标示处理成功
                {
                    //把获取到的数据丢给支付控件处理即可。另外丢进去的数据最好进行下有效性判断
                    [_uPayDic setObject:merchantid forKey:@"merchantid"];
                    [_uPayDic setObject:orderkey forKey:@"orderkey"];
                    [_uPayDic setObject:merorderid forKey:@"merorderid"];
                    [_uPayDic setObject:merordertime forKey:@"merordertime"];
                    [_uPayDic setObject:mersign forKey:@"mersign"];
//                    [TZTUIBaseVCMsg OnMsg:933333 wParam:(UInt32)self.uPayDic lParam:0];
                }
                else
                {
                    tztAfxMessageTitle([pParse GetByName:@"errmsg"], @"登录提示");
                    [g_navigationController popViewControllerAnimated:YES];
                }
            }
            else {
                name = [TBXML childElementNamed:@"respMsg" parentElement:row];
                tztAfxMessageBox([TBXML textForElement:name]);
                [g_navigationController popViewControllerAnimated:YES];
            }
        }
    }
    return 1;
}


@end
