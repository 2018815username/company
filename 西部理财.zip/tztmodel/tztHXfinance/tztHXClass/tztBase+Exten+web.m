//
//  NSObject+tztBase_Exten.m
//  tztMobileApp
//
//  Created by yangares on 13-6-18.
//
//

#import "tztBase+Exten+web.h"
#import <tztMobileBase/tztNSLocation.h>
#import "sys/utsname.h"

@implementation tztMoblieStockComm (tztBaseExten)
- (void)addTztCommHead:(NSMutableDictionary*)sendValue
{
    [tztMoblieStockComm AddCommHead:sendValue];
}

- (void)addTztCommJYHead:(NSMutableDictionary*)sendValue
{
    [tztMoblieStockComm AddCommJYHead:sendValue];
}

+ (void)AddCommHead:(NSMutableDictionary*)sendValue
{
    NSString* strlogMobile = [sendValue tztObjectForKey:@"MobileCode"];
    if (!ISNSStringValid(strlogMobile))
    {
        strlogMobile = [tztKeyChain load:tztLogMobile];
        if (strlogMobile == NULL || strlogMobile.length <= 0 || !validateMobile(strlogMobile)){
            strlogMobile = [tztKeyChain load:tztUniqueID];
        }
        if (strlogMobile == NULL || strlogMobile.length <= 0 || !validateMobile(strlogMobile)){
            strlogMobile = [tztOpenUDID value];
        }
    }
    [sendValue setTztObject:strlogMobile forKey:@"MobileCode"];
    
    
    NSString* strTfrom = @"";
#ifdef tzt_TFrom
    strTfrom = tzt_TFrom;
#else
#if TARGET_OS_IPHONE
    strTfrom  = (IS_TZTIPAD ? @"ipad":@"iphone");
#else
    strTfrom = @"macos";
#endif
#endif
    [sendValue setTztObject:strTfrom forKey:@"TFrom"];
}

//目前仅仅设置token和reqno
+ (void)AddCommJYHead:(NSMutableDictionary*)sendValue
{
    int nAccountType = TZTAccountPTType;
    NSString* strAccountType = [sendValue tztObjectForKey:tztTokenType];
    if (strAccountType && [strAccountType length] > 0)
        nAccountType = [strAccountType intValue];
    [tztMoblieStockComm AddCommJYHead:sendValue withTokenType:nAccountType];
}


+(NSString*)deviceString
{
    struct utsname systemInfo;
    uname(&systemInfo);
    NSString *deviceString = [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
    
    if ([deviceString isEqualToString:@"iPhone1,1"])    return @"iPhone1G";
    if ([deviceString isEqualToString:@"iPhone1,2"])    return @"iPhone3G";
    if ([deviceString isEqualToString:@"iPhone2,1"])    return @"iPhone3GS";
    if ([deviceString isEqualToString:@"iPhone3,1"])    return @"iPhone4";
    if ([deviceString isEqualToString:@"iPhone4,1"])    return @"iPhone4S";
    if ([deviceString isEqualToString:@"iPhone5,2"])    return @"iPhone5";
    if ([deviceString isEqualToString:@"iPhone3,2"])    return @"VerizoniPhone4";
    if ([deviceString isEqualToString:@"iPod1,1"])      return @"iPodTouch1G";
    if ([deviceString isEqualToString:@"iPod2,1"])      return @"iPodTouch2G";
    if ([deviceString isEqualToString:@"iPod3,1"])      return @"iPodTouch3G";
    if ([deviceString isEqualToString:@"iPod4,1"])      return @"iPodTouch4G";
    if ([deviceString isEqualToString:@"iPad1,1"])      return @"iPad1";
    if ([deviceString isEqualToString:@"iPad2,1"])      return @"iPad2(WiFi)";
    if ([deviceString isEqualToString:@"iPad2,2"])      return @"iPad2(GSM)";
    if ([deviceString isEqualToString:@"iPad2,3"])      return @"iPad2(CDMA)";
    if ([deviceString isEqualToString:@"i386"])         return @"Simulator";
    if ([deviceString isEqualToString:@"x86_64"])       return @"Simulator";
    return deviceString;
}

+ (void)AddCommJYHead:(NSMutableDictionary*)sendValue withTokenType:(int)nTokenType
{
    NSString* strImei = [tztOpenUDID value];
    if (validateMobile(strImei))
    {
        [sendValue setTztValue:strImei forKey:@"IMEI"];
        NSString* strMobile = [sendValue tztValueForKey:@"MobileCode"];
        if(strMobile == nil || [strMobile length] <= 0)
        {
            [sendValue setTztObject:strImei forKey:@"MobileCode"];
        }
    }
    
    UIDevice *device = [UIDevice currentDevice];
    NSString* strModel = device.model;
    NSString* strVersion = device.systemVersion;
    NSString* strMobileKind = @"";
    
    strModel = [tztMoblieStockComm deviceString];
    
    if (strModel)
        strMobileKind = [NSString stringWithFormat:@"%@", strModel];
    if (strVersion)
        strMobileKind = [NSString stringWithFormat:@"%@-%@",strMobileKind, strVersion];
    
    [sendValue setTztValue:strMobileKind forKey:@"mobilekind"];
    
    /*第三方调用时，外部接口可自定义替换，添加*/
    [[tztHTTPData getShareInstance] tztperformSelector:@"AddJYCommHeaderEx:withTokenType:" withObject:sendValue withObject:[NSString stringWithFormat:@"%d", nTokenType]];
    
}

+(void)AddClientInfo:(NSMutableDictionary*)sendValue
{

}

@end


/****** reqxml ********************************************************
 mobilecode     手机号码
 checkkey       行情登录密码
 from
 cfrom
 tfrom
 devicemodel    设备型号
 upversion      升级版本号
 localversion	内部版本号
 account        账号
 accounttype	账号类型
 password       客户账号密码(华泰电子合同使用)
 fund_account	资金账号(华泰电子合同)
 yybcode        营业部号
 token          交易token
 rzrqtoken      融资融券token
 qhtoken        期货token
 usercode       华西，补齐地址使用
 khbranch       华西，补齐地址使用
 oskey          华西，补齐地址使用
 maxcount       请求一页记录条数
 stockcode      股票代码
 stockname      股票名称
 selfstocklist	本地自选股列表
 
 Reqlinktype	 联网地址类型
 0行情链接，1交易链接
 2资讯链接，3均衡链接
 这个变量不需补齐，是要告诉客户端用哪个地址和端口请求数据,
 scrolltotop	值为1告诉WebView滑动到最顶端，用于翻页界面的功能
 
 ***************************************************************/

/****** reqlocal ************************************************
 username	华西，客户姓名
 lastnetaddr	华西，上次登录IP位置
 ***************************************************************/

@implementation tztHTTPData (tztBaseExten)
- (BOOL)isTztLoginOfType:(NSString*)strLoginType
{
    NSMutableDictionary *pDict = [[tztHTTPData getShareInstance] getMapValue];
    NSString* strEcif_id = [pDict tztObjectForKey:@"TOKENLOGIN"];
    NSString* strSession = [pDict tztObjectForKey:@"TIMELOGIN"];
    
    if (ISNSStringValid(strEcif_id) && ISNSStringValid(strSession))
    {
        return TRUE;
    }
    return FALSE;
//    
//    int nflag = 0;
//    if (strLoginType && [strLoginType intValue] == 1) {
//        nflag = 2;
//    }else {
//        nflag = 1;
//    }
//    NSString* strJyLoginFlag = [self getlocalValue:@"jyloginflag"];
//    if(strJyLoginFlag && ([strJyLoginFlag intValue] & nflag) == nflag){
//        return TRUE;
//    }
//    return FALSE;
}

- (void)clearTztLoginOfType:(NSString*)strLoginType
{
    NSMutableDictionary *pDict = [[tztHTTPData getShareInstance] getMapValue];
    [pDict setTztObject:@"" forKey:@"TOKENLOGIN"];
    [pDict setTztObject:@"" forKey:@"TIMELOGIN"];
//    
//    int nflag = 0;
//    if (strLoginType && [strLoginType intValue] == 1) {
//        nflag = 2;
//    }else {
//        nflag = 1;
//    }
//    NSString* strJyLoginFlag = [self getlocalValue:@"jyloginflag"];
//    if(strJyLoginFlag && ([strJyLoginFlag intValue] & nflag) == nflag){
//        int nLoginFlag = [strJyLoginFlag intValue];
//        nLoginFlag &= ~nflag;
//        [self setlocalValue:@"jyloginflag" withValue:[NSString stringWithFormat:@"%d",nLoginFlag]];
//    }
}

//下列字段过滤
- (BOOL)isHttpFilterKey:(NSString*)strKey
{
    if(strKey == NULL || [strKey length] <= 0)
        return TRUE;
    if ([strKey caseInsensitiveCompare:tztIphoneREQUSTPARAM] == NSOrderedSame
        || [strKey caseInsensitiveCompare:tztIphoneREQUSTURL] == NSOrderedSame
        || [strKey caseInsensitiveCompare:tztIphoneREQUSTCRC] == NSOrderedSame
        || [strKey caseInsensitiveCompare:tztIphoneReSend] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"MOBILECODE"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"FROM"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"CFROM"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"TFROM"] == NSOrderedSame
//        || [strKey caseInsensitiveCompare:@"VERSION"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"REQNO"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"ZLIB"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"MOBILETYPE"] == NSOrderedSame
        || [strKey caseInsensitiveCompare:@"TOKEN"] == NSOrderedSame
        )
    {
        return TRUE;
    }
    return FALSE;
}

- (id)getHTTPJYLoginInfo:(int)nTokenType;
{
    return nil;
}

- (BOOL) setlocalValueExten:(NSMutableDictionary*)dictValue
{
    return TRUE;
}

- (NSString *)getlocalValueExten:(NSString*)strKey withJyLoginInfo:(id)logininfo
{
    NSString* strValue = nil;
    /*第三方调用时，外部接口可自定义*/
    if ([tztHTTPData getShareInstance] && [[tztHTTPData getShareInstance] respondsToSelector:@selector(getlocalOtherValue:withJyLoginInfo:)])
    {
        strValue = [[tztHTTPData getShareInstance] tztperformSelector:@"getlocalOtherValue:withJyLoginInfo:" withObject:strKey withObject:logininfo];
    }
    if (strValue != nil)
        return strValue;
    /*end*/
    if ([strKey caseInsensitiveCompare:@"mobilecode"] == NSOrderedSame )
    {
        if([self tztperformSelector:@"isTztLoginOfType:" withObject:@"0"])
            strValue = [tztKeyChain load:tztLogMobile];
    }
    else if ([strKey caseInsensitiveCompare:@"tztuniqueid"] == NSOrderedSame)
    {
        strValue = [tztKeyChain load:tztUniqueID];
    }
    else if ([strKey caseInsensitiveCompare:@"tztnettype"] == NSOrderedSame)
    {   
        TZTNetworkStatus status = [g_tztreachability currentReachabilityStatus];
        if (status == TZTReachableViaWiFi)
        {
            strValue = @"wifi";
        }
        else
        {
            if (g_nConnectType == TZTConnectHttp)
            {
                strValue = @"wap";
            }
            else
            {
                strValue = @"net";
            }
        }
    }
    else if([strKey caseInsensitiveCompare:@"surfMethod"] == NSOrderedSame)
    {   
        TZTNetworkStatus status = [g_tztreachability currentReachabilityStatus];
        strValue = @"unknown";
        if (status == TZTReachableViaWiFi)
        {
            strValue = @"wifi";
        }
        else if(status == TZTReachableViaWWAN)
        {
            strValue = @"3g";
        }
    }
    else if ( [strKey caseInsensitiveCompare:@"localversion"] == NSOrderedSame )
    {
        strValue = tzt_Inner_Version;
    }
    else if( [strKey caseInsensitiveCompare:@"tfrom"] == NSOrderedSame)
    {
#ifdef tzt_TFrom
        strValue = tzt_TFrom;
#else
#if TARGET_OS_IPHONE
        strValue  = (IS_TZTIPAD ? @"ipad":@"iphone");
#else
        strValue = @"mac";
#endif
#endif
    }
    else if ([strKey caseInsensitiveCompare:@"tztbadgenumber"] == NSOrderedSame)
    {
        strValue = [NSString stringWithFormat:@"%d", [UIApplication sharedApplication].applicationIconBadgeNumber];
    }
    if(strValue == nil)
        return nil;
    return [[[NSString alloc] initWithString:strValue] autorelease];
}
@end
