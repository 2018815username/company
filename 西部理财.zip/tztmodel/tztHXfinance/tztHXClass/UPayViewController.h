//
//  ViewController.h
//  UPPayDemo
//
//  Created by 在琦中 on 14-2-26.
//  Copyright (c) 2014年 D.B.Q. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "ChinaPay_iPhone_ViewController.h"
@protocol CPApiDelegate;
@interface UPayViewController : UIViewController </*ChinaPayIPhoneDelegate, */CPApiDelegate,tztSocketDataDelegate>
{
    UInt32 _ntztReqno;
//	ChinaPay_iPhone_ViewController *chinaPayVC;
    id     _tztDelegate;
}

@property (nonatomic, retain)NSMutableDictionary *uPayDic;
@property (nonatomic, assign)id     tztDelegate;

@end
