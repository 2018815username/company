//
//  ViewController.m
//  UPPayDemo
//
//  Created by 在琦中 on 14-2-26.
//  Copyright (c) 2014年 D.B.Q. All rights reserved.
//

#import "UPayViewController.h"
#import "CPApi.h"

@interface UPayViewController ()

@end

@implementation UPayViewController

@synthesize uPayDic = _uPayDic;

- (id)init
{
    if (self = [super init])
    {
        _uPayDic = NewObject(NSMutableDictionary);
        [[tztMoblieStockComm getShareInstance] addObj:self];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self callChinaPayPlugin];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)callChinaPayPlugin
{
    [self genXmlData];
//    //应该外部请求好，然后丢数据进来，直接就去执行genXmlData。需要根据流程优化
//	chinaPayVC = [[ChinaPay_iPhone_ViewController alloc] init];
//	chinaPayVC.delegate = self;
//    chinaPayVC.view.frame = self.view.bounds;
//    [self.view addSubview:chinaPayVC.view];
//    [chinaPayVC setXmlData:[self genXmlData]];
}

//响应中途关闭，或者支付成功后的返回响应
- (void)viewClose:(NSData *)data
{
    NSString *responseString = [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
    TZTLogInfo(@"%@", responseString);
    
    //解析数据，只有respCode=0000时，才认为是支付成功了
    TBXML *xml = [[TBXML alloc] initWithXMLString:responseString];
    //获得根节点（此处根据返回的数据，应该是extinfo对应的节点）
    TBXMLElement *root = [xml rootXMLElement];
    //errorno节点位于root下，属于他的子节点
//    TBXMLElement *name = [TBXML childElementNamed:@"respCode" parentElement:root];
    NSString* strRespCode = @"";
    if (root)
        strRespCode = [TBXML textForElement:root];
    
    //支付成功
    //测试环境，认为通过了
    if (strRespCode && strRespCode.length > 0 && [strRespCode isEqualToString:@"0000"])
    {
        [self send];
        
        return;
    }
    
    //关闭自身
    
    [g_navigationController popViewControllerAnimated:UseAnimated];
}

-(void)onResp:(CPBaseResp *)resp
{
    NSLog(@"响应码：%@   响应信息：%@", resp.respCode, resp.respMsg);
    //认证成功
    if (resp && resp.respCode.length > 0 && [resp.respCode caseInsensitiveCompare:@"0000"] == NSOrderedSame)
    {
        [self send];
        return;
    }
    else//失败，回到原来界面
    {
        [g_navigationController popViewControllerAnimated:UseAnimated];
    }
}


- (NSData *)genXmlData
{
    NSString *merchantId = [_uPayDic tztObjectForKey:@"merchantId"];
    NSString *merOrderId = [_uPayDic tztObjectForKey:@"merOrderId"];
    NSString *merOrderTime = [_uPayDic tztObjectForKey:@"merOrderTime"];
    NSString *orderKey = [_uPayDic tztObjectForKey:@"orderKey"];
    NSString *mersign = [_uPayDic tztObjectForKey:@"mersign"];
    NSString *strEnv = [_uPayDic tztObjectForKey:@"environment"];
    
    CPPayReq *req = [[CPPayReq alloc] init];
    if (strEnv && strEnv.length > 0)
    {
        req.userInfo = [NSDictionary dictionaryWithObject:strEnv forKey:@"environment"];   //环境参数，测试环境下需加此行，正式环境下无需此行。
    }
//    else
//    {
//        req.userInfo = [NSDictionary dictionaryWithObject:@"test" forKey:@"environment"];
//    }
	req.merchantId = merchantId;			//商户号
	req.merchantOrderId = merOrderId;		//商户订单号
	req.merchantOrderTime = merOrderTime;	//商户订单时间
	req.orderKey = orderKey;			//订单特征码
	req.sign = mersign;		//签名，见参数说明
//    [CPApi openPayPluginAtViewController:self withReq:req];
	[CPApi openPayPluginAtViewController:self withReq:req];
	[req release];
    return nil;
//    
//    
//    NSMutableString * strData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"];
//    [strData appendString:@"\r\n<CpPay application=\"LunchPay.Req\">"];
//    
//    [strData appendString:@"\r\n<merchantId>"];
//    if (merchantId.length > 0) {
//        [strData appendString:merchantId];
//    }
//    [strData appendString:@"</merchantId>"];
//    
//    [strData appendString:@"\r\n<merchantOrderId>"];
//    if (merOrderId.length > 0) {
//        [strData appendString:merOrderId];
//    }
//    [strData appendString:@"</merchantOrderId>"];
//    
//    [strData appendString:@"\r\n<merchantOrderTime>"];
//    if (merOrderTime.length > 0) {
//        [strData appendString:merOrderTime];
//    }
//    [strData appendString:@"</merchantOrderTime>"];
//    
//    [strData appendString:@"\r\n<orderKey>"];
//    if (orderKey.length > 0) {
//        [strData appendString:orderKey];
//    }
//    [strData appendString:@"</orderKey>"];
//    
//    [strData appendString:@"\r\n<sign>"];
//    if (mersign.length > 0) {
//        [strData appendString:mersign];
//    }
//    [strData appendString:@"</sign>"];
//    
//    [strData appendString:@"\r\n</CpPay>"];
//    NSData *data =  [strData dataUsingEncoding:NSUTF8StringEncoding];
//    return data;
}

/**/
- (NSData *)genXmlData:(NSString *)merchantId
      merchantOrderId_:(NSString *)merchantOrderId
    merchantOrderTime_:(NSString *)merchantOrderTime
             orderKey_:(NSString *)orderKey
                 sign_:(NSString *)sign
{
     NSMutableString * strData = [NSMutableString stringWithString:@"<?xml version=\"1.0\" encoding=\"UTF-8\" ?>"];
    [strData appendString:@"\r\n<CpPay application=\"LunchPay.Req\">"];
    
    [strData appendString:@"\r\n<env>TEST</env>"];
    
    [strData appendString:@"\r\n<merchantId>"];
    [strData appendString:merchantId];
    [strData appendString:@"</merchantId>"];
    
    [strData appendString:@"\r\n<merchantOrderId>"];
    [strData appendString:merchantOrderId];
    [strData appendString:@"</merchantOrderId>"];
    
    [strData appendString:@"\r\n<merchantOrderTime>"];
    [strData appendString:merchantOrderTime];
    [strData appendString:@"</merchantOrderTime>"];
    
    [strData appendString:@"\r\n<orderKey>"];
    [strData appendString:orderKey];
    [strData appendString:@"</orderKey>"];
    
    [strData appendString:@"\r\n<sign>"];
    [strData appendString:sign];
    [strData appendString:@"</sign>"];
    
    [strData appendString:@"\r\n</CpPay>"];
    
    NSLog(@"%@",strData);
    NSData *data =  [strData dataUsingEncoding:NSUTF8StringEncoding];
    return data;
    
}

/*请求数据，流水号等，这些需要放到外面去请求，由外部请求成功后传递进来
 ，此处固定数据，仅做测试*/
- (void)send
{
    NSString* strAction     = @"25002";
    NSString* strFunc_Id    = @"501308";
    NSString* strUser_Id    = [self.uPayDic tztObjectForKey:@"user_id"];
    
    
    NSString *sendString = [NSString stringWithFormat:@"<\?xml version=\"1.0\" encoding=\"utf-8\"\?><extinfo><func_id>%@</func_id><user_id>%@</user_id></extinfo>", strFunc_Id, strUser_Id];
    
    NSMutableDictionary *pDict = NewObject(NSMutableDictionary);
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [pDict setTztValue:strReqno forKey:@"Reqno"];
    
    [pDict setTztValue:@"3" forKey:@"ZLib"];
    [pDict setTztValue:@"3" forKey:@"MobileType"];
    [pDict setTztValue:@"" forKey:@"CheckKEY"];
    
    [pDict setTztValue:sendString forKey:@"grid"];
    
    [[tztMoblieStockComm getShareInstance] onSendDataAction:strAction withDictValue:pDict];
    
    DelObject(pDict);
}

- (NSUInteger)OnCommNotify:(NSUInteger)wParam lParam_:(NSUInteger)lParam
{
    tztNewMSParse *pParse = (tztNewMSParse*)wParam;
    if (pParse == NULL)
        return 0;
    if (![pParse IsIphoneKey:(long)self reqno:_ntztReqno])
        return 0;
    
    TZTLogInfo(@"接收数据：%@", [pParse GetJsonData]);

    /*此部分代码也应该和发送对应，放到外面处理数据，数据接收成功，解析完成后调用支付功能*/
    /*由于调用的是25002转发功能，不需要处理我们自己的errorNo，而是要解析出Grid中的errorno字段作为成功与否的判断标示*/
//    if ([pParse GetErrorNo] < 0)
//    {
//        NSString* strErrMsg = [pParse GetErrorMessage];
//        
//        tztAfxMessageTitle(strErrMsg, @"登录提示");
//        return 0;
//    }
    
    /*接收成功示例数据：
     ACTION = 25002;
     ERRORNO = 25002;
     GRID0 =     (
     "<?xml version=\"1.0\" encoding=\"UTF-8\"?>",
     "<extinfo>",
     "  <func_id>501302</func_id>",
     "  <errorno>0</errorno>",
     "  <errormsg></errormsg>",
     "  <row>",
     "    <transstat>000</transstat>",
     "    <merordertime>20140226225334</merordertime>",
     "    <respmsg>\U4e0b\U5355\U6210\U529f</respmsg>",
     "    <mersign>98A6CC0F5733D477D5129C20979E868522A3A8910EE796D2B97CBF917A67A5EBB2701FA80366BB44082EFE9C9C8C1DFDA5CB63060721AF500C0598C338E99007A7F1F39B7F572EE8ED3A28FBA70392CA17D214BEF9FAF1602A934AEFAC95179A956DEFACA0A5BB353CB6D6E838726BB90849EDAD60C33B5A438AD772CAB69BFA</mersign>",
     "    <merchantid>201401039900001</merchantid>",
     "    <orderkey>2014022600004152</orderkey>",
     "    <merorderid>20140226225334194</merorderid>",
     "  </row>",
     "</extinfo>"
     );
     IPHONEKEY = 208452832;
     REQNO = "208452832=1=0=0=0=53614.283";
     */
    /*首先要解析转发的25002功能号*/
    if ([pParse IsAction:@"25002"])
    {
        //获取grid数据，返回的grid应该是一个xml格式的字符串
        NSString* strGrid = [pParse GetByNameUnicode:@"Grid"];
        //格式化成xml格式
        TBXML *xml = [[TBXML alloc] initWithXMLString:strGrid];
        //获得根节点（此处根据返回的数据，应该是extinfo对应的节点）
        TBXMLElement *root = [xml rootXMLElement];
        //errorno节点位于root下，属于他的子节点
        TBXMLElement *name = [TBXML childElementNamed:@"errcode" parentElement:root];
        NSString *strErrorno = [TBXML textForElement:name];
        int nError = 0;
        if (ISNSStringValid(strErrorno))
            nError = [strErrorno intValue];
        //上面获取到处理的错误号
        
        //类似获取功能号
        name = [TBXML childElementNamed:@"func_id" parentElement:root];
        NSString* func_id = [TBXML textForElement:name];// valueOfAttributeNamed:@"func_id" forElement:root];
        
        //根据功能号判断处理
        if ([func_id intValue] == 501308)
        {
            //取root下的row子节点，以下的数据都是在row子节点下获取的
            TBXMLElement *row = [TBXML childElementNamed:@"row" parentElement:root];
            //错误代码
            name = [TBXML childElementNamed:@"transstat" parentElement:row];
            NSString* transstat = [TBXML textForElement:name];//valueOfAttributeNamed:@"merchantid" forElement:root];
            
            
            if (nError == 0)//根据文档，错误码为0 是标示处理成功
            {
                if ([transstat isEqualToString:@"1"]) {
                    //
                    [g_navigationController popViewControllerAnimated:NO];
                    NSString *strUrl = [self.uPayDic tztObjectForKey:@"url"];
                    NSString *strJs = [self.uPayDic tztObjectForKey:@"jsfuc"];
                    if (strUrl && strUrl.length > 0)
                    {
                        //不要这样跳转
                        /*
                        NSString* str = [NSString stringWithFormat:@"10061/?url=%@&&fullscreen=1&&secondType=9", strUrl] ;
                        [TZTUIBaseVCMsg OnMsg:ID_MENU_ACTION wParam:(UInt32)str lParam:0];
                         */
                        NSString* str = [tztlocalHTTPServer getLocalHttpUrl:strUrl];//跳转到原来的界面打开，否则页面的返回存在问题
                        if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(setWebURL:)])
                        {
                            [_tztDelegate setWebURL:str];
                        }
                        
                    }
                    else if (strJs && strJs.length > 0)
                    {
                        if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(tztStringByEvaluatingJavaScriptFromString:)])
                        {
                            [_tztDelegate tztStringByEvaluatingJavaScriptFromString:strJs];
                        }
                    }
//                    [g_navigationController popViewControllerAnimated:YES];
                }
                else
                {
                    //错误信息
                    tztAfxMessageBox(@"下单失败");
                    [g_navigationController popViewControllerAnimated:YES];
                }
            }
            else
            {
                tztAfxMessageTitle([pParse GetByName:@"errmsg"], @"登录提示");
                [g_navigationController popViewControllerAnimated:YES];
            }
            
            
        }
    }
    
    return 1;
}

@end
