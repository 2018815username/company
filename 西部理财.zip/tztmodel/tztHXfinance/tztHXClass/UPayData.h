//
//  UPayData.h
//  tztAjaxApp
//
//  Created by 在琦中 on 14-2-27.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UPayData : NSObject <tztSocketDataDelegate>
{
    UInt16                        _ntztReqno;
}

@property (nonatomic, retain)NSMutableDictionary *uPayDic;

/*请求数据，流水号等，这些需要放到外面去请求，由外部请求成功后传递进来
 ，此处固定数据，仅做测试*/
- (void)send;

@end
