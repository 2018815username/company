//
//  tztRegistViewController.m
//  tztAjaxApp
//
//  Created by King on 14-6-12.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import "tztRegistViewController.h"
#import "TZTUIMessageBox.h"
@interface tztRegistViewController ()<tztHTTPSendDataDelegate>
{
    UIView      *_pHeaderView;
    UILabel     *_pHeaderLabel;
    UIImageView *_pHeaderImageView;
    UIButton    *_pBtnRegist;
    UIImageView *_pImageView;
    UILabel     *_pTipsLabel;
    int _ntztReqno;
}
@end

@implementation tztRegistViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)dealloc
{
    [super dealloc];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setStatus:(BOOL)benabled
{
    _pMobileText.enabled = benabled;
    _pBtnLogin.enabled = benabled;
}

-(void)LoadLayoutView
{
    [super LoadLayoutView];
    [self setTitle:@"用户注册"];
    [_tztTitleView setTitleLeftType:@""];
    [self.view setBackgroundColor:[UIColor whiteColor]];
    CGRect rcFrame = self.view.frame;
    rcFrame.origin.x += 30;
    rcFrame.size.width -= 60;
    rcFrame.origin.y += 70 + _tztTitleView.frame.size.height;
    
    CGRect rcMobile = rcFrame;
    rcMobile.size.height = 40;
    if (_pMobileText == NULL)
    {
        _pMobileText = [[UITextField alloc] initWithFrame:rcMobile];
        _pMobileText.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pMobileText.leftViewMode = UITextFieldViewModeAlways;
        _pMobileText.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pMobileText.rightViewMode = UITextFieldViewModeAlways;
        _pMobileText.clearButtonMode = UITextFieldViewModeAlways;
        _pMobileText.background = [UIImage imageTztNamed:@"tztTradeUserTextBG@2x"];
        _pMobileText.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _pMobileText.placeholder = @"请输入手机号码";
        _pMobileText.keyboardType = UIKeyboardTypePhonePad;
        [self.view addSubview:_pMobileText];
        [_pMobileText release];
    }
    else
    {
        _pMobileText.frame = rcMobile;
    }
    
    CGRect rcForget = rcMobile;
    rcForget.origin.y += rcMobile.size.height + 15;
    rcForget.size.width = (rcMobile.size.width - 40);
    
    CGRect rcLogin = rcForget;
    rcLogin.origin.x += 20;
    if (_pBtnLogin == NULL)
    {
        _pBtnLogin = [UIButton buttonWithType:UIButtonTypeCustom];
        _pBtnLogin.frame = rcLogin;
        [_pBtnLogin addTarget:self
                       action:@selector(OnSysRegist)
             forControlEvents:UIControlEventTouchUpInside];
        [_pBtnLogin setBackgroundImage:[UIImage imageTztNamed:@"tztMsgBtnOk@2x.png"] forState:UIControlStateNormal];
        [_pBtnLogin setTztTitle:@"马上注册"];
        [self.view addSubview:_pBtnLogin];
    }
    else
    {
        _pBtnLogin.frame = rcLogin;
    }
    
    
    CGRect rcBack = self.view.frame;
    rcBack.origin.y += 20 + _tztTitleView.frame.size.height;
    rcBack.origin.x += 20;
    rcBack.size.width -= 40;
    rcBack.size.height = rcLogin.origin.y + rcLogin.size.height + 80 - rcFrame.origin.y;
    
    if (_pBackView == NULL)
    {
        _pBackView = [[UIView alloc] initWithFrame:rcBack];
        _pBackView.backgroundColor = [UIColor clearColor];
        _pBackView.layer.borderWidth = 1.0f;
        _pBackView.layer.borderColor = [UIColor colorWithTztRGBStr:@"227,227,227"].CGColor;
        [self.view addSubview:_pBackView];
        [self.view sendSubviewToBack:_pBackView];
        [_pBackView release];
    }
    else
    {
        _pBackView.frame = rcBack;
    }
    
    CGRect rc = rcBack;
    rc.size.height = 3;
    if (_pHeaderView == NULL)
    {
        _pHeaderView = [[UIView alloc] initWithFrame:rc];
        _pHeaderView.backgroundColor = [UIColor colorWithTztRGBStr:@"254,110,93"];
        [self.view addSubview:_pHeaderView];
        [_pHeaderView release];
    }
    else
    {
        _pHeaderView.frame = rc;
    }
    
    CGRect rcImageView = rcBack;
    rcImageView.origin.x += 5;
    rcImageView.origin.y += 5;
    rcImageView.size = CGSizeMake(40, 40);
    
    UIImage *pImage1 = [UIImage imageTztNamed:@"tztSysLoginIcon@2x"];
    if (pImage1 && pImage1.size.width > 0 && pImage1.size.height > 0)
    {
        rcImageView.origin.x += (rcImageView.size.width - pImage1.size.width) / 2;
        rcImageView.origin.y += (rcImageView.size.height - pImage1.size.height) / 2;
        rcImageView.size = pImage1.size;
    }
    
    if (_pHeaderImageView == NULL)
    {
        _pHeaderImageView = [[UIImageView alloc] initWithFrame:rcImageView];
        [_pHeaderImageView setImage:pImage1];
        [self.view addSubview:_pHeaderImageView];
        [_pHeaderImageView release];
    }
    else
    {
        _pHeaderImageView.frame = rcImageView;
    }
    
    CGRect rcLabel = rcBack;
    rcLabel.origin.x = rcImageView.origin.x + rcImageView.size.width + 10;
    rcLabel.size.width = (rcBack.size.width) / 2 - rcLabel.origin.x;
    rcLabel.origin.y = rcImageView.origin.y;
    rcLabel.size.height = rcImageView.size.height;
    if (_pHeaderLabel == NULL)
    {
        _pHeaderLabel = [[UILabel alloc] initWithFrame:rcLabel];
        _pHeaderLabel.text = @"用户注册";
        _pHeaderLabel.adjustsFontSizeToFitWidth = YES;
        _pHeaderLabel.textColor = [UIColor colorWithTztRGBStr:@"254,110,93"];
        [self.view addSubview:_pHeaderLabel];
        [_pHeaderLabel release];
    }
    else
    {
        _pHeaderLabel.frame = rcLabel;
    }
    
    CGRect rcTips = rcBack;
    rcTips.origin.y = rcBack.origin.y + rcBack.size.height + 10;
    rcTips.size.height = 40;
    if (_pTipsLabel == NULL)
    {
        _pTipsLabel = [[UILabel alloc] initWithFrame:rcTips];
        _pTipsLabel.font = tztUIBaseViewTextFont(12.0f);
        _pTipsLabel.text = @"提示：输入手机号，点\"马上注册\"，系统会将验证码以短信形式发送到您手机上。";
        _pTipsLabel.numberOfLines = 0;
        _pTipsLabel.textColor = [UIColor darkGrayColor];
        [self.view addSubview:_pTipsLabel];
        [_pTipsLabel release];
    }
    else
    {
        _pTipsLabel.frame = rcTips;
    }
}

-(void)OnSysRegist
{
    [_pMobileText resignFirstResponder];
    NSString *strMobile = _pMobileText.text;
    
    if (strMobile == NULL || strMobile.length < 1)
    {
        tztAfxMessageTitle(@"请输入手机号码!", @"注册提示");
        return;
    }
    [self setStatus:FALSE];
    [_pMobileText resignFirstResponder];
    [_pPasswordText resignFirstResponder];
    NSString* strSend = tztAppSysValueWithDefault(@"tztapp_sysregsend", @"action=206&mobilecode=($MobileCode)&CheckKEY=");
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($MobileCode)" withString:strMobile];
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($PassWord)" withString:@""];
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($UpVersion)" withString:@""];
    
    NSMutableDictionary *sendvalue = [strSend tztNSMutableDictionarySeparatedByString:@"&"];
    [sendvalue setTztObject:tztAppSysValueWithDefault(@"tztapp_sysregaction", @"206") forKey:@"Action"];
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [sendvalue setTztValue:strReqno forKey:@"Reqno"];
    
    tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
    sendHttpData.tztdelegate = self;
    [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
}

- (void)onSenddataError:(NSMutableDictionary*)sendData type:(int)nType
{
    [self setStatus:TRUE];
    tztAfxMessageTitle(@"发送请求失败，请重试!", @"注册提示");
}

- (NSUInteger)OnCommNotify:(NSUInteger)wParam lParam_:(NSUInteger)lParam
{
    tztNewMSParse *pParse = (tztNewMSParse*)wParam;
    if (pParse == NULL)
        return 0;
    [self setStatus:TRUE];
    if ([pParse GetErrorNo] < 0)
    {
        NSString* strErrMsg = [pParse GetErrorMessage];
        tztAfxMessageTitle(strErrMsg, @"注册提示");
        return 0;
    }
    tztAfxMessageBlock(@"验证码将以短信方式发送到您的手机上，请注意查收", @"注册提示", nil, TZTBoxTypeButtonOK, ^(NSInteger nIndex)
                       {
                           [tztKeyChain save:tztLogMobile data: _pMobileText.text];
                           [tztKeyChain save:tztLogPass data:@""];
                           [_tztDelegate tztperformSelector:@"setMobile:pass:" withObject:_pMobileText.text withObject:@""];
                           [g_navigationController popViewControllerAnimated:UseAnimated];
                       });
    return 0;
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_pMobileText resignFirstResponder];
    [_pPasswordText resignFirstResponder];
}
@end
