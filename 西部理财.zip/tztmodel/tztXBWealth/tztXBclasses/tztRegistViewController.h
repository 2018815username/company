/*
 注册界面
 
 */

#import "tztBaseVC.h"

@interface tztRegistViewController : tztBaseVC

@property(nonatomic,retain)id       tztDelegate;
@property(nonatomic,retain)UIView   *pBackView;
@property(nonatomic,retain)UITextField  *pMobileText;
@property(nonatomic,retain)UITextField  *pPasswordText;
@property(nonatomic,retain)UIButton     *pBtnForget;
@property(nonatomic,retain)UIButton     *pBtnLogin;
@end
