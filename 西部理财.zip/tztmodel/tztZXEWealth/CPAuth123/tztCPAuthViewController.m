//
//  tztCPAuthViewController.m
//  tztAjaxApp
//
//  Created by King on 14-6-6.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import "tztCPAuthViewController.h"
#import "CPApi.h"

@interface tztCPAuthViewController ()<CPApiDelegate>

@end

@implementation tztCPAuthViewController
@synthesize dictCPAuth = _dictCPAuth;
@synthesize tztDelegate = _tztDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImage* image = [UIImage imageTztNamed:tztScreenImage(@"Default.png")];
    self.view.backgroundColor = [UIColor colorWithPatternImage:image];
    [self callCPAuth];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)callReturnWithMsg:(NSString*)strMsg
{
    tztAfxMessageBlock(strMsg, nil, nil, TZTBoxTypeButtonOK, ^(int nIndex){
        [g_navigationController popViewControllerAnimated:NO];
        
    });
}

-(void)callCPAuth
{
    //首先要判断数据有效性
    if (self.dictCPAuth == NULL || self.dictCPAuth.count < 1)
    {
        [self callReturnWithMsg:@"认证数据传入有误，请重试!"];
        return;
    }
    
    //商户号（用户系统编号）
    NSString* nsMerchantId = [self.dictCPAuth tztObjectForKey:@"merchantId"];
    if (!ISNSStringValid(nsMerchantId))
    {
        [self callReturnWithMsg:@"商户号(用户系统编号)传入有误，请重试!"];
        return;
    }
    
    //特征码（签名）
    NSString* nsMerSign = [self.dictCPAuth tztObjectForKey:@"mersign"];
    if (!ISNSStringValid(nsMerSign))
    {
        [self callReturnWithMsg:@"特征码(签名)数据传入有误，请重试!"];
        return;
    }
    
    //银行卡号
    NSString* nsCardNo = [self.dictCPAuth tztObjectForKey:@"cardno"];
    if (!ISNSStringValid(nsCardNo))
    {
        [self callReturnWithMsg:@"银行卡号数据传入有误，请重试!"];
        return;
    }
    
    //身份证号
    NSString* nsCerNo = [self.dictCPAuth tztObjectForKey:@"cerno"];
    if (!ISNSStringValid(nsCerNo))
    {
        [self callReturnWithMsg:@"证件号码传入有误，请重试!"];
        return;
    }
    
    //姓名
    NSString* nsCerName = [self.dictCPAuth tztObjectForKey:@"cername"];
    if (!ISNSStringValid(nsCerName))
    {
        [self callReturnWithMsg:@"姓名传入有误，请重试！"];
        return;
    }
    
    //类型
    NSString* nsCerType = [self.dictCPAuth tztObjectForKey:@"certype"];
    if (!ISNSStringValid(nsCerType))
    {
        [self callReturnWithMsg:@"证书类型传入有误，请重试!"];
        return;
    }
    
    NSString* nsMobileCode = [self.dictCPAuth tztObjectForKey:@"mobileno"];
    
    /*
    idType=01
    cardId=420321199001203115
    fullName=杨远远
    mobileno=13282131370
    bankaccount=6228480321693476517
     */
    
//    <?xml version="1.0" encoding="UTF-8" ?><CpPay application="LunchPay.Req"><env>PRODUCT</env><appSysId>90042</appSysId><cardNo>4563511300111816400</cardNo><cerType>01</cerType><cerNo>342127198204287712</cerNo><cerName>庞继亮</cerName><cardMobile>13706507986</cardMobile><sign>46e152f8556a36410ee04f0b2663692e</sign></CpPay>
    
//    NSString *ss = @"90042456351130011181640001342127198204287712庞继亮137065079868T8fvnzhB8yVbxvj484ANgFcX3wTBUw8";
//    NSString* de = [tztHTTPServer MD5:ss];
    
    //判断
    NSString *str = [NSString stringWithFormat:@"%@%@%@%@%@%@%@",nsMerchantId,nsCardNo, nsCerType, nsCerNo,nsCerName,nsMobileCode,@"88888888"];
    
    NSString *MD5 = [tztHTTPServer MD5:str];
    NSLog(@"\r\n客户端MD5值：%@\r\n服务器MD5:%@", MD5, nsMerSign);
    
    NSString* strEnvironment = [self.dictCPAuth objectForKey:@"environment"];
    //发起签名处理：
    CPAuthReq *req = [[CPAuthReq alloc] init];
    if (strEnvironment.length > 0)
    {
        req.userInfo = [NSDictionary dictionaryWithObject:strEnvironment forKey:@"environment"];
    }
    //测试环境必须要发
//    req.userInfo = [NSDictionary dictionaryWithObject:@"test" forKey:@"environment"];
    req.appSysId = nsMerchantId;//商户号
    req.sign = nsMerSign;//特征码 md5后的数据
    req.cardNo = nsCardNo;//银行卡号
    req.cerName = nsCerName;            //用户名称
    req.cerType = nsCerType;            //类型，对应01＝身份证号
    req.cerNo = nsCerNo;//身份证号
    req.cardMobile = nsMobileCode;
    [CPApi openAuthPluginAtViewController:self withReq:req];
    [req release];
    
}

- (void)onResp:(CPBaseResp *)resp
{
    NSLog(@"响应码：%@   响应信息：%@", resp.respCode, resp.respMsg);
    //认证成功
    if (resp && resp.respCode.length > 0 && [resp.respCode caseInsensitiveCompare:@"0000"] == NSOrderedSame)
    {
        [g_navigationController popViewControllerAnimated:NO];
        NSString *strUrl = [self.dictCPAuth tztObjectForKey:@"url"];
        if (strUrl && strUrl.length > 0)
        {
            if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(setWebURL:)])
            {
                [_tztDelegate setWebURL:strUrl];
            }
        }
        NSString* strJS = [self.dictCPAuth tztObjectForKey:@"jsfuc"];
        if (strJS && strJS.length > 0)
        {
            if (_tztDelegate && [_tztDelegate respondsToSelector:@selector(OnMsgJSFun:)])
            {
                [_tztDelegate OnMsgJSFun:strJS];
            }
        }
    }
    else//失败，回到原来界面
    {
        [g_navigationController popViewControllerAnimated:UseAnimated];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
