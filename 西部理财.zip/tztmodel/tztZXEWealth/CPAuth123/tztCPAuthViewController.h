//
//  tztCPAuthViewController.h
//  tztAjaxApp
//
//  Created by King on 14-6-6.
//  Copyright (c) 2014年 zztzt. All rights reserved.
//

#import "tztBaseVC.h"

@interface tztCPAuthViewController : tztBaseVC

//
@property(nonatomic,retain)NSMutableDictionary *dictCPAuth;
@property(nonatomic,assign)id                   tztDelegate;

-(void)callCPAuth;
@end
