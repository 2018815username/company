//
//  tztZXVC_LoginWeb.h
//  tztmodel
//
//  Created by yangares on 14-9-9.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <tztWealthFramework/tztBaseVC_LoginWeb.h>

@interface tztZXVC_LoginWeb : tztBaseVC_LoginWeb
@end


