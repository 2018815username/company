//
//  tztZXVC_Web.h
//  tztmodel
//
//  Created by yangares on 14-9-10.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC_Web.h"

@interface tztZXVC_Web : tztBaseVC_Web

@end
