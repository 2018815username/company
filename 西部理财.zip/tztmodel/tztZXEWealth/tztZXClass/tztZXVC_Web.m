//
//  tztZXVC_Web.m
//  tztmodel
//
//  Created by yangares on 14-9-10.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztZXVC_Web.h"
#import "tztZXVC_LoginWeb.h"
#import "tztCPAuthViewController.h"
#import "tztAppInit.h"

@interface tztZXVC_Web ()

@end

@implementation tztZXVC_Web

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)tztWebViewCanGoBack:(tztHTTPWebView *)webView
{
    [super tztWebViewCanGoBack:webView];
    if (webView == _webView)
    {
        if(![webView canReturnBack]  && _tztTitleView && _webInfo)
        {
            int _nRightType = [_tztTitleView getTitleRightType];
            if(_nRightType == tztBtnUserIcon){
                [_tztTitleView setRightBtnText:[_webInfo tztObjectForKey:@"secondtext"]];
            }
        }
    }
    return NO;
}


- (void)OnAjaxMsg:(int)nAction withParams:(NSString*)strParams
{
    NSMutableDictionary* pDict = nil;
    if(strParams && [strParams length] > 0)
    {
        pDict = (NSMutableDictionary*)[strParams tztNSMutableDictionarySeparatedByString:@"&&" decodeurl:TRUE];
    }
    switch (nAction) {
        case MENU_SYS_UserLogout:
        {
            [self tztMsgBoxBlock:pDict block:^{
                NSMutableDictionary *pHttpData = [[tztHTTPData getShareInstance] getMapValue];
                NSString* strAccount = [pHttpData tztObjectForKey:@"CARDID"];
                
                NSString* strLoginType = [pDict tztValueForKey:@"logintype"];
                [[tztAppInit sharedtztAppInit] tztUniqueidLogout:strAccount branch:@""];
                [[tztHTTPData getShareInstance] tztperformSelector:@"clearTztLoginOfType:" withObject:strLoginType];
                
                //更多不跳转，其他都回到软件首页
                int nSelected = [tztAppInit sharedtztAppInit].mainTabBarVC.tztTabBarView.nSelected;
                if (nSelected == 0 || nSelected == 3)
                {
//                [[tztAppInit sharedtztAppInit] selectedTab:nSelected];
                }
                else
                {
                    [[tztAppInit sharedtztAppInit] onRootTab:0];
                }
                [self tztWebViewCanGoBack:_webView];
            }];
            return;
        }
            break;
        case TZT_MENU_UPayControl://调用银联认证
        {
            tztCPAuthViewController *vc = [[tztCPAuthViewController alloc] init];
            vc.dictCPAuth = (NSMutableDictionary*)pDict;
            vc.tztDelegate = g_navigationController.topViewController;
            [vc SetHidesBottomBarWhenPushed:YES];
            [g_navigationController pushViewController:vc animated:UseAnimated];
            [vc release];
            return;
            
        }
            break;
    }
    [super OnAjaxMsg:nAction withParams:strParams];
}

@end
