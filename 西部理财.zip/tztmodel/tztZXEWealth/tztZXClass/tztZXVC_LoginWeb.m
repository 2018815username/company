//
//  tztZXVC_LoginWeb.m
//  tztmodel
//
//  Created by yangares on 14-9-9.
//  Copyright (c) 2014年 yangares. All rights reserved.
//
#import "tztBase+Exten+web.h"
#import "tztZXVC_LoginWeb.h"
#import "tztAppInit.h"

@interface tztZXVC_LoginWeb ()

@end

@implementation tztZXVC_LoginWeb
- (void)OnLoginBack
{
    if(_tztbaseVC_web)
    {
        if([[tztHTTPData getShareInstance] isTztLoginOfType:@"1"]){
            NSString* strURL = [_loginWebInfo tztValueForKey:@"url"];
            if(strURL && [strURL length] > 0){
                [_tztbaseVC_web OnMsgURL:strURL];
            }else{
                NSString* strJS = [_loginWebInfo tztValueForKey:@"jsfuncname"];
                [_tztbaseVC_web OnMsgJSFun:strJS];
            }
        }else{
            //更多不跳转，其他都回到软件首页
            int nSelected = [tztAppInit sharedtztAppInit].mainTabBarVC.tztTabBarView.nSelected;
            if (nSelected == 0 || nSelected == 3)
            {
//                [[tztAppInit sharedtztAppInit] selectedTab:nSelected];
            }
            else
            {
                [[tztAppInit sharedtztAppInit] onRootTab:0];
            }
        }
        [_tztbaseVC_web tztWebViewCanGoBack:_tztbaseVC_web.webView];
    }
}
@end
