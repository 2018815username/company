//
//  tztSysInitData.m
//  tztmodel
//  系统初始化
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztSysInitData.h"

@interface tztSysInitData()
+ (void)onJHFinish;
@end
@implementation tztSysInitData

+ (void)tztUpdateBundle
{
    tztUpdateBundle(^(NSInteger nCount, NSInteger nPos) {
        TZTLogInfo(@"%ld-%ld",(long)nCount,(long)nPos);
    });
}

//均衡
+ (void)onJHAction:(void (^)(void))completion
{
    //发送均衡功能
    [[TZTServerListDeal getShareClass] onSendJHAction:^
     {
         [tztSysInitData onJHFinish];
         completion();
     }];
}
//均衡结束
+ (void)onJHFinish
{
    //初始化用户手机号
    [tztTechSetting getInstance];//加载配置
    //设置网络状态变化是的通知函数
    if(g_tztreachability == nil)
    {
        g_tztreachability = [[TZTReachability reachabilityWithHostName:@"www.baidu.com"] retain];
        [g_tztreachability startNotifer];
    }
    [tztMoblieStockComm freeAllInstanceSocket];
    [[tztMoblieStockComm getSharezxInstance] onInitGCDDataSocket];
    [[tztMoblieStockComm getShareInstance] onInitGCDDataSocket];
    //启动Http服务
    [tztlocalHTTPServer httpServerInit];
}

@end
