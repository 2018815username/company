//
//  tztSysInitVC.m
//  tztmodel
//
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztSysInitVC.h"

@interface tztSysInitVC ()
{
    UIImageView* _imageview;
    BOOL _animating;
}
@end

@implementation tztSysInitVC
@synthesize tztdelegate = _tztdelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.tztdelegate = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (_imageview == NULL) {
        _imageview = NewObject(UIImageView);
        _imageview.frame = tztScreenBounds();
        [_imageview setImage:[UIImage imageTztNamed:tztScreenImage(@"Default")]];
        [self.view addSubview:_imageview];
        Obj_RELEASE(_imageview);
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)showInit
{
    [tztSysInitVC sharedInit].view.frame = tztScreenBounds();
    [[self mainWindow] addSubview:[tztSysInitVC sharedInit].view];
//    _imageview.frame = tztScreenBounds();
    NSString* strUrl = tztAppSysValueWithDefault(@"tztapp_initimage", @"");
    //http://%@:7780/reqxml/?action=44203&type=102&version=%@
    if(strUrl && [strUrl length] > 0){
        NSString* strSize = [NSString stringWithFormat:@"tztscreensize=%@",tztScreenModeStrSize()];
        if([strUrl rangeOfString:@"?"].location != NSNotFound){
            strUrl = [NSString stringWithFormat:@"%@&%@",strUrl,strSize];
        }else{
            strUrl = [NSString stringWithFormat:@"%@?%@",strUrl,strSize];
        }
        [_imageview loadImageFromURL:strUrl completion:^{
            [self performSelector:@selector(finishInit) withObject:nil afterDelay:3.0f];
        }];
    }else{
//        [_imageview setImage:[UIImage imageTztNamed:tztScreenImage(@"Default")]];
        [self performSelector:@selector(finishInit) withObject:nil afterDelay:3.0f];
    }
}


- (void)finishInit
{
    if(_tztdelegate){
        [_tztdelegate appStart];
    }
    
	[[[tztSysInitVC sharedInit] view] removeFromSuperview];
    
    if(_tztdelegate){
        [_tztdelegate appShow];
    }
}

- (UIWindow *)mainWindow
{
    UIApplication *app = [UIApplication sharedApplication];
    if ([app.delegate respondsToSelector:@selector(window)])
    {
        return [app.delegate window];
    }
    else
    {
        return [app keyWindow];
    }
}

+ (void)show
{
	[[tztSysInitVC sharedInit] showInit];
}

+ (void)hide
{
	[[tztSysInitVC sharedInit] finishInit];
}

+ (tztSysInitVC *)sharedInit
{
    @synchronized(self)
    {
        static tztSysInitVC *sharedInit = nil;
        if (sharedInit == nil)
        {
            sharedInit = [[self alloc] init];
        }
        return sharedInit;
    }
}

@end
