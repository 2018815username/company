#import "tztGuideViewController.h"

@interface tztGuideViewController ()
{
    int _nPageCount;
}
@end

@implementation tztGuideViewController

@synthesize animating = _animating;
@synthesize pagecontroll = _pagecontroll;
@synthesize pageScroll = _pageScroll;
@synthesize tztdelegate = _tztdelegate;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.tztdelegate = nil;
        _nPageCount = 0;
    }
    return self;
}

- (void)showGuide
{
	if (!_animating && self.view.superview == nil)
	{
		[tztGuideViewController sharedGuide].view.frame = tztScreenBounds();
		[[self mainWindow] addSubview:[tztGuideViewController sharedGuide].view];
		_animating = YES;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.4];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(guideShown)];
		[tztGuideViewController sharedGuide].view.frame = tztScreenBounds();
		[UIView commitAnimations];
	}
    
    [[UIApplication sharedApplication] setStatusBarHidden:YES];
}

- (void)guideShown
{
	_animating = NO;
}

- (void)hideGuide
{
	if (!_animating && self.view.superview != nil)
	{
		_animating = YES;
		[UIView beginAnimations:nil context:nil];
		[UIView setAnimationDuration:0.4];
		[UIView setAnimationDelegate:self];
		[UIView setAnimationDidStopSelector:@selector(guideHidden)];
		[UIView commitAnimations];
	}
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO];
}

- (void)guideHidden
{
	_animating = NO;
	[[[tztGuideViewController sharedGuide] view] removeFromSuperview];
}

- (UIWindow *)mainWindow
{
    UIApplication *app = [UIApplication sharedApplication];
    if ([app.delegate respondsToSelector:@selector(window)])
    {
        return [app.delegate window];
    }
    else
    {
        return [app keyWindow];
    }
}

+ (void)show
{
    [[tztGuideViewController sharedGuide].pageScroll setContentOffset:CGPointMake(0.f, 0.f)];
	[[tztGuideViewController sharedGuide] showGuide];
}

+ (void)hide
{
	[[tztGuideViewController sharedGuide] hideGuide];
}

#pragma mark - 

+ (tztGuideViewController *)sharedGuide
{
    @synchronized(self)
    {
        static tztGuideViewController *sharedGuide = nil;
        if (sharedGuide == nil)
        {
            sharedGuide = [[self alloc] init];
        }
        return sharedGuide;
    }
}

- (void)pressCheckButton:(UIButton *)checkButton
{
    [checkButton setSelected:!checkButton.selected];
}

- (void)pressEnterButton:(UIButton *)enterButton
{
    if(_tztdelegate){
        [_tztdelegate appStart];
    }
    [self hideGuide];
    
    NSString* strShowguidver = tztAppSysValueWithDefault(@"tztapp_guidver", @"1.0.0");
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"firstLaunch"];
    tztSetUserData(@"tztapp_guidver", strShowguidver);
    if(_tztdelegate){
        [_tztdelegate appShow];
    }
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
     if (_pagecontroll.currentPage == (_nPageCount -1 ))
    {
        if (scrollView.contentOffset.x > (scrollView.frame.size.width * _pagecontroll.currentPage))
        {
            [self pressEnterButton:nil];
        }
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)sView
{
    NSInteger index = fabs(sView.contentOffset.x) / sView.frame.size.width;
    [_pagecontroll setCurrentPage:index];
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    NSString* strGuidImages = tztAppSysValueWithDefault(@"tztapp_guidimages", @"");
    imageNameArray = [strGuidImages componentsSeparatedByString:@"|"];
    CGRect rcFrame = tztScreenBounds();// self.view.bounds;
    self.view.backgroundColor = [UIColor blackColor];
    _pageScroll = [[UIScrollView alloc] initWithFrame:rcFrame];
    self.pageScroll.pagingEnabled = YES;
    _pageScroll.backgroundColor = [UIColor blackColor];
    self.pageScroll.delegate = self;
    
    NSString *imgName = nil;
    UIImageView *view;
    _nPageCount = 0;
    for (int i = 0; i < imageNameArray.count; i++)
    {
        imgName = [imageNameArray objectAtIndex:i];
        if(imgName == NULL || [imgName length] <= 0)
            continue;

        view = [[UIImageView alloc] initWithFrame:CGRectMake((rcFrame.size.width * _nPageCount), 0.f, rcFrame.size.width, rcFrame.size.height)];
        imgName = tztScreenImage(imgName);
        [view setImage:[UIImage imageTztNamed:imgName]];
        view.userInteractionEnabled = YES;
        [self.pageScroll addSubview:view];
        if (i == imageNameArray.count - 1) {            
            UIButton *checkButton = [UIButton buttonWithType:UIButtonTypeCustom];
            checkButton.frame = CGRectMake(80.f, 355.f, 15.f, 15.f);
            [checkButton setImage:[UIImage imageTztNamed:@"checkBox_selectCheck"] forState:UIControlStateSelected];
            [checkButton setImage:[UIImage imageTztNamed:@"checkBox_blankCheck"] forState:UIControlStateNormal];
            [checkButton addTarget:self action:@selector(pressCheckButton:) forControlEvents:UIControlEventTouchUpInside];
            [checkButton setSelected:YES];
            [view addSubview:checkButton];
            
            UIImage *image = [UIImage imageTztNamed:@"tztStart_stepOk"];
            CGSize sz = image.size;
            
            if (image == NULL || image.size.width < 1 || image.size.height < 1)
            {
                sz.width = rcFrame.size.width;
                sz.height = 80;
            }
            UIButton *enterButton = [UIButton buttonWithType:UIButtonTypeCustom];//
            enterButton.frame = CGRectMake((rcFrame.size.width - sz.width) / 2, rcFrame.size.height - sz.height - 20, sz.width, sz.height);
            [enterButton setBackgroundImage:image forState:UIControlStateNormal];
            enterButton.showsTouchWhenHighlighted = YES;
            enterButton.backgroundColor = [UIColor clearColor];
            [enterButton addTarget:self action:@selector(pressEnterButton:) forControlEvents:UIControlEventTouchUpInside];
            [view addSubview:enterButton];
        }
        _nPageCount++;
    }
    
    self.pageScroll.contentSize = CGSizeMake(rcFrame.size.width * _nPageCount, rcFrame.size.height);
    self.pageScroll.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:self.pageScroll];
    
    _pagecontroll = [[UIPageControl alloc] initWithFrame:CGRectMake((rcFrame.size.width - 80) / 2, rcFrame.size.height - 10, 80, 10)];
    [_pagecontroll setBackgroundColor:[UIColor clearColor]];
    _pagecontroll.currentPage = 0;
    _pagecontroll.numberOfPages = _nPageCount;
    _pagecontroll.userInteractionEnabled = FALSE;
    [self.view addSubview:_pagecontroll];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)dealloc
{
    [imageNameArray release];
    [_pagecontroll release];
    [_pageScroll release];
    [super dealloc];
}
@end
