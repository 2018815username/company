//
//  tztAppStart.m
//  tztmodel
//
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztAppInit.h"
#import "tztGuideViewController.h"
#import "tztSysInitVC.h"
#import "tztMainTabbarVC.h"
#import "tztTabObject.h"
#import "tztSysInitData.h"
#import "tztStatusBar.h"
//#import <tztMobileBase/tztStatusBar.h>
#import "tztBaseVC_Web.h"

@interface tztAppInit ()<tztHTTPSendDataDelegate,tztStatusBarDelegate>
{
    NSDictionary* _launchOptions;
    BOOL _bBackground;
    BOOL _bCallSDK;
    UINavigationController* _pCallNav;
    BOOL _bShowNaviBar;
}
@property (nonatomic,retain) NSDictionary* launchOptions;
//是否显示引导页
- (BOOL)getShowGuid;
//
- (void)onLoadTabVC:(BOOL)bHide;
@end

@implementation tztAppInit
@synthesize window = _window;
@synthesize revealSideViewController = _revealSideViewController;
@synthesize mainTabBarVC = _mainTabBarVC;
@synthesize launchOptions = _launchOptions;

+ (tztAppInit *)sharedtztAppInit
{
    @synchronized(self)
    {
        static tztAppInit *sharedtztAppInit = nil;
        if (sharedtztAppInit == nil)
        {
            sharedtztAppInit = [[self alloc] init];
        }
        return sharedtztAppInit;
    }
}

- (BOOL)tztHandleOpenURL:(NSURL*)url
{
    return TRUE;
}

- (void)appShow
{
    _bBackground = FALSE;
    _mainTabBarVC.view.hidden = NO;
    [self tztGetPushMessage];
    if(self.launchOptions){
        //openURL  UIApplicationLaunchOptionsURLKey UIApplicationLaunchOptionsSourceApplicationKey
        NSString* strURL = [_launchOptions objectForKey:UIApplicationLaunchOptionsURLKey];
        if(strURL && [strURL length] > 0){
            [self tztHandleOpenURL:[NSURL URLWithString:strURL]];
            return;
        }
        //Notification
        NSDictionary* remoteNotification = [_launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
        if(remoteNotification && remoteNotification.count > 0){
            _bBackground = TRUE;
            [self remoteNotification:remoteNotification];
            return;
        }
        //LocalNotification
        NSDictionary* localNotification = [_launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
        if(localNotification && localNotification.count > 0){
            NSLog(@"%@",localNotification);
            return;
        }
    }
}

- (void)appStart
{
    int ntztUserPush = tztAppSysIntValueWithDefault(@"tztapp_usernotification", 1);
    if(ntztUserPush != 0){
#ifdef __IPHONE_8_0
        if(IS_TZTIOS(8)){
            UIUserNotificationType types = UIUserNotificationTypeBadge                                                                                                                        | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
            [[UIApplication sharedApplication] registerForRemoteNotifications];
            UIUserNotificationSettings *mySettings = [UIUserNotificationSettings settingsForTypes:types categories:nil];
            [[UIApplication sharedApplication] registerUserNotificationSettings:mySettings];
            
        }else
#endif
        {
            [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeAlert| UIRemoteNotificationTypeBadge|UIRemoteNotificationTypeSound)];
        }
        [[NSNotificationCenter defaultCenter] addObserver: self
                                                 selector: @selector(tztGetPushMessage)
                                                     name: @"tztGetPushMessage"
                                                   object: nil];
        
        
    }
}

-(void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    NilObject(self.launchOptions);
    Obj_RELEASE(_mainTabBarVC);
    Obj_RELEASE(_revealSideViewController);
    [super dealloc];
}


- (void)tztInitApp:(NSDictionary *)launchOptions
{
    self.launchOptions = launchOptions;
    _bCallSDK = FALSE;

    g_nsUpVersion =[tztMobileInitParams getShareInstance].g_nsUpVersion;
    CheckNetStatus();//初始判断网络状态。
    tztSetBasedef();
    [tztSysInitData tztUpdateBundle];
    tztSetBasedef();
    [self initserver];
    
    if(launchOptions != NULL && [launchOptions count] > 0){
        NSDictionary* CallOptions = [launchOptions objectForKey:@"tztCallSDKOptions"];
        if(CallOptions && [CallOptions count] > 0)
        {
            _bCallSDK = TRUE;
            _pCallNav = [CallOptions objectForKey:@"UINavigationController"];
            self.window = [CallOptions objectForKey:@"UIWindow"];
            for (int i = 0; i < [[CallOptions allKeys] count]; i++) {
                NSString* strKey = [[CallOptions allKeys] objectAtIndex:i];
                id Value = [CallOptions valueForKey:strKey];
                if(Value && [Value isKindOfClass:[NSString class]]){
                    [[tztHTTPData getShareInstance] setlocalValue:strKey withValue:Value];
                }
            }
        }
    }
    
    [tztSysInitData onJHAction:^(){
        if(_bCallSDK){
            [self onLoadTabVC:YES];
            [self appStart];
            [self appShow];
        }else{
            BOOL bShowGuid = [self getShowGuid];
            [self onLoadTabVC:YES];
            if(bShowGuid)
            {
                [tztGuideViewController show];
            }else{
                [tztSysInitVC sharedInit].tztdelegate = self;
                [tztSysInitVC show];
            }
        }
    }];
}

- (void)onLoadTabVC:(BOOL)bHide
{
    //Tab列表
    NSMutableArray *pAy = [tztTabObject makeAyTabBarVC:(_bCallSDK && _pCallNav)];
    if(pAy && [pAy count] > 0){
        if(_mainTabBarVC == NULL){
            _mainTabBarVC = NewObject(tztMainTabbarVC);
            
            _mainTabBarVC.viewControllers = pAy;
            
            NSMutableArray *controllers = [NSMutableArray arrayWithArray:_mainTabBarVC.customizableViewControllers];
            [controllers removeAllObjects];
            _mainTabBarVC.customizableViewControllers = controllers;
            
            _mainTabBarVC.delegate = self;
            
            [_mainTabBarVC setTabBarIndex:0 options_:NULL];
            
            [_mainTabBarVC initSideViewController];
            _revealSideViewController = [[PPRevealSideViewController alloc] initWithRootViewController:_mainTabBarVC];
            _revealSideViewController.delegate = _mainTabBarVC;
            [_revealSideViewController setDirectionsToShowBounce:PPRevealSideDirectionNone];
            [_revealSideViewController setPanInteractionsWhenClosed:PPRevealSideInteractionNavigationBar];
        }
        if(_bCallSDK && _pCallNav){
            _bShowNaviBar = _pCallNav.navigationBar.hidden;
            _pCallNav.navigationBar.hidden = YES;
            [_revealSideViewController SetHidesBottomBarWhenPushed:TRUE];
            [_pCallNav pushViewController:_revealSideViewController animated:NO];
        }
        else{
            [self.window setRootViewController:_revealSideViewController];
        }
        _mainTabBarVC.view.hidden = bHide;
    }else{//不是Tab
    }
    [self.window makeKeyAndVisible];
}

- (void)popRootViewController:(id)pVC Animated:(BOOL)animated
{
    if(pVC && [pVC isKindOfClass:[tztBaseVC class]]){
        tztBaseVC* pRootVC = (tztBaseVC*)pVC;
        if(pRootVC.nTabBarVC != 1){
            [self onRootTab:0];
        }else if(_pCallNav){
            _pCallNav.navigationBar.hidden = _bShowNaviBar;
            [_pCallNav popViewControllerAnimated:animated];
        }
    }
}

- (void)onRootTab:(int)nTab
{
    if(_mainTabBarVC){
        [_mainTabBarVC onRootTab:nTab];
    }
}

- (void)selectedTabPageID:(unsigned int)nPageID
{
    if(_mainTabBarVC){
        int nTab = [_mainTabBarVC GetTabItemIndexByID:nPageID];
        [_mainTabBarVC setTabBarIndex:nTab options_:NULL];
    }
}

- (void)selectedTab:(int)nTab
{
    if(_mainTabBarVC){
        [_mainTabBarVC setTabBarIndex:nTab options_:NULL];
    }
}
- (BOOL)getShowGuid
{
    NSString* strImages = tztAppSysValueWithDefault(@"tztapp_guidimages", @"");
    if(strImages.length > 0){
        NSString* strShowguidver = tztAppSysValueWithDefault(@"tztapp_guidver", @"1.0.0");
        [tztGuideViewController sharedGuide].tztdelegate = self;
        NSString* strLanucnedVer = tztGetUserData(@"tztapp_guidver");
        return (strLanucnedVer == NULL|| strLanucnedVer.length < 1
                          || (strLanucnedVer && [strLanucnedVer caseInsensitiveCompare:strShowguidver] != NSOrderedSame));
    }
    return FALSE;
}

- (void)initserver
{
    NSURLCache *urlCache = [NSURLCache sharedURLCache];
    /* 设置缓存的大小为5M*/
    [urlCache setMemoryCapacity:4*1024*1024];
    [urlCache setDiskCapacity:32*1024*1024];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidEnterBackground) name:UIApplicationDidEnterBackgroundNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillEnterForeground) name:UIApplicationWillEnterForegroundNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationDidBecomeActive) name:UIApplicationDidBecomeActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationWillResignActive) name:UIApplicationWillResignActiveNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(reachabilityChanged:)
                                                 name:kTZTReachabilityChangedNotification
                                               object:nil];
}

//通讯状态回调
- (void)reachabilityChanged:(NSNotification *)note
{
    TZTReachability* curReach = [note object];
    static TZTNetworkStatus prestatus = TZTNotReachable;
    NSParameterAssert([curReach isKindOfClass: [TZTReachability class]]);
    TZTNetworkStatus status = [curReach currentReachabilityStatus];
    BOOL bReConn = (status != prestatus);
    if (status == TZTNotReachable || prestatus != TZTNotReachable )
    {
        TZTLogInfo(@"%@",@"TZTNotReachable");
        [tztMoblieStockComm freeAllInstanceSocket];
    }
    prestatus = status;
    if(bReConn)
    {
        [tztMoblieStockComm getAllInstance];
    }
}


-(void)applicationDidEnterBackground
{
    _bBackground = TRUE;
    [tztlocalHTTPServer stopShareInstance];
    [tztMoblieStockComm freeAllInstanceSocket];
}

-(void)applicationWillEnterForeground
{
    CheckNetStatus();//初始判断网络状态
    [tztlocalHTTPServer stopShareInstance];
    [tztlocalHTTPServer starShareInstance];
    [tztMoblieStockComm getAllInstance];
}


-(void)applicationDidBecomeActive
{
    _bBackground = FALSE;
}

-(void)applicationWillResignActive
{
    
}

- (void)tztUniqueidLogin:(NSString*)strAccount branch:(NSString*)strBranch
{
    //    功能号	44800	老功能号		更新日期	20140224
    //    功能名称	交易登陆	版本号		结果集返回	N
    //    功能描述	记录交易用户登陆状态(客户端不直接调用该功能，还是调用100功能号，但需要把相应字段补上)			账户2.0	-
    //    输入参数	参数名	类型	说明	必须	缺省值
    //    account	string	客户号	Y
    //    uniqueid	string	客户端唯一标识符	Y
    //    tfrom	string	客户端标识	Y
    //    version	string	客户端版本	Y
    //    khbranch	string	营业部号	Y
    //    输出参数	参数名	类型	说明	操作符	缺省值
    //    errorno	int	错误号
    //    errormessage	string	错误信息
    dispatch_async (dispatch_get_global_queue (DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
    {
        NSMutableDictionary *sendvalue = NewObject(NSMutableDictionary);
        NSString* strUniqueid = [tztKeyChain load:tztUniqueID];
        if(strAccount && strAccount.length > 0 && strUniqueid && strUniqueid.length >0 ){
            NSString *strReqno = tztKeyReqno((long)self, 44800);
            [sendvalue setTztValue:strReqno forKey:@"Reqno"];
            [sendvalue setTztObject:@"44800" forKey:@"Action"];
            [sendvalue setTztObject:strAccount forKey:@"account"];
            [sendvalue setTztObject:strUniqueid forKey:@"uniqueid"];
            if (g_nsUpVersion)
                [sendvalue setTztObject:g_nsUpVersion forKey:@"version"];
            if(strBranch)
                [sendvalue setTztObject:strBranch forKey:@"khbranch"];

            tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
            sendHttpData.tztdelegate = self;
            [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
        }
        [sendvalue release];
    });
}

- (void)tztUniqueidLogout:(NSString*)strAccount branch:(NSString*)strBranch;
{
//    功能号	44801	老功能号		更新日期	20140224
//    功能名称	交易登出	版本号		结果集返回	N
//    功能描述	记录交易用户登出状态			账户2.0	-
//    输入参数	参数名	类型	说明	必须	缺省值
//    account	string	客户号	Y
//    uniqueid	string	客户端唯一标识符	Y
//    tfrom	string	客户端标识	Y
//    version	string	客户端版本	Y
//    khbranch	string	营业部号	Y
//    输出参数	参数名	类型	说明	操作符	缺省值
//    errorno	int	错误号
//    errormessage	string	错误信息
    dispatch_async (dispatch_get_global_queue (DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
    {
        NSString* strUniqueid = [tztKeyChain load:tztUniqueID];
        if(strAccount && strAccount.length > 0 && strUniqueid && strUniqueid.length >0 ){
            NSMutableDictionary *sendvalue = NewObject(NSMutableDictionary);
            NSString *strReqno = tztKeyReqno((long)self, 44801);
            [sendvalue setTztValue:strReqno forKey:@"Reqno"];
            [sendvalue setTztObject:@"44801" forKey:@"Action"];
            [sendvalue setTztObject:strAccount forKey:@"account"];
            [sendvalue setTztObject:strUniqueid forKey:@"uniqueid"];
            if (g_nsUpVersion)
                [sendvalue setTztObject:g_nsUpVersion forKey:@"version"];
            if(strBranch)
                [sendvalue setTztObject:strBranch forKey:@"khbranch"];

            tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
            sendHttpData.tztdelegate = self;
            [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
            [sendvalue release];
        }
    });
}

- (void)getTztUniqueid
{
    NSString* strUniqueid = [tztKeyChain load:tztUniqueID];
    NSMutableDictionary *sendvalue = NewObject(NSMutableDictionary);
    if(strUniqueid == NULL || strUniqueid.length <= 0){
        NSString *strReqno = tztKeyReqno((long)self, 44802);
        [sendvalue setTztValue:strReqno forKey:@"Reqno"];
        [sendvalue setTztObject:@"44802" forKey:@"Action"];
        tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
        sendHttpData.tztdelegate = self;
        [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
    }else if(g_nsdeviceToken && g_nsdeviceToken.length > 0){
        NSString *strReqno = tztKeyReqno((long)self, 44804);
        [sendvalue setTztValue:strReqno forKey:@"Reqno"];
        [sendvalue setTztObject:@"44804" forKey:@"Action"];
        [sendvalue setTztValue:strUniqueid forKey:@"uniqueid"];
        NSString* strValue = @"";
#if TARGET_OS_IPHONE
        strValue = [tztKeyChain load:tztLogMobile];
#else
        strValue = g_nsLogMobile;
#endif
        [sendvalue setTztValue:strValue forKey:@"mobilecode"];
        
        NSString* strImei = [tztOpenUDID value];
        if (validateMobile(strImei))
        {
            [sendvalue setTztValue:strImei forKey:@"IMEI"];
        }
        if (g_nsUpVersion)
            [sendvalue setTztObject:g_nsUpVersion forKey:@"version"];
        
        [sendvalue setTztObject:g_nsdeviceToken forKey:@"devicetoken"];
        
        [sendvalue setTztObject:(IS_TZTIPAD ? @"1":@"0") forKey:@"devicetype"];//IPHONE - 0 ; IPAD - 1

        [sendvalue setTztObject:tztAppSysValueWithDefault(@"tztapp_pushcerttype", @"0") forKey:@"certtype"];//证书类型 测试－0 iphone

        NSMutableDictionary *pDeviceInfo = [UIDevice tztDeviceInfo];
        
        [sendvalue setTztObject:[pDeviceInfo tztObjectForKey:@"devicemodel"] forKey:@"platform"];
        [sendvalue setTztObject:[pDeviceInfo tztObjectForKey:@"systemnameex"] forKey:@"model"];
        [sendvalue setTztObject:[pDeviceInfo tztObjectForKey:@"systemversion"] forKey:@"mobileversion"];
        [sendvalue setTztObject:[pDeviceInfo tztObjectForKey:@"screensize"] forKey:@"resolution"];
        
        TZTNetworkStatus status = [g_tztreachability currentReachabilityStatus];
        if (status == TZTReachableViaWiFi)
        {
            strValue = @"wifi";
        }
        else
        {
            if (g_nConnectType == TZTConnectHttp)
            {
                strValue = @"wap";
            }
            else
            {
                strValue = @"3G";
            }
        }
        [sendvalue setTztObject:strValue forKey:@"nettype"];
        
        tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
        sendHttpData.tztdelegate = self;
        [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
    }
    [sendvalue release];
    //uniqueid
}

- (void)setDeviceToken:(NSString*)strToken
{
    g_nsdeviceToken = [strToken retain];
    TZTLogInfo(@"deviceToken: %@", g_nsdeviceToken);
    [self getTztUniqueid];
}

- (void)remoteNotification:(NSDictionary*)userInfo
{
    if(userInfo == NULL || userInfo.count <= 0){
        _bBackground = FALSE;
        return;
    }
    NSString* nsbadge = [[userInfo objectForKey:@"aps"] objectForKey:@"badge"];
    [UIApplication sharedApplication].applicationIconBadgeNumber = [nsbadge intValue];
    if(_mainTabBarVC){
        [_mainTabBarVC setTabBarIndex:tztAppSysIntValueWithDefault(@"tztapp_pushbadgetabindex", -1) withBadge:[NSString stringWithFormat:@"%@",nsbadge]];
    }
    //是从最小化起来
    if(!_bBackground){
        [tztStatusBar tztShowPushInfoInStatusBar:userInfo
                                       bgColor_:[UIColor colorWithTztRGBStr:@"59,59,59"]
                                      txtColor_:[UIColor whiteColor]
                                      fTimeOut_:-1.0f
                                      delegate_:self
                                     nPosition_:0];
    }else{
       [self tztGetPushDetailInfo:[[userInfo objectForKey:@"aps"] objectForKey:@"att"]];
    }
    _bBackground = FALSE;
}

-(void)tztStatusBarClicked:(tztStatusBar*)statusBar
{
 
    if (statusBar && statusBar.tztUserInfo){
        [self tztGetPushDetailInfo:[[statusBar.tztUserInfo objectForKey:@"aps"] objectForKey:@"att"]];
    }
}

- (void)tztGetPushMessage
{
    if(_mainTabBarVC){
        NSString* strBadge = @"";
        if([UIApplication sharedApplication].applicationIconBadgeNumber > 0)
        {
            strBadge = [NSString stringWithFormat:@"%ld",(long)[UIApplication sharedApplication].applicationIconBadgeNumber];
        }
        [_mainTabBarVC setTabBarIndex:tztAppSysIntValueWithDefault(@"tztapp_pushbadgetabindex", -1) withBadge:strBadge];
    }
}

//请求推送详情
-(void)tztGetPushDetailInfo:(NSString*)strData
{
    if (strData == NULL || strData.length < 1)
        return;
//    tztAfxMessageBox(strData);
    NSArray* ayPush = [strData componentsSeparatedByString:@"|"];
    if (ayPush.count < 2)
        return;
    //根据nsSocId和nsType来获取详细信息
    //根据文档，type是必须字段，socid非必须，对type进行判断
    NSString *nsSocId = [ayPush objectAtIndex:0];
    NSString *nsType = [ayPush objectAtIndex:1];
    
    NSString* strUrl = [NSString stringWithFormat:@"/pub/push_message.htm?socid=%@&type=%@", nsSocId, nsType];
    tztBaseVC_Web * pNewVC = (tztBaseVC_Web *)[tztBaseVC_Web tztAllocWebVC];
    [pNewVC SetHidesBottomBarWhenPushed:TRUE];
    [pNewVC setWebInfo:[NSMutableDictionary dictionaryWithObjectsAndKeys:@"1",@"type",@"1",@"fullscreen",strUrl,@"url",nil]];
    [pNewVC setWebURL:strUrl];
    [g_navigationController pushViewController:pNewVC animated:FALSE];
    [pNewVC release];
}

- (void)onSenddataError:(NSMutableDictionary*)sendData type:(int)nType
{
    
}

- (NSUInteger)OnCommNotify:(NSUInteger)wParam lParam_:(NSUInteger)lParam
{
    if( wParam == 0 )
        return 0;
    tztNewMSParse *parse = (tztNewMSParse*)wParam;
    if ([parse IsIphoneKey:(long)self reqno:44802] && [parse IsAction:@"44802"]){
        NSString* strUniqueid = [parse GetByName:@"uniqueid"];
        if(strUniqueid && [strUniqueid length] > 0)
        {
            [tztKeyChain save:tztUniqueID data:strUniqueid];
            [self getTztUniqueid];
        }
        return 0;
    }else if([parse IsIphoneKey:(long)self reqno:44804] && [parse IsAction:@"44804"]){
        return 1;
    }else if([parse IsIphoneKey:(long)self reqno:44800] && [parse IsAction:@"44800"]){
        return 1;
    }else if([parse IsIphoneKey:(long)self reqno:44801] && [parse IsAction:@"44801"]){
        return 1;
    }
    return 0;
}
@end
