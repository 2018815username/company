//
//  tztTabObject.m
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztTabObject.h"
#import "tztBaseVC.h"
#import "tztTabBarProfile.h"
#import "tztBaseVC_Web.h"

@implementation tztTabObject

+ (NSMutableArray*)makeAyTabBarVC:(BOOL)bReturn
{
    NSMutableArray *ayVc = [[NSMutableArray alloc] init];
    [ayVc removeAllObjects];
    if(g_ptztTabBarProfile == NULL)
    {
        g_ptztTabBarProfile = NewObject(tztTabBarProfile);
        [g_ptztTabBarProfile LoadTabBarItem];
    }
    for (int i = 0; i < [g_ptztTabBarProfile.ayTabBarItem count]; i++) {
        tztTabBarItem* item = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:i];
        NSString* strpageid = [item getItemValue:@"pageid"];
        NSString* strAction = [item getItemValue:@"action"];
        NSString* strURL = [item getItemValue:@"url"];
       
        tztBaseVC *pVC = NULL;
        if(strAction && [strAction intValue] > 0){
            
        }else{
            pVC = [tztBaseVC_Web tztAllocWebVC];
            tztBaseVC_Web* webVC = (tztBaseVC_Web*)pVC;
            NSMutableDictionary* pDict = (NSMutableDictionary*)[strURL tztNSMutableDictionarySeparatedByString:tztHTTPStrSep decodeurl:TRUE];
            if(bReturn){
                [pDict setValue:@"" forKey:@"firsttype"];
            }
            webVC.nTabBarVC = i + 1;
            webVC.webInfo = pDict;
            [webVC setWebURL:[pDict tztValueForKey:@"url"]];
        }
        tztUINavigationController* pNavVc = [[tztUINavigationController alloc] initWithRootViewController:pVC];
        Obj_RELEASE(pVC);
        [pNavVc setNavigationBarHidden:YES];
        pNavVc.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"" image:nil tag:[strpageid integerValue]];
        [ayVc addObject:pNavVc];
        Obj_RELEASE(pNavVc);
    }
    return Obj_AUTORELEASE(ayVc);
}
@end
