#import "tztTabBarView.h"
#import "tztTabBarProfile.h"
#import "tztBaseVC.h"
#import "tztBadgeView.h"

#define TZTPageInfoItemLG 1023
#define TZTPageInfoItemTag 1024
tztTabBarView *g_ptztTabBarView = NULL;

@interface tztTabBarView ()
{
    int             _nPreSelectd;//上一个选中的
    NSMutableDictionary *_barProertyValues;
}
@property int  nPreSelectd;
@property (nonatomic,retain)  NSMutableDictionary* barProertyValues;
- (void)saveAndLoadProperty:(BOOL)bSave;
@end

@implementation tztTabBarView
@synthesize pSelectedView = _pSelectedView;
@synthesize pBackGroundView = _pBackGroundView;
@synthesize nSelected = _nSelected;
@synthesize nPreSelectd = _nPreSelectd;
@synthesize barProertyValues = _barProertyValues;
-(id)init
{
    self = [super init];
    if (self)
    {
        _nPreSelectd = -1;
        _nSelected = 0;
        //判断配置文件是否已经加载，没有加载重新加载
        if (g_ptztTabBarProfile == NULL)
        {
            g_ptztTabBarProfile = NewObject(tztTabBarProfile);
            [g_ptztTabBarProfile LoadTabBarItem];
        }
        if(_barProertyValues == NULL)
        {
            _barProertyValues = NewObject(NSMutableDictionary);
        }
        
		[[NSNotificationCenter defaultCenter] addObserver:self
												 selector:@selector(OnHiddenMoreView:)
													 name:TZTNotifi_HiddenMoreView
												   object:nil];
        
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(ReloadToolBar:)
                                                     name:TZTNotifi_ChangeTabBarStatus
                                                   object:nil];
    }
    return self;
}

-(void)OnChangeTheme
{
    //重新加载配置文件
    [g_ptztTabBarProfile LoadTabBarItem];
    [self setFrame:self.frame];
}

-(void)setFrame:(CGRect)frame
{
    if (CGRectIsNull(frame) || CGRectIsEmpty(frame))
        return;
    
    [super setFrame:frame];
    if (_pBackGroundView == NULL)
    {
        _pBackGroundView = [[UIImageView alloc] initWithFrame:self.bounds];
        [_pBackGroundView setImage:[UIImage imageTztNamed:@"TZTTabBarBG.png"]];
        [self addSubview:_pBackGroundView];
        [_pBackGroundView release];
    }
    else
    {
        _pBackGroundView.frame = self.bounds;
    }
    
    if (g_ptztTabBarProfile == NULL)
        return;
    
    if (IS_TZTIPAD)
    {
        CGRect rcLogo = frame;
        rcLogo.origin.y = 0;
        UIImage *pImageLogo = [UIImage imageTztNamed:@"tztTitleLogo.png"];
        if (pImageLogo)
        {
            rcLogo.origin.x = 10;
            rcLogo.size = pImageLogo.size;
            if (rcLogo.size.height > pImageLogo.size.height)
                rcLogo.origin.y += (rcLogo.size.height - pImageLogo.size.height) / 2.f;
            else
                rcLogo.size.height = frame.size.height;
            
            UIButton *pBtnLogo = (UIButton*)[self viewWithTag:TZTPageInfoItemLG];
            if (pBtnLogo == NULL)
            {
                pBtnLogo = [UIButton buttonWithType:UIButtonTypeCustom];
                [pBtnLogo setImage:pImageLogo forState:UIControlStateNormal];
                [pBtnLogo setContentMode:UIViewContentModeCenter];
                [pBtnLogo setShowsTouchWhenHighlighted:YES];
                pBtnLogo.frame = rcLogo;
                pBtnLogo.tag = TZTPageInfoItemLG;
                [self addSubview:pBtnLogo];
            }
            else
            {
                pBtnLogo.frame = rcLogo;
            }
        }
    }
    
    //左侧预留宽度
    float nLeft = g_ptztTabBarProfile.nMarginHead;
    //右侧预留宽度
    float nRight = g_ptztTabBarProfile.nMarginTail;
    //需要显示的个数
    NSUInteger nCount = [g_ptztTabBarProfile.ayTabBarItem count];
    if (g_ptztTabBarProfile.nMaxDisplay > 0)
        nCount = g_ptztTabBarProfile.nMaxDisplay;
    
    if (nCount <= 0)
        return;
    
    float nBaseWidth = 0;
    if (IS_TZTIPAD)
         nBaseWidth = (768 / nCount + 2);
    else
        nBaseWidth = (320 / nCount );
    float nMaxDrawWidth = (frame.size.width - nLeft - nRight);
    
    float nSpace = (nMaxDrawWidth - (nCount*nBaseWidth)) / 2;
    if (nSpace < 0 )
        nSpace = 0;
//    int nPerWidth = / nCount;
    
    CGRect rcFrame = CGRectMake(nLeft + nSpace, 0, nBaseWidth, frame.size.height);
    //创建按钮
    for (int i = 0; i < nCount; i++)
    {
        tztTabBarItem *tabBarItem = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:i];
        if (tabBarItem == NULL)
            continue;
        UIImage* tabImage = [UIImage imageTztNamed:[tabBarItem getItemValue:@"image"]];
        int nTag = i + TZTPageInfoItemTag;
        tztUISwitch *pButton = (tztUISwitch*)[self viewWithTag:nTag];
        CGSize sz = tabImage.size;
        CGRect rcTemp = rcFrame;
        if (!g_ptztTabBarProfile.nDrawName && !IS_TZTIPAD)
        {
            rcTemp.origin.x += (rcFrame.size.width - sz.width) / 2;
            rcTemp.origin.y += (rcFrame.size.height - sz.height) / 2;
            rcTemp.size = sz;
        }
        if (pButton == NULL)
        {
            pButton = [self CreateButton:tabBarItem rcFrame_:rcTemp nTag_:nTag];
            [self addSubview:pButton];
        }
        else
        {
            pButton = [self CreateButton:tabBarItem rcFrame_:rcTemp nTag_:nTag];
            pButton.frame = rcTemp;
            [self setSwitch:pButton withInfo:tabBarItem];
        }
        
        if (g_ptztTabBarProfile.nSeperator)
        {
            CGRect rc = CGRectMake(rcFrame.origin.x + rcFrame.size.width - 1, rcFrame.origin.y + 5, 1, rcFrame.size.height - 10);
            UIView *pSepView = [self viewWithTag:i + (TZTPageInfoItemTag * 2)];
            if (pSepView == NULL)
            {
                pSepView = [[UIView alloc] initWithFrame:rc];
                pSepView.tag = i + (TZTPageInfoItemTag * 2);
                pSepView.backgroundColor = [UIColor colorWithRGBULong:g_ptztTabBarProfile.nSeperatorColor];
                [self addSubview:pSepView];
                [pSepView release];
            }
            else
            {
                pSepView.frame = rc;
            }
        }
        
        if (i == _nSelected)
        {
            [pButton setChecked:YES];
            _nPreSelectd = _nSelected;
        }
        rcFrame.origin.x += nBaseWidth;
        
        if (rcFrame.origin.x + nBaseWidth > frame.size.width)
        {
            rcFrame.size.width = frame.size.width - rcFrame.origin.x;
        }
    }
}

- (void)reload
{
    [self setFrame:self.frame];
}

-(void)setToolBarProperty:(NSDictionary *)property
{
    for (int i = 0; i < [g_ptztTabBarProfile.ayTabBarItem count]; i++)
    {
        NSString *strKey = [NSString stringWithFormat:@"tab%d", (i+1)];
        NSString *strValue = [property objectForKey:strKey];
//        [_barProertyValues setValue:strValue forKey:strKey];
        NSArray* ayValue = [strValue componentsSeparatedByString:@"|"];
        for (int n = 0; n < [ayValue count]; n++) {
//            NSString* strPropertyKey = @"";
            NSString* strPropertyValue = [ayValue objectAtIndex:n];
            switch (n) {
                case 0:
                {
                    [self setTabBarIndex:i withBadge:strPropertyValue];
                }
                    break;
                default:
                    break;
            }
//            if(strPropertyKey.length > 0)
//                [_barProertyValues setValue:strPropertyValue forKey:strPropertyKey];
        }
    }
//    [self saveAndLoadProperty:TRUE];
    NSString* strSysBadge = [property objectForKey:@"sysbadge"];
    if(strSysBadge){
        [UIApplication sharedApplication].applicationIconBadgeNumber = [strSysBadge intValue];
    }
}

//暂不能支持重新读取刷新
- (void)saveAndLoadProperty:(BOOL)bSave
{
    if(bSave){
        NSString* nsFileName = tztTabbarPropertyFile;
        NSString* strPath = [nsFileName tztHttpfilepath];
        [_barProertyValues writeToFile:strPath atomically:YES];
    }else{
        NSString *strFilePath = [tztTabbarPropertyFile tztHttpfilepath];
        NSDictionary *pDict = [NSDictionary dictionaryWithContentsOfFile:strFilePath];
        [self setToolBarProperty:pDict];
    }
    
}
//重新加载toolbar图片，用于图片切换
-(void)ReloadToolBar:(NSString *)strData
{
    //读取上次保存的最新的状态数据
    NSString *strFilePath = [tztTabbarStatusFile tztHttpfilepath];
    NSDictionary *pDict = [NSDictionary dictionaryWithContentsOfFile:strFilePath];
    for (int i = 0; i < [g_ptztTabBarProfile.ayTabBarItem count]; i++)
    {
        tztTabBarItem* pItem = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:i];
        if (pItem == NULL)
            return;
        NSString *strKey = [NSString stringWithFormat:@"tab%d", (i+1)];
        NSString *strValue = [pDict objectForKey:strKey];
        [pItem setItem:@"type" value:strValue];
    }
    
    //读取上次保存的最新的状态数据
    strFilePath = [tztTabbarPropertyFile tztHttpfilepath];
    pDict = [NSDictionary dictionaryWithContentsOfFile:strFilePath];
    for (int i = 0; i < [g_ptztTabBarProfile.ayTabBarItem count]; i++)
    {
        tztTabBarItem* pItem = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:i];
        if (pItem == NULL)
            return;
        NSString *strKey = [NSString stringWithFormat:@"tab%d", (i+1)];
        NSString *strValue = [pDict objectForKey:strKey];
        NSArray* ayValue = [strValue componentsSeparatedByString:@"|"];
        for (int n = 0;  n < [ayValue count]; n++) {
            NSString* strItem = @"";
            switch (n) {
                case 0:
                    strItem = @"badge";
                    break;
                    
                default:
                    break;
            }
            if(strItem.length > 0){
                [pItem setItem:strItem value:strValue];
            }
        }
    }
    
    [self reload];
}

- (void)setTabBarIndex:(int)nBarIndex withBadge:(NSString*)strBadge
{
    if(nBarIndex >= 0 && nBarIndex < [g_ptztTabBarProfile.ayTabBarItem count])
    {
        NSString* strKey = [NSString stringWithFormat:@"badge_%d",nBarIndex];
        NSString* strValue = [NSString stringWithFormat:@"%@",strBadge];
        [_barProertyValues setValue:strBadge forKey:strKey];
        dispatch_async(dispatch_get_main_queue(), ^{
            tztBadgeView* badegeView = (tztBadgeView*)[self viewWithTag:5*TZTPageInfoItemTag + nBarIndex];//
            if (badegeView)
            {
                badegeView.badgeText = strValue;
            }
        });
    }
}

- (void)setTabBarId:(int)nBarID withBadge:(NSString*)strBadge
{
    int nIndex = [self GetTabItemIndexByID:nBarID];
    if(nIndex > 0 )
    {
        [self setTabBarIndex:nIndex withBadge:strBadge];
    }
}

- (void)setTabBarName:(NSString*)strBarName withBadge:(NSString*)strBadge
{
    int nIndex = [self GetTabItemIndexByName:strBarName];
    if(nIndex > 0 )
    {
        [self setTabBarIndex:nIndex withBadge:strBadge];
    }
}

-(tztUISwitch*)CreateButton:(tztTabBarItem*)tabBarItem
                rcFrame_:(CGRect)rcFrame
                   nTag_:(int)nTag
{
    tztUISwitch *pBtn = (tztUISwitch*)[self viewWithTag:nTag];
    if (pBtn == NULL)
    {
        pBtn = [[[tztUISwitch alloc] initWithFrame:rcFrame] autorelease];
        [pBtn addTarget:self action:@selector(OnPageInfoItem:) forControlEvents:UIControlEventTouchUpInside];
        pBtn.tag = nTag;
    }
    pBtn.frame = rcFrame;
    NSString *strImage = [tabBarItem getItemValue:@"image"];
    UIImage *yesImage = [UIImage imageTztNamed:[NSString stringWithFormat:@"%@_on",strImage]];
    pBtn.yesImage = yesImage;
    
    tztBadgeView* badegeView = (tztBadgeView*)[self viewWithTag:4*TZTPageInfoItemTag + nTag];//
    if (badegeView == NULL)
    {
        badegeView = [[tztBadgeView alloc] initWithParentView:pBtn alignment:tztBadgeViewAlignmentTopRight];
        badegeView.tag = 4 * TZTPageInfoItemTag + nTag;
        [badegeView release];
    }
    
    UIImage *noImage = [UIImage imageTztNamed:strImage];
    if (!g_ptztTabBarProfile.nDrawName && !IS_TZTIPAD)
    {
        pBtn.noImage = noImage;// pageInfoItem.ImgNormal;
        [pBtn setChecked:FALSE];
        [pBtn bringSubviewToFront:badegeView];
        return pBtn;
    }
    [pBtn setChecked:FALSE];
    pBtn.showsTouchWhenHighlighted = YES;
    
    CGSize sz = noImage.size;
    CGFloat fHeight = (rcFrame.size.height - 4) / 3;
    if (g_ptztTabBarProfile.nDrawName)
        fHeight = (rcFrame.size.height - 4) / 4;
    
    CGFloat fWidth = MIN(sz.width * fHeight * 3 / sz.height,rcFrame.size.width);
    
    fWidth = MIN(fWidth, sz.width);
    
    CGFloat fImageHeight = MIN(fHeight * 3, sz.height);
    CGFloat fOriginY = 2;
    fOriginY = (fHeight*3 - fImageHeight) / 2;
    if (fOriginY <= 0)
        fOriginY = 2;
    
    CGRect rcImgView = CGRectMake((rcFrame.size.width - fWidth) / 2, fOriginY, fWidth , fImageHeight);
    
    UIImageView *pImageView = (UIImageView*)[self viewWithTag:2*TZTPageInfoItemTag + nTag];
    if (pImageView == NULL)
    {
        pImageView = [[UIImageView alloc] initWithImage:noImage];
        pImageView.backgroundColor = [UIColor clearColor];
        pImageView.tag = 2* TZTPageInfoItemTag + nTag;
        [pBtn addSubview:pImageView];
        [pImageView release];
    }
    pImageView.image = noImage;
    pImageView.frame = rcImgView;
    
    if (!g_ptztTabBarProfile.nDrawName || IS_TZTIPAD)
    {
        [pBtn bringSubviewToFront:badegeView];
        return pBtn;
    }
    
    CGFloat fH = MAX(fHeight*3, fOriginY+fImageHeight);
    CGRect rcLabel = CGRectMake(0, fH, rcFrame.size.width, fHeight);
    UILabel *pLabel = (UILabel*)[self viewWithTag:3*TZTPageInfoItemTag + nTag];//
    if (pLabel == NULL)
    {
        pLabel = [[UILabel alloc] initWithFrame:rcLabel];
        pLabel.text = [tabBarItem getItemValue:@"title"];
        pLabel.textAlignment = NSTextAlignmentCenter;
        pLabel.backgroundColor = [UIColor clearColor];
        pLabel.font = tztUIBaseViewTextBoldFont(13.0f);
        pLabel.tag = 3 * TZTPageInfoItemTag + nTag;
        [pBtn addSubview:pLabel];
        [pLabel release];
        pLabel.textColor = [UIColor colorWithRGBULong:0xB7B7B7];
    }
    [pBtn bringSubviewToFront:badegeView];
    return pBtn;
}

// 重新加载里面的图片，用于替换主题 byDBQ
- (void)setSwitch:(tztUISwitch *)pBtn withInfo:(tztTabBarItem*)tabBarItem
{
    return;
}

-(void)OnDealToolBarByName:(NSString*)nsName
{
    int nIndex = [self GetTabItemIndexByName:nsName];
    [self setTabBarIndex:nIndex options_:NULL];
}

//根据配置的名称获取对应的索引，用于跳转
-(int)GetTabItemIndexByName:(NSString*)nsName
{
    if (g_ptztTabBarProfile)
        return [g_ptztTabBarProfile GetTabItemIndexByName:nsName];
    else
        return -1;
}

//根据配置的ID获取对应的索引，用于跳转
-(int)GetTabItemIndexByID:(unsigned int)intID
{
    if (g_ptztTabBarProfile)
        return [g_ptztTabBarProfile GetTabItemIndexByID:intID];
    else
        return -1;
}

- (void)setNSelected:(int)nSelected
{
    [self setTabBarIndex:nSelected options_:NULL];
}

-(void) setTabBarIndex:(int)nBarIndex options_:(NSDictionary *)options
{
    if (nBarIndex < 0 || nBarIndex >= [g_ptztTabBarProfile.ayTabBarItem count])
        return;
    BOOL bSucc = TRUE;
    _nPreSelectd = _nSelected;
    _nSelected = nBarIndex;
    tztTabBarItem* tztTabItem = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:nBarIndex];
    //处理具体的事件
    if (_pDelegate && [_pDelegate respondsToSelector:@selector(tztTabBarView:didSelectItem:options_:)])
    {
        bSucc = [_pDelegate tztTabBarView:self didSelectItem:tztTabItem  options_:options];
    }
    
    if (bSucc)
    {
        tztUISwitch *pButtonPre =(tztUISwitch*)[self viewWithTag:_nPreSelectd +TZTPageInfoItemTag];
        if (pButtonPre)
        {
            [pButtonPre setChecked:FALSE];
        }
        
        tztUISwitch *pButtonSel = (tztUISwitch*)[self viewWithTag:_nSelected +TZTPageInfoItemTag];
        if (pButtonSel)
        {
            [pButtonSel setChecked:YES];
        }
        _nPreSelectd = _nSelected;
    }
    else{
        _nSelected = _nPreSelectd;
    }
}

-(void)OnPageInfoItem:(id)sender root:(BOOL)broot
{
    UIButton *pButton = (UIButton*)sender;
    NSUInteger nTag = pButton.tag;
    [g_ayPushedViewController removeAllObjects];
    int nPageID = -1;
    tztTabBarItem* tabBarItem = NULL;
    if (nTag - TZTPageInfoItemTag >= 0 && nTag - TZTPageInfoItemTag < [g_ptztTabBarProfile.ayTabBarItem count])
    {
        tabBarItem = [g_ptztTabBarProfile.ayTabBarItem objectAtIndex:nTag - TZTPageInfoItemTag];
        if (tabBarItem)
            nPageID = [[tabBarItem getItemValue:@"pageid"] intValue];
        
        if (tabBarItem && nPageID == tztMorePage)//更多
        {
            UIViewController* pVC = g_navigationController.topViewController;
            if (pVC && [pVC isKindOfClass:[tztBaseVC class]])
            {
                tztUISwitch *pButtonSel = (tztUISwitch*)[self viewWithTag:_nPreSelectd +TZTPageInfoItemTag];
                if (pButtonSel)
                {
                    [pButtonSel setChecked:NO];
                }
                _nSelected = nTag - TZTPageInfoItemTag;
                [(tztBaseVC*)pVC OnMore];
            }
            return;
        }
    }
    [self setTabBarIndex:nTag - TZTPageInfoItemTag options_:NULL];
    if ((tabBarItem && [[tabBarItem getItemValue:@"home"] intValue] > 0) || broot)
    {
        [g_navigationController popToRootViewControllerAnimated:UseAnimated];
        tztBaseVC* pTopVc = (tztBaseVC*)g_navigationController.topViewController;
        [pTopVc tztperformSelector:@"OnRootView"];
    }
    NSArray* ayVC = g_navigationController.viewControllers; //将当前vc列加入操作列
    for (int i = 0; i < [ayVC count]; i++)
    {
        [g_ayPushedViewController addObject:[ayVC objectAtIndex:i]];
    }

}

-(void)OnPageInfoItem:(id)sender
{
    [self OnPageInfoItem:sender root:FALSE];
}

//更多界面隐藏，回到上个界面的选中
-(void)OnHiddenMoreView:(NSNotification*)notification
{
    if(notification && [notification.name compare:TZTNotifi_HiddenMoreView]== NSOrderedSame)
    {
        if (_nPreSelectd == _nSelected)
            return;
        tztUISwitch *pButtonSel = (tztUISwitch*)[self viewWithTag:_nPreSelectd +TZTPageInfoItemTag];
        if (pButtonSel)
        {
            [pButtonSel setChecked:YES];
        }
        pButtonSel = (tztUISwitch*)[self viewWithTag:_nSelected +TZTPageInfoItemTag];
        if (pButtonSel)
        {
            [pButtonSel setChecked:NO];
        }
    }
}
@end
