//
//  tztMainTabbarVC.m
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztMainTabbarVC.h"
#import "tztTabBarProfile.h"
#import "tztBaseVC.h"

@interface tztMainTabbarVC ()
{
    NSMutableArray* _ayViews;
    int _tabBarIndex;
    NSMutableDictionary* _tabBarOption;
}
@property (nonatomic,retain) NSMutableDictionary* tabBarOption;
- (void)showLeftSideVC;
- (void)showRightSideVC;
@end

@implementation tztMainTabbarVC
@synthesize tztTabBarView = _tztTabBarView;
@synthesize tabBarOption = _tabBarOption;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
//    [self LayoutTabBarItem];
//    self.tabBar.hidden = YES;
}

- (void)dealloc
{
    [super dealloc];
    NSLog(@"tztMainTabbarVC dealloc");
}

- (void)viewDidAppear:(BOOL)animated     // Called when the view has been fully transitioned onto the screen. Default does nothing
{
	[super viewDidAppear:animated];
    [self LayoutTabBarItem];
    [self setTabBarIndex:_tabBarIndex options_:self.tabBarOption];
    self.moreNavigationController.navigationBarHidden = YES;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -横竖屏切换时的界面处理
- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
	[super willAnimateRotationToInterfaceOrientation:toInterfaceOrientation duration:duration];
    
    [self LayoutTabBarItem];
}


-(NSUInteger)supportedInterfaceOrientations
{
    if (IS_TZTIPAD)
    {
        return UIInterfaceOrientationMaskLandscape;
    }
    else
    {
        return UIInterfaceOrientationMaskAll;
    }
}

-(BOOL)shouldAutorotate
{
    return YES;
}


#pragma mark -是否允许横竖屏切换
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if (IS_TZTIPAD)
    {
        return (interfaceOrientation == UIInterfaceOrientationLandscapeLeft ||
                interfaceOrientation == UIInterfaceOrientationLandscapeRight);
    }
    else
    {
        if (g_navigationController && [g_navigationController topViewController])
        {
            return [[g_navigationController topViewController] shouldAutorotateToInterfaceOrientation:interfaceOrientation];
        }
        return UIInterfaceOrientationIsPortrait(interfaceOrientation);
    }
}


#pragma mark -加载处理tabBarItem
-(void) LayoutTabBarItem
{
    CGRect rcFrame = self.tabBar.bounds;
    if (_tztTabBarView == nil)
    {
        _tztTabBarView = NewObject(tztTabBarView);
        _tztTabBarView.frame = rcFrame;
        _tztTabBarView.backgroundColor = [UIColor clearColor];
        _tztTabBarView.pDelegate = self;
        _tztTabBarView.nSelected = _tabBarIndex;
        [self.tabBar addSubview:self.tztTabBarView];
    }
    else
    {
        self.tztTabBarView.frame = rcFrame;
    }
    
    g_ptztTabBarView = self.tztTabBarView;
    if (_ayViews == NULL)
    {
        _ayViews = NewObject(NSMutableArray);
    }
    [_ayViews removeObject:self.tabBar];
    [_ayViews addObject:self.tabBar];
}


#pragma SideViewController处理
- (void)initSideViewController
{
    if (_ayViews == NULL)
    {
        _ayViews = NewObject(NSMutableArray);
    }
    [_ayViews removeObject:self.tabBar];
    [_ayViews addObject:self.tabBar];
    
    if (_tztLeftSideVC == nil)
    {
        _tztLeftSideVC = NewObject(tztMainSideVC);
    }
    
    if (_tztLeftNavVC == nil)
    {
        _tztLeftNavVC = [[tztUINavigationController alloc] initWithRootViewController:_tztLeftSideVC];
        _tztLeftNavVC.navigationBar.hidden = YES;
    }
    
    if (_tztRightSideVC == nil)
    {
        _tztRightSideVC = NewObject(tztMainSideVC);
    }
    
    if (_tztRightNavVC == nil)
    {
        _tztRightNavVC = [[tztUINavigationController alloc] initWithRootViewController:_tztRightSideVC];
        _tztRightNavVC.navigationBar.hidden = YES;
    }
    
    CGFloat _offset = tzt_SideWidth;
    [self.revealSideViewController changeOffset:_offset
                                   forDirection:PPRevealSideDirectionRight];
    [self.revealSideViewController changeOffset:_offset
                                   forDirection:PPRevealSideDirectionLeft];
    [self.revealSideViewController changeOffset:_offset
                                   forDirection:PPRevealSideDirectionTop];
    [self.revealSideViewController changeOffset:_offset
                                   forDirection:PPRevealSideDirectionBottom];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(preloadLeft)
                                               object:nil];
    [self performSelector:@selector(preloadLeft) withObject:nil afterDelay:0.3];
    
    [NSObject cancelPreviousPerformRequestsWithTarget:self
                                             selector:@selector(preloadRight)
                                               object:nil];
    [self performSelector:@selector(preloadRight) withObject:nil afterDelay:0.3];
}

-(void)RefreshAddCustomsViews
{
    [self.revealSideViewController updateViewWhichHandleGestures];
}

- (NSArray *)customViewsToAddPanGestureOnPPRevealSideViewController:(PPRevealSideViewController *)controller
{
    return [NSArray arrayWithArray:_ayViews];
}

- (PPRevealSideDirection)pprevealSideViewController:(PPRevealSideViewController *)controller directionsAllowedForPanningOnView:(UIView *)view;
{
    if ([controller getSideToClose] == PPRevealSideDirectionRight)
    {
        return PPRevealSideDirectionRight;
    }
    return PPRevealSideDirectionLeft;
}

- (void)pprevealSideViewController:(PPRevealSideViewController *)controller willPopToController:(UIViewController *)centerController
{
    self.tabBar.userInteractionEnabled = YES;
    g_navigationController.topViewController.view.userInteractionEnabled = YES;
    [g_navigationController.topViewController viewWillAppear:NO];
}

- (void)pprevealSideViewController:(PPRevealSideViewController *)controller willPushController:(UIViewController *)pushedController
{
    self.tabBar.userInteractionEnabled = NO;
    g_navigationController.topViewController.view.userInteractionEnabled = NO;
    [g_navigationController.topViewController viewDidDisappear:NO];
}

-(void)preloadLeft
{
    if (_tztLeftNavVC)
    {
        [self.revealSideViewController preloadViewController:_tztLeftNavVC
                                                     forSide:PPRevealSideDirectionLeft
                                                  withOffset:tzt_SideWidth];
    }
}

-(void)preloadRight
{
    if (_tztRightNavVC)
    {
        [self.revealSideViewController preloadViewController:_tztRightNavVC
                                                     forSide:PPRevealSideDirectionRight
                                                  withOffset:tzt_SideWidth];
    }
}

- (void)showLeftSideVC
{
    if(_tztLeftNavVC)
    {
        self.tabBar.userInteractionEnabled = NO;
        [self.revealSideViewController pushViewController:_tztLeftNavVC onDirection:PPRevealSideDirectionLeft animated:YES];
    }
}

- (void)showRightSideVC
{
    if (_tztRightNavVC)
    {
        [self.revealSideViewController pushViewController:_tztRightNavVC onDirection:PPRevealSideDirectionRight animated:YES];
    }
}

- (void)onRootTab:(int)nTab
{
    NSMutableArray *ayControl = [NSMutableArray arrayWithArray:self.viewControllers];
    for (int nIndex = 0; nIndex < [ayControl count]; nIndex++) {
        tztUINavigationController* viewController = (tztUINavigationController *)[ayControl objectAtIndex:nIndex];
        if (viewController)
        {
            [viewController popToRootViewControllerAnimated:UseAnimated];
            tztBaseVC* pTopVc = (tztBaseVC*)viewController.topViewController;
            [pTopVc tztperformSelector:@"OnRootView"];
        }
    }
    [self setTabBarIndex:nTab options_:NULL];
}

//根据配置的名称获取对应的索引，用于跳转
- (int)GetTabItemIndexByName:(NSString*)nsName
{
    return [_tztTabBarView GetTabItemIndexByName:nsName];
}
//根据配置的ID获取对应的索引，用于跳转
- (int)GetTabItemIndexByID:(unsigned int)nsID
{
    return [_tztTabBarView GetTabItemIndexByID:nsID];
}

//点击TabBar
- (void)setTabBarIndex:(int)nBarIndex options_:(NSDictionary*)options
{
    _tabBarIndex = nBarIndex;
    [_tztTabBarView setTabBarIndex:_tabBarIndex options_:options];
}

- (void)setTabBarIndex:(int)nBarIndex withBadge:(NSString*)strBadge
{
    [_tztTabBarView setTabBarIndex:nBarIndex withBadge:strBadge];
}

- (void)setTabBarId:(int)nBarID withBadge:(NSString*)strBadge
{
    [_tztTabBarView setTabBarId:nBarID withBadge:strBadge];
}

- (void)setTabBarName:(NSString*)strBarName withBadge:(NSString*)strBadge
{
    [_tztTabBarView setTabBarName:strBarName withBadge:strBadge];
}

-(BOOL)didSelectItemAtIndex:(int)nIndex options_:(NSDictionary *)options
{
    NSMutableArray *ayControl = [NSMutableArray arrayWithArray:self.viewControllers];
    UIViewController *viewController = NULL;
	if (ayControl && nIndex >= 0 && nIndex < [ayControl count])
	{
		viewController = [ayControl objectAtIndex:nIndex];
	}
    
    if (viewController == NULL)
	{
		return FALSE;
	}
    _tabBarIndex = nIndex;
    //根据选择tab 设置当前navc
    g_navigationController = (tztUINavigationController*)viewController;
    if(self.selectedIndex != nIndex) //切换列表
    {
        [super setSelectedIndex:nIndex];
        g_bChangeNav = TRUE;
    }
    else
    {
        g_bChangeNav = FALSE;
    }
    return TRUE;
}

- (BOOL)tztTabBarView:(tztTabBarView *)tztTabBar didSelectItem:(tztTabBarItem *)tztBarItem options_:options
{
    int nIndex = tztTabBar.nSelected;
    return [self didSelectItemAtIndex:nIndex options_:options];
}
@end
