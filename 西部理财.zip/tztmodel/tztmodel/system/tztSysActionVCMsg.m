//
//  tztSysActionVCMsg.m
//  tztmodel
//
//  Created by yangares on 14-9-11.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztSysActionVCMsg.h"

@implementation tztSysActionVCMsg

+ (void)tztOpenURL:(NSString*)strURL
{
    if (strURL == NULL || strURL.length <= 0)
        return;
    strURL = [strURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *reqURL = [[NSURL alloc] initWithString:strURL];
    [[UIApplication sharedApplication] openURL:reqURL];
    [reqURL release];
}
@end

void tztOpenURL(NSString* strURL)
{
    [tztSysActionVCMsg tztOpenURL:strURL];
}