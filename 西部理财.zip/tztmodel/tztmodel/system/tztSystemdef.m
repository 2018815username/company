#import "tztSystemdef.h"
#import "tztActionObj.h"

void tztSetBasedef()
{
    tztMobileBaseInit();
#ifdef tzt_CheckUserLogin
    g_nsOnLineAction = @"20401";
#endif
    
#ifndef tzt2013Protocol
    g_ntztProtocol = 2011;//通讯协议
#endif

//#ifdef Support_OpenUDID_for_MobileCode
//    NSString* strOpenUDID = [tztOpenUDID value];
//    if(validateMobile(strOpenUDID))
//    {
//        [tztKeyChain save:tztLogMobile data:strOpenUDID];
//    }
//    else
//    {
////        tztAfxMessageBox(@"获取标识码错误!");
//    }
//#else
//    [tztKeyChain save:tztLogMobile data:@""];
//#endif
    if (IS_TZTIOS(6))
    {
#ifdef UILineBreakModeWordWrap
#undef UILineBreakModeWordWrap
#endif
        
#define UILineBreakModeWordWrap NSLineBreakByWordWrapping
//#define UILineBreakModeCharacterWrap NSLineBreakByCharWrapping
    }
}

BOOL validateMobile(NSString* mobile)
{
    if(mobile == nil || [mobile length] <= 0)
        return FALSE;
//#ifdef Support_OpenUDID_for_MobileCode
    NSString *mobileRegex = @"[A-Z0-9a-z]{11,40}";
//#else
//    NSString *mobileRegex = @"[1]{1}+[0-9]{10}";
//#endif
    NSPredicate *mobileTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", mobileRegex];
    return [mobileTest evaluateWithObject:mobile];
}

NSString* tztScreenImage(NSString* imageName)
{
    NSString* strScreenEx = @"";
    NSString* strName = @"";
    NSString* strExt = @"png";
    NSRange rang = [imageName rangeOfString:@"." options:NSBackwardsSearch];
    if(rang.location == NSNotFound){
        strName = imageName;
    }else{
        strExt = [imageName substringFromIndex:NSMaxRange(rang)];
        strName = [imageName substringToIndex:rang.location];
    }
    NSString* strKey = [NSString stringWithFormat:@"tztapp_screensize_%@",tztScreenModeStrSize()];
    strScreenEx = tztAppSysValueWithDefault(strKey, @"");
    return [NSString stringWithFormat:@"%@%@.%@",strName,strScreenEx,strExt];
}

NSString* GetTitleByID(int nMsgID)
{
    return [tztActionObj getActionTitle:[NSString stringWithFormat:@"%d",nMsgID]];
}

NSString* tztdecimalNumberByDividingBy(NSString* nsValue,int nNumber)
{
    if (nsValue == NULL)
        return @"";
    if (nNumber < 0)
        nNumber = 0;
    double dValue = [nsValue doubleValue];
    
    NSDecimalNumber *multiplicandNumber = [NSDecimalNumber decimalNumberWithString:nsValue];
    NSDecimalNumber *multiplierNumber;
    NSString* nsUnit = @"";
    if (dValue >= 100000000)
    {
        multiplierNumber = [NSDecimalNumber decimalNumberWithString:@"100000000"];
        nsUnit = @"亿";
    }
    else if(dValue >= 10000)
    {
        multiplierNumber = [NSDecimalNumber decimalNumberWithString:@"10000"];
        nsUnit = @"万";
    }
    else
    {
        return nsValue;
    }
    NSDecimalNumber *product = [multiplicandNumber decimalNumberByDividingBy:multiplierNumber];
    NSString* strNew = [product stringValue];
    
    NSString* strValueReturn = @"";
    
    NSRange range = [strNew rangeOfString:@"."];
    
    if (range.location > 0 && range.location < [strNew length])
    {
        NSString *strFirst = [strNew substringToIndex:range.location];
        NSString *strSecond = [strNew substringFromIndex:range.location+1];
        
        if (strSecond.length < nNumber)
        {
            for (NSUInteger i = strSecond.length; i < nNumber; i++)
            {
                strSecond = [NSString stringWithFormat:@"%@0",strSecond];
            }
        }
        else
        {
            strSecond = [strSecond substringToIndex:nNumber];
        }
        strValueReturn = [NSString stringWithFormat:@"%@.%@%@", strFirst, strSecond, nsUnit];
    }
    else
    {
        NSString* strValid = @"";
        for (int i = 0; i < nNumber; i++)
        {
            strValid = [NSString stringWithFormat:@"%@0",strValid];
        }
        strValueReturn = [NSString stringWithFormat:@"%@.%@%@", strNew, strValid, nsUnit];
    }
    return strValueReturn;
    
}

NSString* tztRightInStringWithKey(NSString* nsSrc, NSString* nsKey, NSString* nsMainSep, NSString* nsSubSep)
{
    if (nsSrc == NULL || nsSrc.length < 1)
        return nil;
    
    NSArray *ayData = [nsSrc componentsSeparatedByString:nsMainSep];
    for (int i = 0; i < [ayData count]; i++)
    {
        NSString* str = [ayData objectAtIndex:i];
        if (str == NULL || str.length <= 0)
            continue;
        NSArray* ay = [str componentsSeparatedByString:nsSubSep];
        if (ay == NULL || ay.count < 1)
            continue;
        
        NSString* nsReturn = [ay objectAtIndex:0];
        if (nsReturn && [nsReturn caseInsensitiveCompare:nsKey] == NSOrderedSame)
        {
            if ([ay count] > 1)
                return [ay objectAtIndex:1];
        }
    }
    return nil;
}
int         g_nScreenWidth = 0;//[UIScreen mainScreen].bounds.size.width;
int         g_nScreenHeight = 0;//[UIScreen mainScreen].bounds.size.height;
int         g_nToolbarHeight = 0;
int         g_nJYBackBlackColor = 1;
int         g_nHQBackBlackColor = 1;
NSString    *g_nsdeviceToken = NULL;
int         g_nTradeListType = 0;
NSString    *g_nsPeople = NULL;
NSString    *g_nsContact = NULL;
BOOL        g_bShowLock = FALSE;
//是否显示动态口令（涨乐理财）
BOOL        g_nHaveDtPassword = FALSE;
//记录传递进来的登录账号信息
NSMutableDictionary *g_pDictLoginInfo = NULL;

NSString* g_nsUserCardID = NULL;        //资金理财身份证号码
NSString* g_nsUserInquiryPW = NULL;     //资金理财查询密码
int         g_nJyTypeCount = 1;//交易界面中类型数量
NSMutableArray      *g_ayTradeRights = NULL;//交易权限，没有权限的菜单需要隐藏
