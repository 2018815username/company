

#import "tztBarMoreView.h"

@interface tztBarMoreView()
{
    UIView      *_pSelView;
}

@end

@implementation tztBarMoreView
@synthesize pTableView  = _pTableView;
@synthesize pNineGridView = _pNineGridView;
@synthesize nPosition = _nPosition;
@synthesize fCellHeight = _fCellHeight;
@synthesize bgColor = _bgColor;
@synthesize nRowCount = _nRowCount;
@synthesize nColCount = _nColCount;
@synthesize fMenuWidth = _fMenuWidth;
@synthesize nShowType = _nShowType;
@synthesize clSeporater = _clSeporater;
@synthesize clText = _clText;
@synthesize szOffset = _szOffset;
-(id)initWithShowType:(tztBarMoreShowType)showType
{
    self = [super init];
    if (self)
    {
        self.nShowType = showType;
        [self initdata];
    }
    return self;
}
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initdata];
    }
    return self;
}

-(void)initdata
{
    self.clSeporater = [UIColor colorWithRGBULong:0x373737];
    self.clText = [UIColor colorWithRGBULong:0xC6C6C6];
}

-(void)dealloc
{
    if(_ayGrid)
    {
        [_ayGrid removeAllObjects];
        [_ayGrid release];
        _ayGrid = nil;
    }
    [super dealloc];
}

-(void)SetAyGridCell:(NSArray*)ayGridCell
{
    if (_ayGrid == NULL)
        _ayGrid = NewObject(NSMutableArray);
    
    [_ayGrid removeAllObjects];
    
    for (int i = 0; i < [ayGridCell count]; i++)
    {
        [_ayGrid addObject:[ayGridCell objectAtIndex:i]];
    }
}

-(void)setShowFrame:(CGRect)showFrame
{
    if (CGRectIsEmpty(showFrame) || CGRectIsNull(showFrame))
        return;
    if (_ayGrid == nil || [_ayGrid count] <= 0)
        return;
    if (_fCellHeight <= 10)
    {
        _fCellHeight = TZTToolBarHeight + 20;
    }
    CGRect rcFrame = showFrame;
    if (_nShowType == tztShowType_Grid)
    {
        if (_nColCount <= 0)
            _nColCount = 3;
        
        if (_nRowCount <= 0)
            _nRowCount = [_ayGrid count] / _nColCount + (([_ayGrid count]) % _nColCount == 0 ? 0 : 1);
    }
    
    if ((_nPosition & tztBarMoreBottom))
    {
        if (_nShowType == tztShowType_List)
        {
            rcFrame.origin.y += MAX(0,rcFrame.size.height - ([_ayGrid count] > 5 ? (5 * _fCellHeight) : ([_ayGrid count] * _fCellHeight)));
        }
        else
        {
            rcFrame.origin.y += MAX(0,rcFrame.size.height - _nRowCount * _fCellHeight);
        }
    }
    
    if(_nPosition & tztBarMoreRight)
    {
        rcFrame.origin.x += MAX(0,rcFrame.size.width - _fMenuWidth);
    }
    
    if (_nShowType == tztShowType_Grid)
        rcFrame.size.height = MIN(rcFrame.size.height,_nRowCount * _fCellHeight);
    else
        rcFrame.size.height = MIN(rcFrame.size.height,([_ayGrid count] > 5 ? (5 * _fCellHeight) : ([_ayGrid count] * _fCellHeight)));
    
    if (_fMenuWidth > 0)
    {
        rcFrame.size.width = MIN(rcFrame.size.width,_fMenuWidth);
    }
    
    if (_nShowType == tztShowType_Grid)
        [self setFrame_Grid:rcFrame];
    else if(_nShowType == tztShowType_List)
        [self setFrame_List:rcFrame];
}

-(void)setFrame_List:(CGRect)rcFrame
{
    if (_pSelView == NULL)
    {
        _pSelView = [[UIView alloc] init];
        _pSelView.backgroundColor = [UIColor colorWithRGBULong:0xBB2D2B];
    }
    if (_pTableView == NULL)
    {
        _pTableView = [[UITableView alloc] init];
        _pTableView.delegate = self;
        _pTableView.dataSource = self;
        _pTableView.alpha = 0.95f;
        _pTableView.backgroundColor = self.bgColor;// [UIColor colorWithRGBULong:0x434343];
        _pTableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
        _pTableView.separatorColor = self.clSeporater;//[UIColor colorWithRGBULong:0x373737];
        
        if (_nPosition == tztBarMoreTop)
        {
            CGRect rc = rcFrame;
            rc.size.height = 0;
            [self addSubview:_pTableView];
            _pTableView.frame = rc;
            [UIView beginAnimations:@"hideSelectionView" context:nil];
            [UIView setAnimationDuration:0.2f];
            [UIView setAnimationDelegate:self];
            _pTableView.frame = rcFrame;
            [_pTableView release];
            [UIView commitAnimations];
        }
        else
        {
            CGRect rc = rcFrame;
            int nHeight = rcFrame.size.height;
            rc.origin.y += nHeight;
            rc.size.height = 0;
            _pTableView.frame = rc;
            [UIView beginAnimations:@"hideSelectionView" context:nil];
            _pTableView.frame = rcFrame;
            [self addSubview:_pTableView];
            [_pTableView release];
            [UIView commitAnimations];
        }
    }
    else
    {
        _pTableView.backgroundColor = self.bgColor;
        _pTableView.frame = rcFrame;
    }
}

-(void)setFrame_Grid:(CGRect)rcFrame
{
    if (_pNineGridView == Nil)
    {
        _pNineGridView = [[tztUINineGridView alloc] init];
        _pNineGridView.clText = [UIColor blackColor];
        _pNineGridView.bIsMoreView = YES;
        _pNineGridView.tztdelegate = self;
        _pNineGridView.fCellSize = _fCellHeight;
        _pNineGridView.rowCount = _nRowCount;
        _pNineGridView.colCount = _nColCount;
        [_pNineGridView setAyCellDataAll:_ayGrid];
        [_pNineGridView setAyCellData:_ayGrid];
        if (_nPosition == tztBarMoreTop)
        {
            CGRect rc = rcFrame;
            rc.size.height = 0;
            [self addSubview:_pNineGridView];
            _pNineGridView.frame = rc;
            [UIView beginAnimations:@"hideSelectionView" context:nil];
            [UIView setAnimationDuration:0.2f];
            [UIView setAnimationDelegate:self];
            _pNineGridView.frame = rcFrame;
            [_pNineGridView release];
            [UIView commitAnimations];
        }
        else
        {
            CGRect rc = rcFrame;
            int nHeight = rcFrame.size.height;
            rc.origin.y += nHeight;
            rc.size.height = 0;
            _pNineGridView.frame = rc;
            [UIView beginAnimations:@"hideSelectionView" context:nil];
            _pNineGridView.frame = rcFrame;
            [self addSubview:_pNineGridView];
            [_pNineGridView release];
            [UIView commitAnimations];
        }    }
    else
    {
        _pNineGridView.frame = rcFrame;
    }
    _pNineGridView.alpha = 0.9f;
    if (self.bgColor)
        _pNineGridView.backgroundColor = self.bgColor;
    else
        _pNineGridView.backgroundColor = [UIColor whiteColor];

}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch *touch = [touches anyObject];
	CGPoint ptEnd = [touch locationInView:self];
    if ((_nShowType == tztShowType_Grid) && CGRectContainsPoint(_pNineGridView.frame, ptEnd))
        return;
    if ((_nShowType == tztShowType_List) && CGRectContainsPoint(_pTableView.frame, ptEnd))
        return;
    
	[self hideMoreBar];
}

-(void)RemoveView
{
    [self removeFromSuperview];
}

-(void)tztNineGridView:(id)ninegridview clickCellData:(tztNineCellData *)cellData
{
    [self hideMoreBar];
    if (_pDelegate && [_pDelegate respondsToSelector:@selector(tztNineGridView:clickCellData:)])
    {
        [_pDelegate tztNineGridView:ninegridview clickCellData:cellData];
    }
}


-(void)hideMoreBar
{
    [UIView beginAnimations:@"hideSelectionView" context:nil];
	[UIView setAnimationDuration:0.2f];
	[UIView setAnimationDelegate:self];
	[UIView setAnimationDidStopSelector:@selector(RemoveView)];
	
    UIView *pView = nil;
    if (_nShowType == tztShowType_List)
        pView = _pTableView;
    else
        pView = _pNineGridView;
    
    CGRect rcFrame = CGRectZero;
    rcFrame = pView.frame;
    
    int nHeight = rcFrame.size.height;
    rcFrame.size.height = 0;
    if (_nPosition & tztBarMoreBottom)
    {
        rcFrame.origin.y += nHeight;
    }
    
    pView.frame = rcFrame;
	[UIView commitAnimations];
    
    //点击取消，返回上个选中的tabbar，发送消息通知处理
    NSNotification* pNotifi = [NSNotification notificationWithName:TZTNotifi_HiddenMoreView object:self];
    [[NSNotificationCenter defaultCenter] postNotification:pNotifi];
}


#pragma tableviewlist

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_ayGrid count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return _fCellHeight;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString* CellIndenter = @"tztTableMenu";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIndenter];
    if (cell == nil)
    {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIndenter] autorelease];
        cell.backgroundColor = self.bgColor;
        cell.selectedBackgroundView = _pSelView;
    }
    NSString *str = [_ayGrid objectAtIndex:indexPath.row];
    NSArray *ay = [str componentsSeparatedByString:@"|"];
    if ([ay count] > 1)
    {
        NSString* strTitle = [ay objectAtIndex:1];
        cell.textLabel.textColor = self.clText;
        cell.textLabel.text = [NSString stringWithFormat:@"%@", strTitle];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.font = tztUIBaseViewTextFont(17.0f);
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger nIndex = indexPath.row;
    if (nIndex >= [_ayGrid count])
        return;
    NSString *str = [_ayGrid objectAtIndex:nIndex];
    NSArray *ay = [str componentsSeparatedByString:@"|"];
    if ([ay count] > 2)
    {
        NSString* strFuncID = [ay objectAtIndex:2];
        if (_pDelegate && [_pDelegate respondsToSelector:@selector(tztNineGridView:clickCellData:)])
        {
            tztNineCellData *cellData = NewObjectAutoD(tztNineCellData);
            cellData.cmdid = [strFuncID intValue];
            [_pDelegate tztNineGridView:nil clickCellData:cellData];
        }
    }
    [self hideMoreBar];
}
@end
