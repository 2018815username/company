//
//  tztBaseVC_LoginWeb.m
//  tztmodel
//
//  Created by yangares on 14-9-9.
//  Copyright (c) 2014年 yangares. All rights reserved.
//
#import "tztBase+Exten+web.h"
#import "tztBaseVC_LoginWeb.h"

@interface tztBaseVC_LoginWeb ()

@end

@implementation tztBaseVC_LoginWeb
@synthesize loginWebInfo = _loginWebInfo;
@synthesize tztbaseVC_web = _tztbaseVC_web;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _bHaveTabBar = FALSE;
        _nLoginType = 1;//默认交易
        _nLoginKind = 1;//默认强权限登陆
        _loginWebInfo = nil;
        _tztbaseVC_web = nil;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}
- (void)LoadLayoutView
{
    [super LoadLayoutView];
    NSString* strLoginType = [_loginWebInfo tztValueForKey:@"logintype"];
    if(strLoginType && strLoginType.length > 0)
        _nLoginType = [strLoginType intValue];
    if(_nLoginType == 0){
        [_tztTitleView setTitleLeftType:[NSString stringWithFormat:@"%d",tztBtnLogoAbout]];
        [self setTitle:@"用户登录"];
    }else{
       [_tztTitleView setTitleLeftType:[NSString stringWithFormat:@"%d",tztBtnReturn]];
        [self setTitle:@"交易登录"];
    }
    [_tztTitleView setTitleRightType:[NSString stringWithFormat:@"%d",tztBtnHide]];
    
    NSString* strURL = tztAppSysValue([NSString stringWithFormat:@"tztapp_loginurl_%d",_nLoginType]);
    if(strURL && [strURL length] > 0){
        [self setWebURL:strURL];
    }else{
        NSString* strTitle = tztAppSysValue([NSString stringWithFormat:@"tztapp_logintitle_%d",_nLoginType]);
        if(strTitle && strTitle.length > 0){
            [self setTitle:strTitle];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)OnCloseBack
{
    [super OnCloseBack];
    [self OnLoginBack];
}
- (void)OnReturnBack
{
    if (_webView && [_webView OnReturnBack])
    {
        [self setTitle:[_webView getWebTitle]];
        return;
    }
    else
    {
        [self OnCloseBack];
    }
}

- (void)OnLoginBack
{
    if(_tztbaseVC_web)
    {
        if([[tztHTTPData getShareInstance] isTztLoginOfType:[NSString stringWithFormat:@"%d",_nLoginType]]){
            NSString* strURL = [_loginWebInfo tztValueForKey:@"url"];
            if(strURL && [strURL length] > 0){
                [_tztbaseVC_web OnMsgURL:strURL];
            }else{
                NSString* strJS = [_loginWebInfo tztValueForKey:@"jsfuncname"];
                [_tztbaseVC_web OnMsgJSFun:strJS];
            }
        }
    }
}
@end
