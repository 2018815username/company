//
//  NumberKeyboard.m
//  medcalc
//
//  Created by Pascal Pfiffner on 03.09.08.
//	Copyright 2009 MedCalc. All rights reserved.
//  This sourcecode is released under the Apache License, Version 2.0
//  http://www.apache.org/licenses/LICENSE-2.0.html
//  
//  A custom keyboard that allows to input numerical values and change units
// 

#import "tztKeyboardView.h"
@interface tztKeyboardView (Private)
- (void)onButtonShift;
@end

@implementation tztKeyboardView
@synthesize textView = _textView;
@synthesize keyboardViewType = _keyboardViewType;
@synthesize tztdotvalue = _tztdotvalue;
static tztKeyboardView* keyboardviewInstance = nil;
+(tztKeyboardView *)shareKeyboardView
{
    if(keyboardviewInstance == nil)
    {
        UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
        CGRect frame;
        if(UIDeviceOrientationIsLandscape(orientation))
            frame = CGRectMake(0, 0, 480, 162);
        else
            frame = CGRectMake(0, 0, 320, 216);
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"tztStockKeyboardView" owner:self options:nil];
        if(nib && [nib count] > 0 )
        {
            keyboardviewInstance = [[nib objectAtIndex:0] retain];
            keyboardviewInstance.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"TZTKeyBoardBg.png"]];
            [keyboardviewInstance setFrame:frame];
            keyboardviewInstance.keyboardViewType = tztKeyboardViewTypeNon;
            return keyboardviewInstance;
        }
        return nil;
    }
    return keyboardviewInstance;
}

- (void) dealloc			// will never be called anyway! (Singleton)
{
    [self removeCustomButton];
	[super dealloc];
}

#pragma mark -
- (BOOL)enableInputClicksWhenVisible
{
    return YES;
}

- (IBAction)onButtonPressed:(id)sender
{
    [[UIDevice currentDevice] playInputClick];
	if (!_textView)
    {
		return;
	}
    if ([self.textView isKindOfClass:[UITextView class]])
    {
    }
    else if ([self.textView isKindOfClass:[UITextField class]])
    {
    }
    else
    {
        TZTLogError(@"textView类型:%@%@",NSStringFromClass([_textView class]),@"不支持");
        return;
    }
    UIButton* preBtn = (UIButton *)sender;
    if(preBtn.tag < 900)//文本
    {
        if ([self CanInsert:sender])
        {
            [_textView insertText:[preBtn titleLabel].text];
        }
    }
    else
    {
        switch (preBtn.tag)//功能
        {
            case 901://. 数字是否需要判断
            {
                if ([self CanInsert:sender])
                {
                    [_textView insertText:[preBtn titleLabel].text];
                }
            }
                break;
            case 902: //确定
            case 903: //隐藏
            {
                if ([self.textView isKindOfClass:[UITextView class]])
                    [(UITextView *)self.textView resignFirstResponder];
                
                else if ([self.textView isKindOfClass:[UITextField class]])
                    [(UITextField *)self.textView resignFirstResponder];
            }
                break;
            case 904: //删除
                if(_textView && [_textView respondsToSelector:@selector(deleteBackward)])
                {
                    [_textView deleteBackward];
                }
                else
                {
                    id tempTextView = _textView;
                    if([[tempTextView text] length] <= 0)
                        return;
                    NSMutableString* strText = [[NSMutableString alloc] initWithString:[tempTextView text]];
                    NSRange theRange = NSMakeRange(strText.length-1, 1);
                    [strText deleteCharactersInRange:theRange];
                    [tempTextView setText:[NSString stringWithFormat:@"%@",strText]];
                    [strText release];
                    [tempTextView setNeedsDisplay];
                }
                break;
            case 905: //shift
                break;
            case 906: //123
                break;
            case 907: //system
            case 908: //ABC
            {
                id tempTextView = _textView;
                [tempTextView setInputView:nil];
                [tempTextView reloadInputViews];
                [self addCustomButton:@"More-Key" title:@"123"];
            }
                break;
            default:
                break;
        }
    }
    
}

- (UIView *)findKeyView:(NSString *)name inView:(UIView *)view
{
	for (id subview in view.subviews)
	{
		NSString *className = NSStringFromClass([subview class]);
		if ([className isEqualToString:@"UIKBKeyView"])
		{
            if ([subview respondsToSelector:@selector(key)])
            {
                id subviewkey = [subview key];
                if([subviewkey respondsToSelector:@selector(name)])
                {
                    NSString* strKeyname = [NSString stringWithFormat:@"%@",[subviewkey name]];
                    if ((name == nil) || [name isEqualToString:strKeyname])
                    {
                        return subview;
                    }
                }
            }
		}
		else 
		{
            UIView *subview2 = [self findKeyView:name inView:subview];
            if(subview2)
                return subview2;
		}
	}
	return nil;
}


- (UIView *)findKeyView:(NSString *)name
{
	NSArray *windows = [[UIApplication sharedApplication] windows];
	if (windows.count < 2) return nil;
	return [self findKeyView:name inView:[windows objectAtIndex:1]];
}

- (void)onClick123:(id)sender
{
    if ([self.textView isKindOfClass:[UITextView class]])
    {
        UITextView * pActiveView = (UITextView *)self.textView;
        tztKeyboardView* ppKeyboard = [tztKeyboardView shareKeyboardView];
        if(ppKeyboard)
        {
            [self removeCustomButton];
            [pActiveView setInputView:ppKeyboard];
            [pActiveView reloadInputViews];
        }

    }
    else if ([self.textView isKindOfClass:[UITextField class]])
    {
        UITextField * pActiveView = (UITextField *)self.textView;
        tztKeyboardView* ppKeyboard = [tztKeyboardView shareKeyboardView];
        if(ppKeyboard)
        {
            [self removeCustomButton];
            [pActiveView setInputView:ppKeyboard];
            [pActiveView reloadInputViews];
        }
        
    }
}

- (void)removeCustomButton
{
    if(_customButton)
    {
        [_customButton removeFromSuperview];
        _customButton = nil;
    }
}

- (void)addCustomButton:(NSString *)name title:(NSString *)title
{
	UIView *view = [self findKeyView:name];
	if (view)
	{
        [self removeCustomButton];
        if (tztKeyBoardViewIsSys & _keyboardViewType)
            return;
        if(_customButton == nil)
        {
            CGFloat y = [view gettztwindowy:nil];
            CGFloat x = [view gettztwindowx:nil];
            _customButton = [[UIButton alloc] initWithFrame:CGRectMake(x, y, view.frame.size.width, view.frame.size.height)];
            [_customButton addTarget:self action:@selector(onClick123:) forControlEvents:UIControlEventTouchUpInside];
            [view.window addSubview:_customButton];
            [_customButton release];
        }
	}
}

-(void)setKeyboardViewType:(tztKeyboardViewType)keyboardViewType
{
    _keyboardViewType = keyboardViewType;
    UIButton* pBtnABC = (UIButton*)[self viewWithTag:908];
    if ((tztKeyboardViewNOABC & _keyboardViewType))
    {
        pBtnABC.enabled = FALSE;
    }
    else
    {
        pBtnABC.enabled = TRUE;
    }
    
    UIButton* pBtnDot = (UIButton*)[self viewWithTag:901];
    if ((tztKeyboardViewNODot & _keyboardViewType))
    {
        pBtnDot.enabled = FALSE;
    }
    else
    {
        pBtnDot.enabled = TRUE;
    }
}

//输入判断
-(BOOL)CanInsert:(id)sender
{
    if (!_textView)
    {
		return NO;
	}
    
    UIButton *pBtn = (UIButton*)sender;
    NSString* nsValue = nil;
    if ([self.textView isKindOfClass:[UITextView class]])
    {
        nsValue = ((UITextView*)self.textView).text;
    }
    else if ([self.textView isKindOfClass:[UITextField class]])
    {
        nsValue = ((UITextField*)self.textView).text;
    }
    else
    {
        TZTLogError(@"textView类型:%@%@",NSStringFromClass([_textView class]),@"不支持");
        return NO;
    }
    
    //纯数值判断比较
    if (tztKeyboardViewIsNumber & _keyboardViewType)
    {
        //输入(.)
        if (pBtn.tag == 901)//判断是否已经输入过(.)，输入过后，不可重复输入
        {
            return (0 == [nsValue rangeOfString:@"."].length);
        }
        if ([nsValue rangeOfString:@"."].length > 0)//已经输入过小数点
        {
            int nCount = 10;
//            if (self.tztdotvalue < 1)//
//            {
//                nCount = 1;
//            }
//            else
//            {
//                for (int i = 1; i < self.tztdotvalue; i++)
//                {
//                    nCount *= 10;
//                }
//            }
            //格式化
            NSString* nsFormat = nil;
            //根据小数点跟个字符串，然后操作
            NSArray *ay = [nsValue componentsSeparatedByString:@"."];
            NSString* strFirst = [ay objectAtIndex:0];
            int nNum = [[ay objectAtIndex:0] intValue];//小数点前的数值
            NSString* str = [ay objectAtIndex:1];
            if (str && [str length] > 0)//小数点后已经输入过值了
            {
                if ([str length] >= self.tztdotvalue)//超过了允许的小数点位数，不可输入
                    return NO;
                
                //字符串追加需要输入的数字
                str = [NSString stringWithFormat:@"%@%@", str, [pBtn titleLabel].text];
                if ([str length] >= self.tztdotvalue)//超过截断
                {
                    str = [str substringToIndex:self.tztdotvalue];
                }
                //int nsub = [str intValue];
                //取当前的长度和小数点位数判断，取小的进行格式化
                nsFormat = [NSString stringWithFormat:@"%%.%df",MIN(self.tztdotvalue, [str length])];
                //重新计算当前的小数点位数
                nCount = 10;
                for (int i = 1; i < MIN(self.tztdotvalue, [str length]); i++)
                {
                    nCount *= 10;
                }
                //生成新的
                nsValue = [NSString stringWithFormat:@"%@.%@", strFirst, str];
//                nsValue = [NSString stringWithFormat:nsFormat, (float)(nNum + ((float)nsub/nCount))];
            }
            else
            {
                NSString* title = [pBtn titleLabel].text;
                if ([title length] >= self.tztdotvalue)
                {
                    title = [title substringToIndex:self.tztdotvalue];
                }
                int nsub = [title intValue];
                //没有输入过小数点后的数值，则认为是第一个
                nCount = 10;
                for (int i = 1; i < MIN(self.tztdotvalue, [title length]); i++)
                {
                    nCount *= 10;
                }
                nsFormat = [NSString stringWithFormat:@"%%.%df",MIN(self.tztdotvalue, [title length])];
                nsValue = [NSString stringWithFormat:nsFormat, (float)(nNum + ((float)nsub/nCount))];
                nsValue = [NSString stringWithFormat:@"%@.%@", strFirst, title];
            }
        }
        else//没有小数点，则直接输入拼接，去掉开始的0
        {
            nsValue = [NSString stringWithFormat:@"%@%@", nsValue, [pBtn titleLabel].text];
            
            while ([nsValue hasPrefix:@"0"] && [nsValue length] > 0)
            {
                nsValue = [nsValue substringFromIndex:1];
            }
        }
        if ([self.textView isKindOfClass:[UITextView class]])
        {
            [(UITextView*)self.textView setText:nsValue];
            return NO;
        }
        else if ([self.textView isKindOfClass:[UITextField class]])
        {
            [(UITextField*)self.textView setText:nsValue];
            NSNotification* pNotifi = [NSNotification notificationWithName:UITextFieldTextDidChangeNotification object:self.textView];
            [[NSNotificationCenter defaultCenter] postNotification:pNotifi];
            return NO;
        }
    }
    return TRUE;
}

@end