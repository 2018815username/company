//
//  tztUILable.m
//  tztMobileApp
//
//  Created by yangdl on 13-2-22.
//  Copyright (c) 2013年 投资堂. All rights reserved.
//

#import "tztUILabel.h"

@implementation tztUILabel
@synthesize tzttagcode = _tzttagcode;

- (id)init
{
    self = [super init];
    if(self)
    {
        [self setProperty:@""];
    }
    return self;
}

- (id)initWithProperty:(NSString*)strProperty withCellWidth_:(float)fWidth
{
    _fCellWidth = fWidth;
    return [self initWithProperty:strProperty];
}

- (id)initWithProperty:(NSString*)strProperty
{
    self = [super init];
    if(self)
    {
        [self setProperty:strProperty];
    }
    return self;
}

//;tag|区域|contentMode|numberOfLines|text|textAlignment|font|enabled|
- (void)setProperty:(NSString*)strProperty
{
    NSString* strRect = @",,,";
    NilObject(self.tzttagcode);
    _insets = UIEdgeInsetsMake(0,0,0,0);
    self.backgroundColor = [UIColor clearColor];
    self.textColor = [UIColor blackColor];
    self.font = tztUIBaseViewTextFont(0);
    self.contentMode = UIViewContentModeCenter;
    //int nHeight = 0;
    if(strProperty && [strProperty length] > 0)
    {
        NSMutableDictionary* Property = NewObject(NSMutableDictionary);
        [Property settztProperty:strProperty];
        //tag
        NSString* strValue = [Property objectForKey:@"tag"];
        if(strValue && [strValue length] > 0)
            self.tzttagcode = strValue;
        
        //区域
        strValue = [Property objectForKey:@"rect"];
        if(strValue && [strValue length] > 0)
            strRect = strValue;
        
        //行数
        strValue = [Property objectForKey:@"lines"];
        if(strValue && [strValue length] > 0)
        {
            self.numberOfLines = [strValue intValue];
        }
        
        strValue = [Property objectForKey:@"backgroundcolor"];
        if (strValue && [strValue length] > 0)
        {
            self.backgroundColor = [UIColor colorWithTztRGBStr:strValue];
        }
        
        //text
        self.text = [Property objectForKey:@"text"];
        
        //textcolor
        strValue = [Property objectForKey:@"textcolor"];
        if(strValue && [strValue length] > 0)
        {
            self.textColor = [UIColor colorWithTztRGBStr:strValue];
        }
        //textAlignment
        strValue = [Property objectForKey:@"textalignment"];
        if(strValue && [strValue length] > 0)
        {
            if([strValue compare:@"right"] == NSOrderedSame)
            {
                self.textAlignment = NSTextAlignmentRight;
            }
            else if([strValue compare:@"center"] == NSOrderedSame)
            {
                self.textAlignment = NSTextAlignmentCenter;
            }
            else 
            {
                self.textAlignment = NSTextAlignmentLeft;
            }
        }
        
        //font
        strValue = [Property objectForKey:@"font"];
        if(strValue && [strValue length] > 0) //设置字体大小
        {
            CGFloat fontsize = [strValue floatValue];
            self.font = tztUIBaseViewTextFont(fontsize);
        }

        //enabled
        strValue = [Property objectForKey:@"enabled"];
        if(strValue && [strValue length] > 0)
        {
            self.enabled = ([strValue intValue] != 0);
        }

        //adjustsFontSizeToFitWidth
        strValue = [Property objectForKey:@"adjustsfontsizetofitwidth"];
        if(strValue && [strValue length] > 0) //设置区域
        {
            self.adjustsFontSizeToFitWidth = ([strValue intValue] != 0);
            if(self.adjustsFontSizeToFitWidth)
                self.numberOfLines = 1;
        }
        DelObject(Property);
    }
    
    if(strRect && [strRect length] > 0)
    {
        CGRect frame = CGRectMaketztNSString(strRect,tztUIBaseViewBeginBlank,tztUIBaseViewOrgY,90.f,tztUIBaseViewHeight,_fCellWidth,tztUIBaseViewTableCellHeight);
        [self setFrame:frame];
    }

}

- (void)dealloc
{
    NilObject(self.tzttagcode);
    [super dealloc];
}

#pragma tztUIBaseViewDelegate
- (NSString*)gettztUIBaseViewValue;
{
    return self.text;
}

- (void)settztUIBaseViewValue:(NSString*)strValue
{
    self.text = strValue;
}

- (void)setUIEdgeInsets:(UIEdgeInsets)insets
{
    _insets = insets;
}

- (void)drawTextInRect:(CGRect)rect
{
    return [super drawTextInRect:UIEdgeInsetsInsetRect(rect, _insets)];
}
@end
