//
//  tztBaseVC_Web.m
//  tztmodel
//
//  Created by yangares on 14-9-3.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC_Web.h"
#import "tztStockInfo.h"
#import "tztAppInit.h"
#import "tztTabBarView.h"
#import "tztUINineGridView.h"
#import "tztBarMoreView.h"
#import "tztBaseVC_LoginWeb.h"
#import "tztBaseSetViewController.h"
#import <tztMobileBase/tztNSLocation.h>
#import "TZTUIMessageBox.h"
#ifdef TZTShare
#import "TZTShareObject.h"
#endif

@interface tztBaseWebView ()
@end

@implementation tztBaseWebView

- (tztHTTPWebViewLoadType)ontztWebURL:(UIWebView*)tztWebView strURL:(NSString *)strUrl WithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    tztHTTPWebViewLoadType loadType =tztHTTPWebViewTrue | tztHTTPWebViewContinue;
    NSString* strUrllower = [strUrl lowercaseString];
    if ( [strUrllower hasPrefix:@"http://tel:"] )
    {
        NSString* strTelCode = [strUrl substringFromIndex:[@"http://tel:" length]];
        NSString* strTelPhone = [NSString stringWithFormat:@"%@",strTelCode];
        [_tztDelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",HQ_MENU_TztTelPhone] withObject:strTelPhone];
        return tztHTTPWebViewFalse | tztHTTPWebViewBreak;
    }
    else if ( [strUrllower hasPrefix:@"tel:"] )
    {
        NSString* strTelCode = [strUrl substringFromIndex:[@"tel:" length]];
        NSString* strTelPhone = [NSString stringWithFormat:@"%@",strTelCode];
        [_tztDelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",HQ_MENU_TztTelPhone] withObject:strTelPhone];
        return tztHTTPWebViewFalse | tztHTTPWebViewBreak;
    }
    else if ( [strUrllower hasPrefix:@"http://stock:"] )
    {
        NSString* strStockCode = [strUrl substringFromIndex:[@"http://stock:" length]];
        if(strStockCode && [strStockCode length] > 0)
        {
            tztStockInfo* pStock = NewObject(tztStockInfo);
            pStock.stockCode = strStockCode;
            [_tztDelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",HQ_MENU_Trend] withObject:pStock];
            [pStock release];
        }
        return tztHTTPWebViewFalse | tztHTTPWebViewBreak;
    }
    else if ( [strUrllower hasPrefix:tztHTTPAction] )
    {
        NSString* strAction = [strUrl substringFromIndex:[tztHTTPAction length]];
        if(strAction && [strAction length] > 0)
        {
            [_tztDelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",ID_MENU_ACTION] withObject:strAction];
        }
        return tztHTTPWebViewFalse | tztHTTPWebViewBreak;
    }
    return loadType;
}

//设置网页地址
- (void)setWebURL:(NSString *)strURL
{
    if (strURL== NULL || strURL.length <= 0){
        strURL = @"/";
    }
    self.strURL = [tztlocalHTTPServer getLocalHttpUrl:strURL];
    [super setWebURL:self.strURL];
}

- (void)setLocalWebURL:(NSString*)strURL
{
    NSURL* url = [NSURL URLWithString:strURL];
    self.strURL = [NSString stringWithFormat:@"%@", url];
    [super setLocalWebURL:self.strURL];
}
@end


typedef enum tztWebURLType
{
	tztWebURL = 0,//普通模式
	tztWebHTML = 1, //上下模式
	tztWebLocalURL = 2, //左右模式
}tztWebURLType;

@interface tztBaseVC_Web ()
{
    tztWebURLType _nURLType;
    CGFloat v_titleHeight;
    CGFloat v_tabbarHeight;
    int _nLeftType;
    int _nRightType;
}
- (void)tztNineGridView:(id)nineGridView clickCellData:(tztNineCellData *)cellData;
@end

@implementation tztBaseVC_Web
@synthesize strURL = _strURL;
@synthesize webInfo = _webInfo;
@synthesize webView = _webView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        _nURLType = tztWebURL;
        _bHaveTitle = TRUE;
        _bHaveTabBar = TRUE;
    }
    return self;
}

- (void)dealloc{
    DelObject(_webInfo);
    [super dealloc];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)OnRootView
{
    if (_webView) {
        [_webView returnRootWebView];
        [self setURL];
    }
}
//页面信息
- (void)setWebInfo:(NSMutableDictionary*)webInfo
{
    DelObject(_webInfo);
    if(webInfo){
        _webInfo = [webInfo retain];
        NSString* strRightType = [_webInfo tztObjectForKey:@"secondtype"];
        if (strRightType == NULL || strRightType.length <= 0)
            strRightType = [_webInfo tztObjectForKey:@"type"];
        if (strRightType != NULL)
            [_webInfo setValue:strRightType forKey:@"secondtype"];
    }
}

- (void)setURL
{
    if (self.strURL)
    {
        switch (_nURLType) {
            case tztWebURL:
            {
                [self setWebURL:self.strURL];
            }
                break;
            case tztWebHTML:
            {
                [_webView LoadHtmlData:self.strURL];
            }
                break;
            case tztWebLocalURL:
            {
                [_webView setLocalWebURL:self.strURL];
            }
                break;
            default:
                break;
        }
        
    }
}

- (void)setWebURL:(NSString *)strURL
{
    _nURLType = tztWebURL;
    self.strURL = [NSString stringWithFormat:@"%@",strURL];
    [self OnMsgURL:self.strURL];
//    if (_webView)
//    {
//        [_webView setWebURL:self.strURL];
//    }
}

//直接加载静态网页格式
-(void)LoadHtmlData:(NSString*)nsHTML
{
    _nURLType = tztWebHTML;
    self.strURL = [NSString stringWithFormat:@"%@", nsHTML];
    NSString* str = [NSString stringWithFormat:@"tzthtml_%d",g_nSkinType];
    NSString* strPath = GetTztBundlePath(str,@"html",@"plist");
    if(strPath == NULL || [strPath length] <= 0){
        strPath = GetTztBundlePath(@"tzthtml_0", @"html", @"plist");
    }
    
    if(strPath && [strPath length] > 0)
    {
        NSString* strtztHtml = [NSString stringWithContentsOfFile:strPath encoding:NSUTF8StringEncoding error:nil];
        if(strtztHtml && [strtztHtml length] > 0)
            self.strURL = [NSString stringWithFormat:strtztHtml,self.title, nsHTML];
    }
    if (_webView)
    {
        [_webView LoadHtmlData:self.strURL];
    }
}

- (void)setLocalWebURL:(NSString*)strURL
{
    _nURLType = tztWebLocalURL;
    self.strURL = [NSString stringWithFormat:@"%@",strURL];
    if (_webView)
    {
        [_webView setLocalWebURL:self.strURL];
    }
}

#pragma tztHTTPWebViewDelegate
- (void)tztWebView:(tztHTTPWebView *)webView withTitle:(NSString *)title
{
    if(_webView && webView == _webView)
    {
        if(_webInfo){
            if(_nRightType == tztBtnFont){
                NSString* strFile = @"tztFontSize";
                NSString* strURL = [strFile tztHttpfilepath];
                NSString* str = [NSString stringWithContentsOfFile:strURL encoding:NSUTF8StringEncoding error:nil];
                if (str && str.length > 0)
                {
                    [_webView tztStringByEvaluatingJavaScriptFromString:str];
                }
            }else if(_nRightType == tztBtnUserIcon && _tztTitleView){
                [_tztTitleView setRightBtnText:[_webInfo tztObjectForKey:@"secondtext"]];
            }
        }
        if(title == NULL || title.length <= 0){
            title = tztAppSysValue(@"tztapp_title");
        }
        [self setTitle:title];
    }
}

- (BOOL)tztWebViewCanGoBack:(tztHTTPWebView *)webView
{
    if (webView == _webView)
    {
        if ([webView canReturnBack]  && _tztTitleView && (_nLeftType == tztBtnHide || _nLeftType == tztBtnLogoAbout))
        {
            [_tztTitleView replaceTitleLeftType:_nLeftType with:tztBtnReturn];
        }else if(_nLeftType == tztBtnHide || _nLeftType == tztBtnLogoAbout){
            [_tztTitleView replaceTitleLeftType:tztBtnReturn with:_nLeftType];
        }
    }
    return NO;
}

- (BOOL)tztWebViewIsRoot:(tztHTTPWebView*)webView
{
    NSString* vcShowType = [self getVcShowType];
    if ([vcShowType intValue] == tztVcShowTypeRoot)
        return TRUE;
    return FALSE;
}

-(void)CleanWebURL
{
    if (_webView)
    {
        CGRect webRect = _webView.frame;
        [_webView removeFromSuperview];
        _webView = NULL;
        
        _webView = [[tztBaseWebView alloc] initWithFrame:webRect];
        _webView.tztDelegate = self;
        [self.view addSubview:_webView];
        Obj_RELEASE(_webView);
    }
}

- (BOOL)IsHaveWebView
{
    if (_webView)
        return [_webView IsHaveWebView];
    return FALSE;
}

- (void)LoadLayoutView
{
    CGRect rcFrame = tztScreenBounds();
    if (CGRectIsEmpty(rcFrame) || CGRectIsNull(rcFrame))
        return;
    [super LoadLayoutView];
    [_tztTitleView setTitleShowType:tztTitleNormal];
    if(_webInfo)
    {
        NSString* strRightType = [_webInfo tztObjectForKey:@"secondtype"];
        if (strRightType == NULL || strRightType.length <= 0)
            strRightType = [_webInfo tztObjectForKey:@"type"];
        [_webInfo setValue:strRightType forKey:@"secondtype"];
        [_tztTitleView setTitleRightType:strRightType];
        NSString* strLeftType = [_webInfo tztObjectForKey:@"firsttype"];
        [_tztTitleView setTitleLeftType:strLeftType];
        
        _nLeftType = [_tztTitleView getTitleLeftType];
        _nRightType = [_tztTitleView getTitleRightType];
    }
   
    if(_webInfo){
        NSString* strLeftText = [_webInfo tztObjectForKey:@"firsttext"];
        [_tztTitleView setLeftBtnText:strLeftText];
        NSString* strRightText = [_webInfo tztObjectForKey:@"secondtext"];
        [_tztTitleView setRightBtnText:strRightText];
        NSString* strLeftUrl = [_webInfo tztObjectForKey:@"firsturl"];
        NSString* strLeftJS = [_webInfo tztObjectForKey:@"firstjsfuncname"];
        [_tztTitleView setLeftUrl:strLeftUrl jsfun:strLeftJS];
        
        NSString* strRightUrl = [_webInfo tztObjectForKey:@"secondurl"];
        NSString* strRightJS = [_webInfo tztObjectForKey:@"secondjsfuncname"];
        [_tztTitleView setRightUrl:strRightUrl jsfun:strRightJS];
        NSString* strFullScreen = [_webInfo tztObjectForKey:@"fullScreen"];
        if(strFullScreen){
            _bHaveTabBar = ([strFullScreen intValue] == 0);
        }
    }
    [_tztTitleView setTitle:self.title];
    _tztTitleView.hidden = (!_bHaveTitle);
    rcFrame.origin = CGPointZero;
    if(_bHaveTitle){
        rcFrame.origin.y += CGRectGetHeight(_tztTitleView.frame);
        rcFrame.size.height -= CGRectGetHeight(_tztTitleView.frame);
    }
    
    if (_bHaveTabBar)
        rcFrame.size.height -=  48;
#ifdef __IPHONE_7_0
    if(IS_TZTIOS(7))
    {
        
    }else
#endif
    {
        rcFrame.size.height -=  tztStatusBarHeight();
    }
    if (_webView == nil)
    {
        _webView = [[tztBaseWebView alloc] initWithFrame:rcFrame];
        _webView.clBackground = [UIColor whiteColor];
        _webView.bblackground = FALSE;
        _webView.bScalesPageToFit = YES;
//      _webView.multipleTouchEnabled = YES;
//      _webView.delegate = self;
        _webView.tztDelegate = self;
        [self.view addSubview:_webView];
        [self setURL];
        Obj_RELEASE(_webView);
    }
    else
        _webView.frame = rcFrame;
    
}

- (void)OnMsg:(NSString*)strMsgID withObj:(id)obj
{
    if(strMsgID == NULL || [strMsgID length] <= 0)
        return;
    int nMsgID = [strMsgID intValue];
    switch (nMsgID) {
        case ID_MENU_ACTION://AjaxAction功能
        {
            NSString* strAction = (NSString *)obj;
            NSString* strKey;
            NSString* strValue;
            [strAction tzthttpKeyValue:&strKey value:&strValue SeparatedByString:@"?"];
            [self OnAjaxMsg:[strKey intValue] withParams:[NSString stringWithFormat:@"%@",strValue]];
        }
            break;
        case HQ_MENU_Trend://分时
        {
            tztStockInfo* pStock = (tztStockInfo *)obj;
            NSLog(@"%@",pStock);
        }
            break;
        case HQ_MENU_TztTelPhone: //拨打电话
        {
            NSString* strTel = (NSString *)obj;
            [self OnShowPhoneList:strTel];
        }
            break;
        case TZT_MENU_OnPrev://前一条、前一页
        case TZT_MENU_OnNext://后一条、后一页
            break;
        default:
        {
            
        }
            break;
    }
}

- (void)OnAjaxMsg:(int)nAction withParams:(NSString*)strParams
{
    UINavigationController* navVC = self.navigationController;
    NSMutableDictionary* pDict = nil;
    if(strParams && [strParams length] > 0)
    {
        pDict = (NSMutableDictionary*)[strParams tztNSMutableDictionarySeparatedByString:tztHTTPStrSep decodeurl:TRUE];
    }
    switch (nAction) {
        case AJAX_MENU_CloseCurWeb://关闭当前页面 1964
        {
            NSString* strURL = [pDict tztValueForKey:@"url"];
            if(strURL == NULL || [strURL length] <= 0){
                [self OnMsgURL:strParams];
            }else{
                [self onSetWebDict:pDict];
            }
        }
            break;
        case MENU_SYS_UpdataVersion: //系统浏览器打开URL 10330
        {
            NSString* url = [pDict tztObjectForKey:@"url"];
            tztOpenURL(url);
        }
            break;
        case TZT_MENU_Return://返回前一页面 10002
        {
            [self tztMsgBoxBlock:pDict block:^{
                [self OnReturnBack];
            }];
        }
            break;
        case TZT_MENU_GetGPSLocation://10062 获取GPS位置，打开指定的URL
        {
            if (pDict == NULL)
                return;
            NSString* strURL = [pDict tztObjectForKey:@"url"];
            [[tztNSLocation getShareClass] getLocation:^(NSString *strGpsX, NSString *strGpsY) {
                
                NSString* strGPSXURL = [strURL stringByReplacingOccurrencesOfString:@"($tztgpsx)" withString:strGpsX];
                NSString* strGPSURL = [strGPSXURL stringByReplacingOccurrencesOfString:@"($tztgpsy)" withString:strGpsY];
                [self OnMsgURL:strGPSURL];
            }];
            return;
            
        }
            break;
        case TZT_MENU_Share: // 10055分享
        {
#ifdef TZTShare
            NSString* strShareType = [pDict tztObjectForKey:@"sharetype"];
            int nType = 0;
            if (strShareType && strShareType.length > 0)
                nType = [strShareType intValue];
            UIView *viewWindow = [[UIApplication sharedApplication] keyWindow];
            [TZTShareObject addShareViewin:viewWindow withDelegate:(id)self andInfo:(NSMutableDictionary*)pDict andType_:nType];
#else
            tztAfxMessageBox(@"暂不支持分享功能!");
#endif
        }
            break;
        case AJAX_MENU_CloseAllWeb://3413 关闭当前流程
        {
            [self tztMsgBoxBlock:pDict block:^{
                [self OnCloseBack];
            }];
        }
            break;
        case MENU_SYS_UserLogout:
        {
            [self tztMsgBoxBlock:pDict block:^{
                NSString* strAccount = [tztKeyChain load:tztLogMobile];
                NSString* strLoginType = [pDict tztValueForKey:@"logintype"];
                [[tztAppInit sharedtztAppInit] tztUniqueidLogout:strAccount branch:@""];
                [[tztHTTPData getShareInstance] tztperformSelector:@"clearTztLoginOfType:" withObject:strLoginType];
//                [tztKeyChain save:tztLogMobile data:@""];
                [[tztAppInit sharedtztAppInit] onRootTab:0];
            }];
        }
            break;
        case TZT_MENU_WebLogin://登录
        {
            NSString* strLoginClass = @"";
            NSString* strLoginType = [pDict tztValueForKey:@"logintype"];
            //强权限登录
            if(strLoginType && strLoginType.length > 0 && strLoginType.intValue == 1){
                strLoginClass = tztAppSysValueWithDefault(@"tztapp_tradeloginclass", @"tztBaseVC_LoginWeb");
            }else{ //弱权限登录
                strLoginClass = tztAppSysValueWithDefault(@"tztapp_sysloginclass", @"tztBaseVC_LoginWeb");
            }
            if([[tztHTTPData getShareInstance] tztperformSelector:@"isTztLoginOfType:" withObject:strLoginType]){
                NSString* strLogOut = [pDict tztValueForKey:@"logout"];
                if(strLogOut && [strLogOut intValue] > 0){
                    [self OnAjaxMsg:MENU_SYS_UserLogout withParams:strParams];
                }else{
                    [self onSetWebDict:pDict];
                }
            }
            else if(navVC && pDict)
            {
                Class loginclass = NSClassFromString(strLoginClass);
                id pLoginVC = [[loginclass alloc]init];
                if(pLoginVC == nil)
                {
                    TZTLogErrorUp(@"%@ alloc 错误",strLoginClass);
                }
                tztBaseVC_LoginWeb * pNewVC = (tztBaseVC_LoginWeb *)pLoginVC;
                [pNewVC SetHidesBottomBarWhenPushed:TRUE];
                pNewVC.tztbaseVC_web = self;
                pNewVC.loginWebInfo = pDict;
                [navVC pushViewController:pNewVC animated:FALSE];
                [pNewVC release];
            }
        }
            break;
        case TZT_TabBar_Status://1901 更新TabBar图标
        {
            NSString* nsFileName = tztTabbarStatusFile;
            NSString* strPath = [nsFileName tztHttpfilepath];
            NSError *error = nil;
            [pDict writeToFile:strPath atomically:YES];
            if (error)
            {
                TZTLogInfo(@"Action:1901,写文件出错，原因：%@",[error description]);
            }
            else
            {
                if (g_ptztTabBarView)
                    [g_ptztTabBarView ReloadToolBar:@""];
            }
        }
            break;
        case TZT_TabBar_Property://1902 更新TabBar属性
        {
            NSString* nsFileName = tztTabbarPropertyFile;
            NSString* strPath = [nsFileName tztHttpfilepath];
            NSError *error = nil;
            [pDict writeToFile:strPath atomically:YES];
            if (error)
            {
                TZTLogInfo(@"Action:1902,写文件出错，原因：%@",[error description]);
            }
            else
            {
                if (g_ptztTabBarView)
                    [g_ptztTabBarView ReloadToolBar:@""];
            }
        }
            break;
        case TZT_MENU_OpenWebInfoContent://10061 打开一个新流程
        {
            if(navVC && pDict)
            {
                NSString* url = [pDict tztObjectForKey:@"url"];
                if (url == NULL || url.length <= 0)
                    return;
                tztBaseVC_Web * pNewVC = (tztBaseVC_Web *)[tztBaseVC_Web tztAllocWebVC];
                NSString* strFullScreen = [pDict tztValueForKey:@"fullScreen"];
                if(strFullScreen == NULL || strFullScreen.length <= 0)
                    strFullScreen = @"0";
                [pNewVC SetHidesBottomBarWhenPushed:[strFullScreen intValue]];
                [pNewVC setWebInfo:pDict];
                [pNewVC setWebURL:url];
                [navVC pushViewController:pNewVC animated:FALSE];
                [pNewVC release];
            }
        }
            break;
        case TZT_MENU_Main://第一个Tab页
        case TZT_MENU_Market://第二个Tab页
        case TZT_MENU_Info://第三个Tab页
        case TZT_MENU_Trade://第四个Tab页
        case TZT_MENU_Set://第五个Tab页
        {
            [[tztAppInit sharedtztAppInit] onRootTab:(nAction-TZT_MENU_Main)];
        }
            break;
        case MENU_SYS_SerAddSet:
        {
            tztBaseSetViewController *pVC = NewObject(tztBaseSetViewController);
            [pVC SetHidesBottomBarWhenPushed:TRUE];
            pVC.nMsgType = nAction;
            [navVC pushViewController:pVC animated:UseAnimated];
            [pVC release];
        }
            break;
        default:
        {
            
        }
            break;
    }
}

- (void)onSetWebDict:(NSMutableDictionary*)pDict
{
    NSString* strURL = [pDict tztValueForKey:@"url"];
    if(strURL && [strURL length] > 0){
        [self OnMsgURL:strURL];
    }else{
        NSString* strJS = [pDict tztValueForKey:@"jsfuncname"];
        if(strJS && strJS.length > 0)
            [self OnMsgJSFun:strJS];
    }
}

- (void)OnReturnBack
{
    if (_webView && [_webView OnReturnBack])
    {
        [self setTitle:[_webView getWebTitle]];
        return;
    }
    else
    {
        [super OnReturnBack];
    }
}

- (void)OnMsgURL:(NSString*)strURL
{
    if (strURL && [[strURL lowercaseString] hasPrefix:tztHTTPAction] ) //处理action
    {
        strURL = [strURL substringFromIndex:[tztHTTPAction length]];
        NSString* strKey;
        NSString* strValue;
        [strURL tzthttpKeyValue:&strKey value:&strValue SeparatedByString:@"?"];
        int nAction = [strKey intValue];
        if(nAction == AJAX_MENU_CloseCurWeb && _webView){
            [_webView closeCurHTTPWebView];
        }
        [self OnAjaxMsg:nAction withParams:strValue];
    }else if(_webView){
        [_webView setWebURL:strURL];
    }
}

- (void)OnMsgJSFun:(NSString*)strJSFun
{
    if(strJSFun && [strJSFun length] > 0){
        NSString* strJS = [strJSFun tztencodeURLString];
        [_webView tztStringByEvaluatingJavaScriptFromString:strJS];
    }
}

//显示字体
- (void)OnMsgFont
{
    tztBarMoreView *pMoreView = (tztBarMoreView*)[self.view viewWithTag:0x7878];
    if (pMoreView == NULL)
    {
        CGRect webRect = _webView.frame;
        NSMutableArray *pAy = NewObjectAutoD(NSMutableArray);
        [pAy addObject:@"tztFontSmall.png||75|"];
        [pAy addObject:@"tztFontMiddle.png||100|"];
        [pAy addObject:@"tztFontBig.png||125|"];
        pMoreView = NewObject(tztBarMoreView);
        pMoreView.frame = tztScreenBounds();
        [self.view.window addSubview:pMoreView];
        [self.view.window bringSubviewToFront:pMoreView];
        pMoreView.tag = 0x7878;
        pMoreView.nPosition = tztBarMoreTop;
        pMoreView.fCellHeight = 40;
        [pMoreView SetAyGridCell:pAy];
        pMoreView.pNineGridView.nsBackImage = @"tztTitlebg.png";
        pMoreView.bgColor = [UIColor colorWithPatternImage:[UIImage imageTztNamed:@"tztTitlebg.png"]];
        [pMoreView setShowFrame:webRect];
        pMoreView.pDelegate = self;
        Obj_RELEASE(pMoreView);
    }
    else
    {
        [pMoreView removeFromSuperview];
    }
}

-(void)tztNineGridView:(id)nineGridView clickCellData:(tztNineCellData *)cellData
{
    if (cellData == NULL)
        return;
    
    int nSize = cellData.cmdid;
    if (nSize < 75 || nSize > 125)
        nSize = 100;
    NSString* str = [NSString stringWithFormat:@"document.getElementsByTagName('body')[0].style.webkitTextSizeAdjust= '%d%%'", nSize];
    
    NSString* strJS = [str tztencodeURLString];
    [_webView tztStringByEvaluatingJavaScriptFromString:strJS];
}

- (void)tztMsgBoxBlock:(NSMutableDictionary*)pDict block:(void (^)(void))block
{
    NSString* strCloseContent = [pDict tztValueForKey:@"content"];
    if(strCloseContent && strCloseContent.length > 0){
        NSString* strCloseTitle = [pDict tztValueForKey:@"title"];
        tztAfxMessageBlock(strCloseContent, strCloseTitle, nil, TZTBoxTypeButtonBoth, ^(NSInteger buttonIndex) {
            if(buttonIndex == 0)
            {
                block();
            }
        });
    }else{
        block();
    }
}

+ (id)tztAllocWebVC
{
    NSString* strWebClass = tztAppStringValue(@"tztapphttp",@"tztapp_httpwebclass", @"tztBaseVC_Web");
    Class webvcclass = NSClassFromString(strWebClass);
    id pWebVC = [[webvcclass alloc]init];
    if(pWebVC == nil)
    {
        TZTLogErrorUp(@"%@ alloc 错误",strWebClass);
    }
    return pWebVC;
}

- (void)tztStringByEvaluatingJavaScriptFromString:(NSString*)strJs
{
    if (_webView && strJs.length > 0)
    {
        [_webView tztStringByEvaluatingJavaScriptFromString:strJs];
    }
}
@end
