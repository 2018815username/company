//
//  tztBaseVC.m
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC.h"
#import "tztBaseTitleView.h"
#import "tztAppInit.h"

@interface tztBaseVC ()

@end

@implementation tztBaseVC
@synthesize tztTitleView = _tztTitleView;
@synthesize tztTitle = _tztTitle;
@synthesize nMsgType = _nMsgType;
@synthesize nTabBarVC = _nTabBarVC;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self LoadLayoutView];
//    [self.view bringSubviewToFront:_tztTitleView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)LoadLayoutView
{
    if(_tztTitleView == NULL){
        _tztTitleView = NewObject(tztBaseTitleView);
        _tztTitleView.tztdelegate = self;
        [self.view addSubview:_tztTitleView];
        Obj_RELEASE(_tztTitleView);
    }
#ifdef __IPHONE_7_0
    if (IS_TZTIOS(7)) {
        _tztTitleView.frame = CGRectMake(0, 0, self.view.frame.size.width, 44+tztStatusBarHeight());
    }else
#endif
    {
        _tztTitleView.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
    }
    [_tztTitleView initSubView];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setTitle:(NSString *)title
{
    //[super setTitle:title];
    self.tztTitle = [NSString stringWithFormat:@"%@",title];
    if (title && [title length] > 0)
    {
        if(_tztTitleView)
        {
            [_tztTitleView setTitle:title];
        }
    }
}

- (void)OnMsg:(NSString*)strMsgID withObj:(id)obj
{
    
}

- (void)OnCloseBack
{
    if(_nTabBarVC > 0 ){
        [[tztAppInit sharedtztAppInit] popRootViewController:self Animated:UseAnimated];
    }else{
        [self.navigationController popViewControllerAnimated:UseAnimated];
    }
}

- (void)OnReturnBack
{
    if(_nTabBarVC > 0 ){
        [[tztAppInit sharedtztAppInit] popRootViewController:self Animated:UseAnimated];
    }else{
        [self.navigationController popViewControllerAnimated:UseAnimated];
    }
}

- (void)OnMsgURL:(NSString*)strURL
{
    
}

- (void)OnMsgJSFun:(NSString*)strJSFun
{
    
}

- (void)OnMsgFont
{
    
}

//更多(根据各个vc不同，显示的更多也不一样，到各个vc单独处理)
- (void)OnMore
{
}

- (void)OnRootView
{
    
}

- (void)OnShowPhoneList:(NSString*)telphone
{
	UIActionSheet *contactAlert = nil;
    if(telphone == nil || [telphone length] <=0 )
        telphone = tztAppSysValue(@"tztapp_onlinephone");
	contactAlert = [[UIActionSheet alloc] initWithTitle:@"拨打电话"
											   delegate:self
                                      cancelButtonTitle:@"取消"
								 destructiveButtonTitle:nil
									  otherButtonTitles:telphone,nil];
    
	contactAlert.actionSheetStyle = UIActionSheetStyleDefault;
    //[contactAlert showInView:[UIApplication sharedApplication].keyWindow];
    [contactAlert tztshowInView:[UIApplication sharedApplication].keyWindow withCompletionHandler:^(NSInteger buttonIndex) {
        if (buttonIndex == 0){
			NSString * phoneNum = [contactAlert buttonTitleAtIndex:buttonIndex];//;
            [self OnMakePhoneCall:phoneNum];
        }
    }];
	[contactAlert release];
}

- (void) OnMakePhoneCall:(NSString*)telePhoneNum
{
	NSString *telStr = [[NSString alloc] initWithFormat:@"tel:%@",telePhoneNum];
    tztOpenURL(telStr);
    [telStr release];
}
@end
