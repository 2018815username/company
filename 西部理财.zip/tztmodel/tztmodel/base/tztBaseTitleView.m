//
//  tztBaseTitleView.m
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//
#define tztTitleOrgX 5
#define tztTitleImageBtnWidth 30
#define tztTitleBtnWidth 44.5
#define tztTitleBtnFont 13
#define tztapptitle @"tztapptitle"
#import "tztBaseTitleView.h"
@interface tztBaseTitleView ()
{
    NSString* _leftURL;
    NSString* _leftJS;
    NSString* _rightURL;
    NSString* _rightJS;
    
    CGFloat vHeight;
    CGFloat vWidth;
    CGFloat vStatus;
}
@property (nonatomic,retain)NSString* leftType;
@property (nonatomic,retain)NSString* rightType;
@property (nonatomic,retain)NSString* leftURL;
@property (nonatomic,retain)NSString* leftJS;
@property (nonatomic,retain)NSString* rightURL;
@property (nonatomic,retain)NSString* rightJS;
@property (nonatomic,retain)UIView  * pShadowView;
- (void)initdata;
- (void)initSubView;
@end

@implementation tztBaseTitleView
@synthesize leftType = _leftType;
@synthesize rightType = _rightType;
@synthesize leftURL = _leftURL;
@synthesize leftJS = _leftJS;
@synthesize rightURL = _rightURL;
@synthesize rightJS = _rightJS;
@synthesize pShadowView = _pShadowView;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initdata];
    }
    return self;
}

- (id)init
{
    self = [super init];
    if(self){
        [self initdata];
    }
    return self;
}

- (void)initdata
{
    self.leftType = NULL;
    self.rightType = NULL;
    
//#ifndef tztHasNoShadow
//    [self.layer setShadowOffset:CGSizeMake(0.1, 0.01)];
//    self.layer.masksToBounds = NO;
//    [self.layer setShadowColor:[UIColor lightGrayColor].CGColor];
//    [self.layer setShadowOpacity:0.3];
//#endif
}

- (void)initSubView
{
    vHeight = self.frame.size.height/* - 10*/;
    vWidth = self.frame.size.width;
//#ifndef tztHasNoShadow
//    self.layer.shadowPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 4.1, vWidth, vHeight)].CGPath;
//#endif
    self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageTztNamed:@"tztTitlebg.png"]];
    vStatus = tztStatusBarHeight();
#ifdef __IPHONE_7_0
    if(IS_TZTIOS(7)){
        vHeight -= vStatus;
    }
    else
#endif
    {
        vStatus = 0;
    }
    if(_backImage == nil){
        _backImage = NewObject(UIImageView);
        [self addSubview:_backImage];
        Obj_RELEASE(_backImage);
    }
    [_backImage setFrame:self.bounds];
    [_backImage setImage:[UIImage imageTztNamed:@"tztTitlebg.png"]];
    
    if(_leftBtn == nil){
        _leftBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_leftBtn];
        [_leftBtn addTarget:self action:@selector(onClickLeftBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    [_leftBtn setShowsTouchWhenHighlighted:YES];
    [_leftBtn setContentMode:UIViewContentModeCenter];
    _leftBtn.userInteractionEnabled = NO;
    [_leftBtn setFrame:CGRectMake(tztTitleOrgX, vStatus, tztTitleBtnWidth, vHeight)];
    [_leftBtn.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    if(_rightBtn == nil){
        _rightBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_rightBtn];
        [_rightBtn addTarget:self action:@selector(onClickRightBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    
    [_rightBtn setShowsTouchWhenHighlighted:YES];
    [_rightBtn setContentMode:UIViewContentModeCenter];
    _rightBtn.userInteractionEnabled = NO;
    [_rightBtn setFrame:CGRectMake(vWidth-tztTitleOrgX-tztTitleBtnWidth, vStatus, tztTitleBtnWidth, vHeight)];
    [_rightBtn.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    if(_btn1 == nil){
        _btn1 = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_btn1];
        [_btn1 addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    [_btn1 setShowsTouchWhenHighlighted:YES];
    [_btn1 setContentMode:UIViewContentModeCenter];
    _btn1.userInteractionEnabled = NO;
    _btn1.hidden = YES;
    [_btn1 setFrame:CGRectMake(tztTitleOrgX, vStatus, tztTitleImageBtnWidth, vHeight)];
    [_btn1.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    if(_btn2 == nil){
        _btn2 = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_btn2];
        [_btn2 addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    [_btn2 setShowsTouchWhenHighlighted:YES];
    [_btn2 setContentMode:UIViewContentModeCenter];
    _btn2.userInteractionEnabled = NO;
    _btn2.hidden = YES;
    [_btn2 setFrame:CGRectMake(tztTitleOrgX + tztTitleImageBtnWidth + tztTitleOrgX, vStatus, tztTitleImageBtnWidth, vHeight)];
    [_btn2.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    if(_btn3 == nil){
        _btn3 = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_btn3];
        [_btn3 addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    [_btn3 setShowsTouchWhenHighlighted:YES];
    [_btn3 setContentMode:UIViewContentModeCenter];
    _btn3.userInteractionEnabled = NO;
    _btn3.hidden = YES;
    [_btn3 setFrame:CGRectMake(vWidth - (tztTitleOrgX + tztTitleImageBtnWidth) * 2, vStatus, tztTitleImageBtnWidth, vHeight)];
    [_btn3.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    
    if(_btn4 == nil){
        _btn4 = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_btn4];
        [_btn4 addTarget:self action:@selector(onBtnClick:) forControlEvents:UIControlEventTouchUpInside];
    }
    [_btn4 setShowsTouchWhenHighlighted:YES];
    [_btn4 setContentMode:UIViewContentModeCenter];
    _btn4.userInteractionEnabled = NO;
    _btn4.hidden = YES;
    [_btn4 setFrame:CGRectMake(vWidth - (tztTitleOrgX + tztTitleImageBtnWidth), vStatus, tztTitleImageBtnWidth, vHeight)];
    [_btn4.titleLabel setFont:tztUIBaseViewTextFont(tztTitleBtnFont)];
    
    if(_preBtn == nil){
        _preBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_preBtn];
    }
    [_preBtn setTztBackgroundImage:[UIImage imageTztNamed:@"tztTitlePrebg.png"]];
    [_preBtn setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX*4, (vHeight-12)/2, 10, 12)];
    
    if(_nextBtn == nil){
        _nextBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_nextBtn];
    }
    [_nextBtn setTztBackgroundImage:[UIImage imageTztNamed:@"tztTitleNextbg.png"]];
    [_nextBtn setFrame:CGRectMake(vWidth-tztTitleBtnWidth-tztTitleOrgX*4-10, (vHeight-12)/2, 10, 12)];
    
    if(_preHideBtn == nil){
        _preHideBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_preHideBtn];
        [_preHideBtn addTarget:self action:@selector(onClickPreBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    [_preHideBtn setShowsTouchWhenHighlighted:YES];
    [_preHideBtn setContentMode:UIViewContentModeCenter];
    [_preHideBtn setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX*2, vStatus, vWidth/2-tztTitleOrgX*2-tztTitleBtnWidth, vHeight)];
    
    if(_nextHideBtn == nil){
        _nextHideBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        [self addSubview:_nextHideBtn];
        [_nextHideBtn addTarget:self action:@selector(onClickNextBtn) forControlEvents:UIControlEventTouchUpInside];
    }
    [_nextHideBtn setShowsTouchWhenHighlighted:YES];
    [_nextHideBtn setContentMode:UIViewContentModeCenter];
    [_nextHideBtn setFrame:CGRectMake(vWidth-tztTitleBtnWidth-tztTitleOrgX*2, vStatus, vWidth/2-tztTitleOrgX*2-tztTitleBtnWidth, vHeight)];
    
    if(_centerTitle == nil){
        _centerTitle = NewObject(UILabel);
        [self addSubview:_centerTitle];
        Obj_RELEASE(_centerTitle);
    }
    [_centerTitle setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX, vStatus, vWidth-(tztTitleBtnWidth+tztTitleOrgX) * 2, vHeight)];
    [_centerTitle setTextColor:[UIColor colorWithTztRGBStr:tztAppStringValue(tztapptitle,@"tztapptitle_textcolor", @"255,255,255")]];
    [_centerTitle setBackgroundColor:[UIColor clearColor]];
    [_centerTitle setTextAlignment:NSTextAlignmentCenter];
    [_centerTitle setFont:tztUIBaseViewTextBoldFont(17)];
    
    if(_topTitle == nil){
        _topTitle = NewObject(UILabel);
        [self addSubview:_topTitle];
        Obj_RELEASE(_topTitle);
    }
    _topTitle.hidden = YES;
    [_topTitle setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX, vStatus, vWidth-(tztTitleBtnWidth +tztTitleOrgX)* 2, vHeight * 2 /3)];
    [_topTitle setTextColor:[UIColor colorWithTztRGBStr:tztAppStringValue(tztapptitle,@"tztapptitle_toptextcolor", @"255,255,255")]];
    [_topTitle setBackgroundColor:[UIColor clearColor]];
    [_topTitle setTextAlignment:NSTextAlignmentCenter];
    [_topTitle setFont:tztUIBaseViewTextBoldFont(14)];
 
    if(_bottomTitle == nil){
        _bottomTitle = NewObject(UILabel);
        [self addSubview:_bottomTitle];
        Obj_RELEASE(_bottomTitle);
    }
    _bottomTitle.hidden = YES;
    [_bottomTitle setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX, vHeight * 2 /3, vWidth-(tztTitleBtnWidth+tztTitleOrgX) * 2, vHeight /3)];
    [_bottomTitle setTextColor:[UIColor colorWithTztRGBStr:tztAppStringValue(tztapptitle,@"tztapptitle_bottomtextcolor", @"255,255,0")]];
    [_bottomTitle setBackgroundColor:[UIColor clearColor]];
    [_bottomTitle setTextAlignment:NSTextAlignmentCenter];
    [_bottomTitle setFont:tztUIBaseViewTextFont(12)];
    
    if(_leftTitle == nil){
        _leftTitle = NewObject(UILabel);
        [self addSubview:_leftTitle];
        Obj_RELEASE(_leftTitle);
    }
    [_leftTitle setFrame:CGRectMake(tztTitleBtnWidth+tztTitleOrgX, vStatus, vWidth/2-tztTitleBtnWidth-tztTitleOrgX-2, vHeight)];
    [_leftTitle setTextColor:[UIColor colorWithTztRGBStr:tztAppStringValue(tztapptitle,@"tztapptitle_lefttextcolor", @"255,255,255")]];
    [_leftTitle setBackgroundColor:[UIColor clearColor]];
    [_leftTitle setTextAlignment:NSTextAlignmentRight];
    [_leftTitle setFont:tztUIBaseViewTextFont(14)];
    _leftTitle.hidden = YES;
    
    if(_rightTitle == nil){
        _rightTitle = NewObject(UILabel);
        [self addSubview:_rightTitle];
        Obj_RELEASE(_rightTitle);
    }
    [_rightTitle setFrame:CGRectMake(vWidth/2+2, vStatus, vWidth/2-tztTitleOrgX-tztTitleBtnWidth-2, vHeight)];
    [_rightTitle setTextColor:[UIColor colorWithTztRGBStr:tztAppStringValue(tztapptitle,@"tztapptitle_righttextcolor", @"255,255,0")]];
    [_rightTitle setBackgroundColor:[UIColor clearColor]];
    [_rightTitle setTextAlignment:NSTextAlignmentLeft];
    [_rightTitle setFont:tztUIBaseViewTextFont(14)];
    _rightTitle.hidden = YES;

    [self setTitlePreNextHide:TRUE];
    [self setTitleLeftType:self.leftType];
    [self setTitleRightType:self.rightType];

    
    _pShadowView = NewObject(UIView);
    _pShadowView.backgroundColor = self.backgroundColor;
    
    CGRect rcShadow = self.bounds;
    rcShadow.origin.y += self.bounds.size.height - 1;
    rcShadow.size.height = 1;
    _pShadowView.frame = rcShadow;
    [self addSubview:_pShadowView];
    Obj_RELEASE(_pShadowView);
    
#ifndef tztHasNoShadow
//    _pShadowView.layer.shadowPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, vWidth, vHeight)].CGPath;
    [_pShadowView.layer setShadowOffset:CGSizeMake(0.1, 0.01)];
    _pShadowView.layer.masksToBounds = NO;
    [_pShadowView.layer setShadowColor:[UIColor blackColor].CGColor];
    [_pShadowView.layer setShadowOpacity:1];
    _pShadowView.layer.shadowRadius = 8.f;
#endif
}

- (void)setTitleShowType:(tztTitleShowType)showType
{
    _showType = showType;
    _centerTitle.hidden = NO;
    if((_showType & tztTitleUpDown) == tztTitleUpDown){
        _topTitle.hidden = NO;
        _bottomTitle.hidden = NO;
        
        _leftTitle.hidden = YES;
        _rightTitle.hidden = YES;
        _centerTitle.hidden = YES;
    }else if((_showType & tztTitleLeftRight)== tztTitleLeftRight){
        _leftTitle.hidden = NO;
        _rightTitle.hidden = NO;
        
        _centerTitle.hidden = YES;
        _topTitle.hidden = YES;
        _bottomTitle.hidden = YES;
    }
}

- (void)setTitlePreNextHide:(BOOL)bHide
{
    _preBtn.userInteractionEnabled = (!bHide);
    _preBtn.hidden = bHide;
    
    _nextBtn.userInteractionEnabled = (!bHide);
    _nextBtn.hidden = bHide;
    
    _preHideBtn.userInteractionEnabled = (!bHide);
    _preHideBtn.hidden = bHide;
    
    _nextHideBtn.userInteractionEnabled = (!bHide);
    _nextHideBtn.hidden = bHide;
}

- (void)setBtn:(UIButton*)btn ofType:(int)nType
{
    btn.hidden = NO;
    btn.userInteractionEnabled = YES;
    CGRect frame = btn.frame;
    frame.origin.x +=frame.size.width-55;
    if(frame.origin.x < 0)
        frame.origin.x = tztTitleOrgX;
    frame.size.width = 55;
    [btn setTztBackgroundImage:nil];
    [btn setAllStateTitle:@""];
    UIImage* btnImage = nil;
    switch (nType) {
        case tztBtnSearchStock:
        {
            btnImage = [UIImage imageTztNamed:@"tztTitleSearch.png"];
        }
            break;
        case tztBtnFont:
        {
            btnImage = [UIImage imageTztNamed:@"tztTitleFont.png"];
        }
            break;
        case tztBtnSign:
        {
            [btn setAllStateTitle:@"订阅"];
        }
            break;
        case tztBtnEdit:
        {
            [btn setAllStateTitle:@"编辑"];
        }
            break;
        case tztBtnKH:
        {
            [btn setAllStateTitle:@"我要开户"];
            [btn setFrame:frame];
        }
            break;
        case tztBtnOnline:
        {
            [btn setAllStateTitle:@"在线客服"];
            [btn setFrame:frame];
        }
            break;
        case tztBtnFilter:
        {
            [btn setAllStateTitle:@"筛选"];
        }
            break;
        case tztBtnFilterIcon:
        {
            btnImage = [UIImage imageTztNamed:@"tztTitleFilter.png"];
        }
            break;
        case tztBtnLogoAbout:
        {
            btnImage = [UIImage imageTztNamed:@"tztTitleLogo.png"];
        }
            break;
        case tztBtnHide:
        {
            btn.hidden = YES;
            btn.userInteractionEnabled = NO;
        }
            break;
        case tztBtnReturn:
        {
            btnImage = [UIImage imageTztNamed:@"tztTitleReturn.png"];
        }
            break;
        case tztBtnClose:
        {
            [btn setAllStateTitle:@"退出"];
        }
            break;
        case tztBtnMap:
        {
            [btn setAllStateTitle:@"查看地图"];
            [btn setFrame:frame];
        }
            break;
        case tztBtnClear:
        {
            [btn setAllStateTitle:@"一键清除"];
            [btn setFrame:frame];
        }
            break;
        case tztBtnUserIcon:
        {
            
        }
            break;
        case tztBtnUserText:
        {
            [btn setFrame:frame];
        }
            break;
        default:
            break;
    }
    [btn setTztBackgroundImage:btnImage];
    if(btnImage){
        CGSize image = btnImage.size;
        frame = btn.frame;
        btn.frame = CGRectMake(frame.origin.x, frame.origin.y, image.width * frame.size.height / image.height, frame.size.height);
    }
}
//左侧按钮类型
- (void)setTitleLeftType:(NSString*)strType
{
    if(strType == NULL || strType.length <= 0){
        strType = [NSString stringWithFormat:@"%d",tztBtnReturn];
    }
    self.leftType = strType;
    int nType = [self.leftType intValue];
    _leftBtn.frame = CGRectMake(tztTitleOrgX, vStatus, tztTitleBtnWidth, vHeight);
    [self setBtn:_leftBtn ofType:nType];
}

- (int)getTitleLeftType
{
    if(self.leftType)
        return [self.leftType intValue];
    return tztBtnReturn;
}

//右侧按钮类型
- (void)setTitleRightType:(NSString*)strType
{
    if(strType == NULL || strType.length <= 0){
        strType = [NSString stringWithFormat:@"%d",tztBtnHide];
    }
    self.rightType = strType;
    int nType = [self.rightType intValue];
    _rightBtn.frame = CGRectMake(vWidth-tztTitleBtnWidth-tztTitleOrgX, vStatus, tztTitleBtnWidth, vHeight);
    [self setBtn:_rightBtn ofType:nType];
}

- (int)getTitleRightType
{
    if(self.rightType)
        return [self.rightType intValue];
    return tztBtnHide;
}

//替换左侧按钮类型
- (void)replaceTitleLeftType:(int)ntarget with:(int)nreplace
{
    int nType;
    if(self.leftType == NULL || self.leftType.length <= 0){
        nType =  tztBtnReturn;
    }else{
        nType = [self.leftType intValue];
    }
    if(ntarget == nType){
        [self setTitleLeftType:[NSString stringWithFormat:@"%d",nreplace]];
    }
}

//替换右侧按钮类型
- (void)replaceTitleRightType:(int)ntarget with:(int)nreplace
{
    int nType;
    if(self.rightType == NULL || self.rightType.length <= 0){
        nType =  tztBtnHide;
    }else{
        nType = [self.rightType intValue];
    }
    if(ntarget == nType){
        [self setTitleRightType:[NSString stringWithFormat:@"%d",nreplace]];
    }
}
//标题
- (void)setTitle:(NSString*)strTitle
{
    [_centerTitle setText:strTitle];
    [_leftTitle setText:strTitle];
    [_topTitle setText:strTitle];
}

//标题
- (void)setTitle:(NSString*)strTitle otherTitle:(NSString*)strOther
{
    [_centerTitle setText:strTitle];
    [_leftTitle setText:strTitle];
    [_rightTitle setText:strOther];
    [_topTitle setText:strTitle];
    [_bottomTitle setText:strOther];
}

- (void)setLeftBtnText:(NSString*)strText
{
    if(strText == NULL)
        return;
    if([self.leftType compare:@"98"] == NSOrderedSame){//图片
        UIImage* btnImage = [UIImage imageTztNamed:strText];
        [_leftBtn setTztBackgroundImage:[UIImage imageTztNamed:strText]];
        if(btnImage){
            CGSize image = btnImage.size;
            CGRect frame = _leftBtn.frame;
            _leftBtn.frame = CGRectMake(frame.origin.x, frame.origin.y, image.width * frame.size.height / image.height, frame.size.height);
        }
    }else if([self.leftType compare:@"99"] == NSOrderedSame){//文字
        [_leftBtn setAllStateTitle:strText];
    }
}

- (void)setRightBtnText:(NSString*)strText
{
    if(strText == NULL)
        return;
    if([self.rightType compare:@"98"] == NSOrderedSame){//图片
        NSString* strAdd = @"";
        if([strText hasPrefix:@"tzttitlelogin"]){
            if([[tztHTTPData getShareInstance] tztperformSelector:@"isTztLoginOfType:" withObject:@""]){
               strAdd = @"_on";
            }   
        }
        UIImage* btnImage = [UIImage imageTztNamed:strText withAdd:strAdd];
        [_rightBtn setTztBackgroundImage:btnImage];
        if(btnImage){
            CGSize image = btnImage.size;
            CGRect frame = _rightBtn.frame;
            _rightBtn.frame = CGRectMake(frame.origin.x - image.width * frame.size.height / image.height+frame.size.width, frame.origin.y, image.width * frame.size.height / image.height, frame.size.height);
        }
    }else if([self.rightType compare:@"99"] == NSOrderedSame){//文字
        [_rightBtn setAllStateTitle:strText];
    }
}

- (void)setLeftUrl:(NSString*)strUrl jsfun:(NSString*)strJS
{
    self.leftURL = strUrl;
    self.leftJS = strJS;
}

- (void)setRightUrl:(NSString*)strUrl jsfun:(NSString*)strJS
{
    self.rightURL = strUrl;
    self.rightJS = strJS;
}

- (void)onBtnClick:(id)sender
{
    
}

- (void)onBtnClick:(int)nType url:(NSString*)strURL jsfun:(NSString *)strJS btn:(id)obj
{
    if(_tztdelegate){
        switch (nType) {
            case tztBtnSearchStock://个股搜索
            {
                [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",HQ_MENU_SearchStock] withObject:nil];
            }
                break;
            case tztBtnFont://修改字体
            {
                [_tztdelegate tztperformSelector:@"OnMsgFont"];
            }
                break;
            case tztBtnKH://我要开户
            {
                [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",TZT_MENU_StartOpen] withObject:strURL];
            }
                break;
            case tztBtnOnline://在线客服 MENU_SYS_OnlineServe
            {
                [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",MENU_SYS_OnlineServe] withObject:strURL];
            }
                break;
            case tztBtnLogoAbout://LOGO图标
            {
                [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",MENU_SYS_About] withObject:strURL];
            }
                break;
            case tztBtnHide://不显示
            {
            }
                break;
            case tztBtnReturn://返回
            {
                [_tztdelegate tztperformSelector:@"OnReturnBack"];
            }
                break;
            case tztBtnClose://退出
            {
                [_tztdelegate tztperformSelector:@"OnCloseBack"];
            }
                break;
            case tztBtnClear://一键清除
            {
                [_tztdelegate tztperformSelector:@"OnMsgJSFun:" withObject:@"clearKey();"];
            }
                break;
            case tztBtnSign://订阅
            case tztBtnEdit://修改
            case tztBtnFilter://筛选
            case tztBtnFilterIcon://筛选图片
            case tztBtnMap://查看地图
            case tztBtnUserIcon://自定义图片
            case tztBtnUserText://自定义文本
            {
                if(strURL && strURL.length > 0){
                    [_tztdelegate tztperformSelector:@"OnMsgURL:" withObject:strURL];
                }else if(strJS && strJS.length > 0){
                    [_tztdelegate tztperformSelector:@"OnMsgJSFun:" withObject:strJS];
                }else{
                    [_tztdelegate tztperformSelector:@"OnClickBtn:" withObject:obj];
                }
            }
                break;
            default:
                break;
        }
    }
}

- (void)onClickLeftBtn
{
    int nType = [_leftType intValue];
    [self onBtnClick:nType url:self.leftURL jsfun:self.leftJS btn:_leftBtn];
}

- (void)onClickRightBtn
{
    int nType = [_rightType intValue];
    [self onBtnClick:nType url:self.rightURL jsfun:self.rightJS btn:_rightBtn];
}
//前一条
- (void)onClickPreBtn
{
    if(_tztdelegate){
        [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",TZT_MENU_OnPrev] withObject:nil];
    }
    
}
//后一条
- (void)onClickNextBtn
{
    if(_tztdelegate){
        [_tztdelegate tztperformSelector:@"OnMsg:withObj:" withObject:[NSString stringWithFormat:@"%d",TZT_MENU_OnNext] withObject:nil];
    }
}

@end
