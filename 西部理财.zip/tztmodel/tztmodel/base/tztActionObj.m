//
//  tztActionObj.m
//  tztmodel
//
//  Created by yangares on 14-9-3.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztActionObj.h"
@interface tztActionObj ()
{
    NSMutableDictionary* _actionInfo;
}
@property (nonatomic,retain) NSString* strAction;
@property (nonatomic,retain) NSMutableDictionary* actionInfo;
@end

@implementation tztActionObj
@synthesize strAction = _strAction;
@synthesize actionInfo = _actionInfo;
- (id)init
{
    self = [super init];
    if(self){
        if(_actionInfo == NULL)
            self.actionInfo = NewObjectAutoD(NSMutableDictionary);
    }
    return self;
}

- (void)dealloc
{
    NilObject(self.actionInfo);
    [super dealloc];
}

//功能标题
- (NSString*)getActionTitle
{
    if(self.actionInfo)
        return [self.actionInfo tztValueForKey:@"title"];
    return @"";
}

- (id) initWithAction:(NSString*)strAction
{
    self = [super init];
    if(self){
        [self setTztAction:strAction];
    }
    return self;
}

- (void)setTztAction:(NSString*)strAction
{
    if(_actionInfo == NULL)
        self.actionInfo = NewObjectAutoD(NSMutableDictionary);
    
    self.strAction = strAction;
    
    NSString* nsID = [NSString stringWithFormat:@"Fuction:%@", strAction];
    NSString* strValue = [nsID tztAppStringValue:@"tztappaction" value:nsID];
    [self.actionInfo settztProperty:strValue];
}

+ (NSString*)getActionTitle:(NSString *)strAction
{
    tztActionObj* action = NewObjectAutoD(tztActionObj);
    [action setTztAction:strAction];
    return [action getActionTitle];
}
@end
