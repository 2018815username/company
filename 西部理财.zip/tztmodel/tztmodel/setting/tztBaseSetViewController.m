//
//  tztBaseSetViewController.m
//  tztMobileApp
//
//  Created by yangares on 13-5-19.
//
//

#import "tztBaseSetViewController.h"
//#import "tztSendToFriendView.h"
#import "tztServerSettingView.h"
//#import "tztHQSetView.h"
//#import "tztKLineSetView.h"
#import "tztCheckServerListView.h"
#import "tztSystemSettingView.h"
@implementation tztUIBaseSetView
@synthesize tztTableView = _tztTableView;
@synthesize tableConfig = _tableConfig;
-(id)init
{
    if (self = [super init])
    {
        self.backgroundColor = [tztTechSetting getInstance].backgroundColor;
    }
    return self;
}

-(void)dealloc
{
    [self onReadWriteSettingValue:FALSE];
    [super dealloc];
}

-(void)setFrame:(CGRect)frame
{
    if (CGRectIsNull(frame) || CGRectIsEmpty(frame))
        return;
    [super setFrame:frame];
    
    CGRect rcFrame = self.bounds;
    if (g_nSkinType == 0) {
        rcFrame = CGRectInset(rcFrame,10,5);
    }
    
    if (IS_TZTIPAD) //调整iPad版本的宽度
        rcFrame.size.width = CGRectGetWidth(rcFrame) / 2;
    
    if (_tztTableView == nil)
    {
        _tztTableView = [[tztUIVCBaseView alloc] initWithFrame:rcFrame];
        _tztTableView.tztDelegate = self;
        [self addSubview:_tztTableView];
//        _tztTableView.backgroundColor = [tztTechSetting getInstance].backgroundColor;
        [_tztTableView release];
    }
    else
    {
        _tztTableView.frame = rcFrame;
    }
    [_tztTableView setTableConfig:self.tableConfig];
    [self onReadWriteSettingValue:YES];
//    if (g_nSkinType == 1)
//    {
//        [UIColor colorWithTztRGBStr:@"237, 237, 237"];
//    }
}

- (void)onSetTableConfig:(NSString*)strConfig
{
    self.tableConfig = strConfig;
    if(self.tableConfig && [self.tableConfig length] > 0 && _tztTableView)
    {
        [_tztTableView setTableConfig:self.tableConfig];
        [self onReadWriteSettingValue:YES];
    }
}

- (void)onReadWriteSettingValue:(BOOL)bRead
{
    
}

@end

@implementation tztBaseSetViewController
@synthesize tztSetView = _tztSetView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        tztSetViewClass = [tztUIBaseSetView class];
    }
    return self;
}

- (id)init
{
    self = [super init];
    if (self)
    {
        tztSetViewClass = [tztUIBaseSetView class];
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

#pragma mark - View lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self LoadLayoutView];
    [self setNMsgType:_nMsgType];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

-(void)dealloc
{
    [super dealloc];
}

-(void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (_tztSetView)
    {
        [_tztSetView onReadWriteSettingValue:YES];
    }
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    if (_tztSetView)
    {
        [_tztSetView onReadWriteSettingValue:NO];
    }
}

- (void)setNMsgType:(int)nMsgType
{
    _nMsgType = nMsgType;
    
    NSString* strTitle = GetTitleByID(nMsgType);
    switch (_nMsgType) {
        case Sys_Menu_SetServer:
        case MENU_SYS_SerAddSet:
        {
           [self setTztSetViewClass:[tztServerSettingView class]];
            if (ISNSStringValid(strTitle))
                [self setTitle:strTitle];
            else
                [self setTitle:@"服务器设置"];
        }
            break;
//        case Sys_Menu_HQSet:
//        {
//            [self setTztSetViewClass:[tztHQSetView class]];
//            if (ISNSStringValid(strTitle))
//                [self setTitle:strTitle];
//            else
//                [self setTitle:@"行情设置"];
//        }
//            break;
//        case Sys_Menu_KLineSet:
//        {
//            [self setTztSetViewClass:[tztKLineSetView class]];
//            if (ISNSStringValid(strTitle))
//                [self setTitle:strTitle];
//            else
//                [self setTitle:@"K线设置"];
//        }
//            break;
        case Sys_Menu_CheckServer:
        case MENU_SYS_SerAddCheck:
        {
            [self setTztSetViewClass:[tztCheckServerListView class]];
            if (ISNSStringValid(strTitle))
                [self setTitle:strTitle];
            else
                [self setTitle:@"服务器测速"];
        }
            break;
        case Sys_Menu_SystemSetting:
        case MENU_SYS_System:
        {
            [self setTztSetViewClass:[tztSystemSettingView class]];
            if (ISNSStringValid(strTitle))
                [self setTitle:strTitle];
            else
                [self setTitle:@"行情设置"];
        }
        default:
            break;
    }
}

-(void)OnBtnAddStock:(id)sender
{
//    if(_nMsgType == Sys_Menu_SetServer || _nMsgType == MENU_SYS_SerAddSet)
//    {
////        [TZTUIBaseVCMsg OnMsg:Sys_Menu_CheckServer wParam:0 lParam:0];
//    }
}

- (void)setTztSetViewClass:(Class)viewClass
{
    tztSetViewClass = viewClass; 
}

- (void)LoadLayoutView
{
    CGRect rcFrame = tztScreenBounds();
    if (CGRectIsEmpty(rcFrame) || CGRectIsNull(rcFrame))
        return;
    [super LoadLayoutView];
    [_tztTitleView setTitleShowType:tztTitleNormal];
    [_tztTitleView setTitleRightType:@"9"];
    [_tztTitleView setTitle:self.title];
    rcFrame.origin = CGPointZero;
#ifdef __IPHONE_7_0
    if(IS_TZTIOS(7))
    {
        
    }else
#endif
    {
       rcFrame.size.height -=  tztStatusBarHeight(); 
    }
    CGRect rcServer = rcFrame;
    rcServer.origin.y += _tztTitleView.frame.size.height;
    rcServer.size.height -= _tztTitleView.frame.size.height;
    if (_tztSetView == NULL)
    {
        _tztSetView = (tztUIBaseSetView *)[[tztSetViewClass alloc] init];
        _tztSetView.frame = rcServer;
        [self.view addSubview:_tztSetView];
        _tztSetView.backgroundColor = [UIColor colorWithTztRGBStr:@"121,121,121"];
        [_tztSetView release];
    }
    else
        _tztSetView.frame = rcServer;
}

- (void)OnMsgURL:(NSString*)strURL
{
    if (strURL && [[strURL lowercaseString] hasPrefix:tztHTTPAction] ) //处理action
    {
        strURL = [strURL substringFromIndex:[tztHTTPAction length]];
        NSString* strKey;
        NSString* strValue;
        [strURL tzthttpKeyValue:&strKey value:&strValue SeparatedByString:@"?"];
        int nAction = [strKey intValue];
        switch (nAction) {
            case Sys_Menu_CheckServer:
            {
                tztBaseSetViewController *pVC = NewObject(tztBaseSetViewController);
                [pVC SetHidesBottomBarWhenPushed:TRUE];
                pVC.nMsgType = nAction;
                [self.navigationController pushViewController:pVC animated:UseAnimated];
                [pVC release];
            }
                break;
                
            default:
                break;
        }
    }
}
@end
