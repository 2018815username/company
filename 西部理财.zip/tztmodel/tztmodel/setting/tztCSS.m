//
//  tztCSS.m
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztCSS.h"

@implementation tztCSS

- (void)loadCSS:(NSString*)strType
{
    
}

- (NSDictionary*)getCSSValue:(NSString*)strCSSCode
{
    
    return NULL;
}
@end
