//
//  TZTShareObject.h
//  Test
//
//  Created by 在琦中 on 14-2-17.
//  Copyright (c) 2014年 crte. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <TencentOpenAPI/TencentOAuthObject.h>
#import <TencentOpenAPI/TencentOAuth.h>
#import "WeiboApi.h"
#import "TZTShareView.h"

@interface TZTShareObject : NSObject

+ (TencentOAuth *)tencentOAuthWithAppID:(NSString *)appID withDelegate:(id<TencentSessionDelegate>)delegate;
+ (WeiboApi *)wbapiWithApppKey:(NSString *)appKey andAppSecret:(NSString *)appSecret;
+ (NSArray *)permissions;
+ (void)addShareViewin:(UIView *)view withDelegate:(id<shareDelegate>)delegate andInfo:(NSMutableDictionary*)pDict andType_:(int)nShareType;
//+ (void)shareWithType:(int)nShareType andMsg_:(NSMutableDictionary*)pDict;
@end
