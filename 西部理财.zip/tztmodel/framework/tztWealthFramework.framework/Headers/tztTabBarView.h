/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        工具栏view
 * 文件标识:        
 * 摘要说明:        
 * 
 * 当前版本:        2.0
 * 作    者:       yinjp
 * 更新日期:            
 * 整理修改:	
 *
            读取配置文件中的配置，创建toolbar按钮
 ***************************************************************/

#import "TZTUIBaseView.h"
#import "tztTabBarProfile.h"
@protocol tztTabBarViewDelegate;
@interface tztTabBarView : TZTUIBaseView
{
    NSMutableArray      *_ayToolBarItem;
    UIImageView         *_pSelectedView;
    CGRect              _rcSelected;
    UIImageView         *_pBackGroundView;
    int                 _nSelected;
}
@property (nonatomic) int  nSelected;
@property (nonatomic,retain)UIImageView *pSelectedView;
@property (nonatomic,retain)UIImageView *pBackGroundView;
- (void)setTabBarIndex:(int)nBarIndex options_:(NSDictionary*)options;
- (void)OnDealToolBarByName:(NSString*)nsName;
//根据配置的名称获取对应的索引，用于跳转
- (int)GetTabItemIndexByName:(NSString*)nsName;
//根据配置的ID获取对应的索引，用于跳转
- (int)GetTabItemIndexByID:(unsigned int)nsID;

- (void)ReloadToolBar:(NSString*)strData;
- (void)setToolBarProperty:(NSDictionary*)property;
- (void)setTabBarIndex:(int)nBarIndex withBadge:(NSString*)strBadge;
- (void)setTabBarId:(int)nBarID withBadge:(NSString*)strBadge;
- (void)setTabBarName:(NSString*)strBarName withBadge:(NSString*)strBadge;
@end

@protocol tztTabBarViewDelegate<NSObject>
@optional
- (BOOL)tztTabBarView:(tztTabBarView *)tztTabBar didSelectItem:(tztTabBarItem *)tztBarItem options_:options;
-(void)OnReturnPreSelect;
@end

extern tztTabBarView *g_ptztTabBarView;