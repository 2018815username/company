//
//  tztActionObj.h
//  tztmodel
//
//  Created by yangares on 14-9-3.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface tztActionObj : NSObject
{
    NSString* _strAction;
}
- (id) initWithAction:(NSString*)strAction;
- (void)setTztAction:(NSString*)strAction;
- (NSString*)getActionTitle;

+ (NSString*)getActionTitle:(NSString *)strAction;
@end