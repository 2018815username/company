/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:		tztUIDroplistView
 * 文件标识:
 * 摘要说明:		自定义下拉框控件
 * 
 * 当前版本:	2.0
 * 作    者:	
 * 更新日期:	
 * 整理修改:	yinjp
 *
 ***************************************************************/


#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import "tztUIBaseViewDelegate.h"

typedef enum tztDroplistViewType
{
	tztDroplistNon = 0,//
	tztDroplistEdit = 0x0001, //可编辑
	tztDroplistSecure = 0x0010, //加密显示
    tztDroplistDate = 0x0100, //日期选择
    tztDroplistHour = 0x1000,//时间选择
}tztDroplistViewType;

@protocol tztSysKeyboardDelegate <NSObject>
@optional
- (void)showSysKeyboard:(id)keyboardview Show:(BOOL)bShow;
- (void)keyboardWillShow:(id)keyboardview;
- (void)keyboardWillHide;
- (void)keyboardDidHide;
@end

@class tztUITextField;
@protocol tztUIDroplistViewDelegate;
@protocol tztUIBaseViewDelegate;
@protocol tztUIBaseViewTextDelegate;

@interface tztUIDroplistView : UIView<UITableViewDelegate,UITableViewDataSource,UIAlertViewDelegate,UITextFieldDelegate,tztSysKeyboardDelegate,tztUIBaseViewDelegate,tztUIBaseViewTextDelegate>
{
    UIView          *_pBackView;
	//上方的按钮
	tztUITextField* _textfield; //输入框
	UIButton *_textbtn;     //输入框按钮
    
	UIButton *_dropbtn;      //列表按钮
	UITableView *_listView;  //列表
	
	NSMutableArray *_ayData; //列表数据
	NSMutableArray *_ayValue; //列表显示数据
    
    NSString *_title;
    
    NSString *_placeholder;    //提示信息
    NSString *_text;           //显示数据
    NSString *_nsData;          
    
    
    UIColor  *_textColor;      //字体颜色
    
    int _selectindex;          //选中行
    
    id _tztdelegate;//接口回调
    CGFloat _listviewwidth;    //列表宽度
    
    BOOL    _dropbtnMode;//是否显示dropbtn
    BOOL    _droplistdel; //列表支持删除
    BOOL    _tztcheckdate; //检测数据是否为空
	tztDroplistViewType		_droplistViewType;	//类型
    int     _nTextMaxLen;//可输入时d最大输入长度
    BOOL        _enabled;
    NSString* _tzttagcode;
    BOOL _nShowSuper; //显示在superview
   @private

    int  _nShowListRow;
    CGFloat _fCellHeight;
    int _deleteindex;
    BOOL _bShowList;
    CGSize szDropImg;
}
@property (nonatomic, retain)UIView    *pBackView;
@property (nonatomic,retain) NSString* tzttagcode;
@property (nonatomic) BOOL nShowSuper;
@property (nonatomic) BOOL enabled;
@property (nonatomic, retain) tztUITextField *textfield;
@property (nonatomic, retain) UIButton *textbtn;
@property (nonatomic, retain) UIButton *dropbtn;
@property(nonatomic,retain) UITableView *listView;

@property(nonatomic,retain) NSMutableArray *ayData;
@property(nonatomic,retain) NSMutableArray *ayValue;

@property(nonatomic,retain) NSString *title;

@property(nonatomic,retain) NSString *placeholder;
@property(nonatomic,retain) NSString *text;
@property(nonatomic,retain) NSString *nsData;
@property(nonatomic,retain) UIColor *textColor;
@property(nonatomic,assign) id<tztUIDroplistViewDelegate> tztdelegate;

@property (nonatomic) int selectindex; //
@property CGFloat listviewwidth;
@property BOOL dropbtnMode;
@property BOOL droplistdel;
@property BOOL tztcheckdate;
@property tztDroplistViewType droplistViewType;

- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
- (void)onSetPlaceholder;
//nShow = 0 隐藏 1 显示 其他 切换(隐藏则显示 ，显示则隐藏)
- (void)doShowList:(int)nShow;
- (void)doHideList;
- (void)doHideListEx;
//设置_text为空
-(void)setTextFieldText;
@end


@protocol tztUIDroplistViewDelegate <tztSysKeyboardDelegate>
@optional
//获取列表显示位置
- (CGPoint)tztDroplistView:(tztUIDroplistView*)droplistview point:(CGPoint)listpoint;
//显示列表视图
- (BOOL)tztDroplistView:(tztUIDroplistView*)droplistview showlistview:(UITableView*)listview;
//显示时间选择器
- (void)tztDroplistViewWithDataview:(tztUIDroplistView*)droplistview;

//zxl 20131022 开始显示数据前处理
- (void)tztDroplistViewBeginShowData:(tztUIDroplistView*)droplistview;

//刷新数据
- (void)tztDroplistViewGetData:(tztUIDroplistView*)droplistview;
//删除列表数据
- (BOOL)tztDroplistView:(tztUIDroplistView *)droplistview didDeleteIndex:(int)index;
//选中列表数据
- (void)tztDroplistView:(tztUIDroplistView *)droplistview didSelectIndex:(int)index;
//隐藏时间选择器
- (void)tztDroplistViewWithDataviewHide:(tztUIDroplistView*)droplistview;
@end
