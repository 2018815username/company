/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztUINineGridView.h
 * 文件标识：
 * 摘    要：九宫格
 *          tztNineCellData 宫格对象
 *          tztNineCellView 宫格视图
 *          tztUINineGridView 九宫格视图
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/

#import <UIKit/UIKit.h>
@interface tztNineCellData : NSObject
{
    NSString* _image;//图片名称
    NSString* _highimage;//高亮
    NSString* _text; //标题
    NSInteger _cmdid;//功能ID
    NSString* _cmdparam;//功能参数
}
@property (nonatomic,retain) NSString* image;
@property (nonatomic,retain) NSString* highimage;
@property (nonatomic,retain) NSString* text;
@property NSInteger cmdid;
@property (nonatomic,retain) NSString* cmdparam;

- (id)initwithCellData:(NSString*)celldata;
- (void)setCellData:(NSString*)celldata;
@end

@protocol tztNineGridViewDelegate <NSObject>
@optional
//返回点击宫格功能值
- (void)tztNineGridView:(id)ninegridview clickCellData:(tztNineCellData *)cellData;
@end

@interface tztNineCellView : UIView
{
    UIButton* _cellbtn;
    UILabel*  _celllab;
    tztNineCellData* _cellData;
    id<tztNineGridViewDelegate> _tztdelegate;
    UIColor  *_clText;
    CGFloat _fCellSize;
}
@property (nonatomic,assign) id<tztNineGridViewDelegate> tztdelegate;
@property (nonatomic,retain) tztNineCellData* cellData;
@property (nonatomic,retain) UIColor *clText;
@property CGFloat fCellSize;
@end

@interface tztUINineGridView : UIView<tztNineGridViewDelegate, UIScrollViewDelegate>
{
    UIScrollView    *_pScrollView;
    NSMutableArray* _aycelldata;//数据列表
    NSMutableArray* _aycell;
    int _rowCount;//行数
    int _colCount;//列数
    id<tztNineGridViewDelegate> _tztdelegate;
    UIColor     *_clText;//标题文字颜色
    NSString*   _nsBackImage;
    BOOL        _bIsMoreView;
    CGFloat     _fCellSize;
    int         _nFixCol;
    
    UIPageControl   *_pageControl;
    NSMutableArray* _aycelldataAll;
}
@property (nonatomic,retain)UIScrollView    *pScrollView;
@property (nonatomic,assign) id<tztNineGridViewDelegate> tztdelegate;
@property (nonatomic) int rowCount;
@property (nonatomic) int colCount;
@property (nonatomic,retain)UIColor *clText;
@property (nonatomic,retain)NSString* nsBackImage;
@property BOOL bIsMoreView;
@property CGFloat fCellSize;
@property int nFixCol;
@property (nonatomic,retain)UIPageControl *pageControl;

- (void)setAyCellData:(NSArray*)ayCellData;
- (void)setAyCellDataAll:(NSArray*)ayCellData;
@end



