//
//  tztAppStart.h
//  tztmodel
//
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "tztMainTabbarVC.h"

@protocol tztAppInitDelegate <NSObject>
@required
- (void)appStart;
- (void)appShow;
@end
//@class tztMainTabbarVC;
@interface tztAppInit : NSObject<tztAppInitDelegate,UITabBarControllerDelegate>
{
    PPRevealSideViewController*     _revealSideViewController;
    tztMainTabbarVC*                _mainTabBarVC;
    UIWindow *_window;
}
@property(nonatomic,retain) PPRevealSideViewController*      revealSideViewController;
@property(nonatomic,retain) tztMainTabbarVC*     mainTabBarVC;
@property(nonatomic,retain) UIWindow *window;
+ (tztAppInit *)sharedtztAppInit;
- (void)tztInitApp:(NSDictionary *)launchOptions;
//外部调用URL
- (BOOL)tztHandleOpenURL:(NSURL*)url;
- (void)selectedTabPageID:(unsigned int)nPageID;
- (void)selectedTab:(int)nTab;
- (void)onRootTab:(int)nTab;
- (void)popRootViewController:(id)pVC Animated:(BOOL)animated;
//获取devicetoken
- (void)setDeviceToken:(NSString*)strToken;
//账号登录
- (void)tztUniqueidLogin:(NSString*)strAccount branch:(NSString*)strBranch;
//账号登出
- (void)tztUniqueidLogout:(NSString*)strAccount branch:(NSString*)strBranch;;
//消息推送
- (void)remoteNotification:(NSDictionary*)userInfo;
@end
