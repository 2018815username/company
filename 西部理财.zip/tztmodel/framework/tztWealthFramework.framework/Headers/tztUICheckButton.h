/*************************************************************
* Copyright (c)2009, 杭州中焯信息技术股份有限公司
* All rights reserved.
*
* 文件名称:		TZTUICheckButton
* 文件标识:
* 摘要说明:		选择框控件
* 
* 当前版本:	2.0
* 作    者:	yinjp
* 更新日期:	
* 整理修改:	
*
***************************************************************/


#import <UIKit/UIKit.h>
#import "tztUIBaseViewDelegate.h"
@class tztUICheckButton;

@protocol tztUIBaseViewDelegate;
//tag|区域|value|textAlignment|font|控件类型|未选中信息|选中信息|提示信息|是否必须选中|
@interface tztUICheckButton : UIButton <tztUIBaseViewDelegate> 
{
    UIButton*   _checkbtn;//选择框
//    UIButton*   _infobtn; //信息
    UILabel*    _infolab;
    //是否需要进行校验，判断必须选择
	BOOL		 _tztcheckdate;
    BOOL         _checkleft;
	id			 _tztdelegate;
    //提示信息
    NSString    *_yestitle;
    NSString    *_notitle;
	NSString	*_messageinfo;
    NSString* _tzttagcode;
}
@property (nonatomic,retain) NSString* tzttagcode;
@property (nonatomic, assign) id<tztUIBaseViewCheckDelegate> tztdelegate;
@property (nonatomic, retain)NSString*  yestitle;
@property (nonatomic, retain)NSString*  notitle;
@property (nonatomic, retain)NSString*  messageinfo;
@property BOOL tztcheckdate;
- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
@end

