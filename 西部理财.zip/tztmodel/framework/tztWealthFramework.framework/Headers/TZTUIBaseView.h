/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        TZTUIBaseView
 * 文件标识:        
 * 摘要说明:        view基类
 * 
 * 当前版本:        2.0
 * 作    者:       yinjp
 * 更新日期:            
 * 整理修改:	
 *
 ***************************************************************/

#import <UIKit/UIKit.h>
#import <MobileCoreServices/UTCoreTypes.h>
#import "tztUIDroplistView.h"
#import "tztStockInfo.h"
#import "TZTUIMessageBox.h"
@protocol tztSocketDataDelegate;
@protocol TZTUIMessageBoxDelegate;

@protocol TZTUIBaseViewDelegate
@optional
-(void)OnReturnBack;//返回
-(void)OnOK;
-(NSMutableArray*)GetAyToolBar;
-(void)OnPopSelf;
-(void)upDownBottomView;
@end

#define TZT_T_Margin 10
@class tztStockInfo;
@interface TZTUIBaseView : UIView<UIScrollViewDelegate, tztSocketDataDelegate,TZTUIMessageBoxDelegate, tztUIDroplistViewDelegate>
{
    id              _pDelegate;            //回调句柄
    char            _cBeSending;           //是否可以发送数据
    NSString*       _nsStockCode;           //股票代码
    UInt16          _ntztReqNo;             //请求序号
    tztStockInfo    *_pStockInfo;
    int             _nMsgType;
}

@property(nonatomic,assign)id               pDelegate;
@property(nonatomic,retain)NSString         *nsStockCode;
@property char                              cBeSending;
@property UInt16                            ntztReqNo;
@property(nonatomic, retain)tztStockInfo    *pStockInfo;
@property int nMsgType;

//菜单点击,返回bool，标识内部是否已经处理过
-(BOOL)OnToolbarMenuClick:(id)sender;
//
-(BOOL) OnCloseKeybord:(UIView*)pView;
-(void) OnReturnBack;
@end
