//
//  tztBaseVC.h
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztBaseTitleView.h"

@interface tztBaseVC : UIViewController<UIActionSheetDelegate,tztTitleViewDelegate>
{
    tztBaseTitleView* _tztTitleView;
    NSString* _tztTitle;
    int _nMsgType;
    int _nTabBarVC;
}
@property (nonatomic,retain) tztBaseTitleView* tztTitleView;
@property (nonatomic,retain) NSString* tztTitle;
@property(nonatomic) int   nMsgType;
@property(nonatomic) int   nTabBarVC;
- (void)LoadLayoutView;
- (void)OnReturnBack;
- (void)OnCloseBack;
- (void)OnMore;
- (void)OnMsg:(NSString*)strMsgID withObj:(id)obj;
- (void)OnMsgURL:(NSString*)strURL;
- (void)OnMsgJSFun:(NSString*)strJSFun;
- (void)OnMsgFont;
//回到首页
- (void)OnRootView;
//拨打电话
- (void)OnShowPhoneList:(NSString*)telphone;
@end
