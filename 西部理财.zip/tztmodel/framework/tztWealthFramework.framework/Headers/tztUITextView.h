//
//  tztUITextView.h
//  tztMobileApp
//
//  Created by yangdl on 13-2-22.
//  Copyright (c) 2013年 投资堂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztUIBaseViewDelegate.h"

@protocol tztUITextViewDelegate;
@protocol tztUIBaseViewDelegate;
@interface tztUITextView : UITextView<tztUIBaseViewDelegate>
{
    CGFloat _minHeight;
	CGFloat _maxHeight;
	
	int _maxNumberOfLines;
	int _minNumberOfLines;
	
	BOOL _animateHeightChange;
    
    BOOL _tztcheckdate;
    BOOL _tztsendaction;
    int _maxlen;
    id _tztdelegate;
    NSString* _tzttagcode;
    int _tztKeyboardType;
}
@property (nonatomic,retain) NSString* tzttagcode;
@property (nonatomic) int maxNumberOfLines;
@property (nonatomic) int minNumberOfLines;
@property int maxlen;
@property BOOL tztcheckdate;
@property BOOL tztsendaction;
@property int  tztKeyboardType;
@property (nonatomic, assign) id<tztUIBaseViewTextDelegate> tztdelegate;
- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
@end