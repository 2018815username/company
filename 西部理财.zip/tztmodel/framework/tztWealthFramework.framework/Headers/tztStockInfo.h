/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztStockInfo.h
 * 文件标识：
 * 摘    要：股票信息
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/

#import <Foundation/Foundation.h>
@interface tztStockInfo : NSObject
{
    NSString*   _stockCode; //股票代码
    NSString*   _stockName; //股票名称
    int         _stockType; //市场类型
}
@property(nonatomic, retain)NSString* stockCode;
@property(nonatomic, retain)NSString* stockName;
@property int   stockType;

- (BOOL)isVaildStock;
- (NSMutableDictionary*)GetStockDict;
- (void)setStockDict:(NSDictionary*)stockDict;
@end