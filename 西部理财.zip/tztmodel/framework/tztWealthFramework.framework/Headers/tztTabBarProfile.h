/*************************************************************
* Copyright (c)2009, 杭州中焯信息技术股份有限公司
* All rights reserved.
*
* 文件名称:		TZTTabBarProfile
* 文件标识:
* 摘要说明:		
* 
* 当前版本:	2.0
* 作    者:	yinjp
* 更新日期:	
* 整理修改:	
*
***************************************************************/


#import <Foundation/Foundation.h>
/*
 pageid:id标示
 image:图片
 title:标题
 disptitle:显示标题
 url:打开对应URL
 action:打开对应功能
 home:点击回首页
 selected:选中状态
 type:样式
 */
@interface tztTabBarItem : NSObject
{
    NSMutableDictionary* _itemInfo;
    BOOL _bHome;//点击回首页
}
@property (nonatomic,retain)NSMutableDictionary* itemInfo;
- (id)initWithString:(NSString*)str;
- (void)setTabItem:(NSString*)str;
//点击回首页
- (void)setBHome:(BOOL)bHome;
//获取对应信息
- (NSString*)getItemValue:(NSString*)strKey;
//设置对应信息
- (void)setItem:(NSString*)strKey value:(NSString*)strValue;
@end

@interface tztTabBarProfile : NSObject
{
	//tabBar配置项
    
    //tabBar项列表，包含顺序
	NSMutableArray	*_ayTabBarItem;
	
	//不显示配置名称，由图片提供
	int _nDrawName;
	int _nDrawNameColor;
    int _nDrawNameColorSel;
    
	//是否启用自动页面展示，显示不下的图标自动归集到列表中供用户选择
	int _nAutoLayout;
	
	//最大显示页面Item个数，默认-1不控制。
	int _nMaxDisplay;
	
	//Item高亮图片名称
	UIImage *_imgHight;
	
    //是否支持滑动
    int _nHandleMove;
    
    //固定宽度绘制图片
    int _nFixedIconWidth;
    
    //图片绘制风格：0 居中；1 置顶；2 沉底；
    int _nDrawIconStyle;
    int _nDrawSelectedStyle;
    int _nDrawMiddleLine;
    
    //两头留白
    int _nMarginHead;
    int _nMarginTail;
    
    //两头留白竖屏方式
    int _nMarginHeadEx;
    int _nMarginTailEx;
    
    //分割线
    int _nSeperator;
    unsigned long _nSeperatorColor;
    
    //选中序号
    int _nSelectIndex;
}

//tabBar项列表，包含顺序
@property(nonatomic,retain) NSMutableArray	*ayTabBarItem;

//不显示配置名称，由图片提供
@property int nDrawName;
@property int nDrawNameColor;
@property int nDrawNameColorSel;

//是否启用自动页面展示，显示不下的图标自动归集到列表中供用户选择
@property int nAutoLayout;

//最大显示页面Item个数，默认-1不控制。
@property int nMaxDisplay;

//Item高亮图片名称
@property(nonatomic,retain) UIImage *imgHight;

//是否支持滑动
@property int nHandleMove;

//固定宽度绘制图片
@property int nFixedIconWidth;

//图片绘制风格：0 居中；1 置顶；2 沉底；
@property int nDrawIconStyle;
@property int nDrawSelectedStyle;
@property int nDrawMiddleLine;

//两头留白
@property int nMarginHead;
@property int nMarginTail;

//两头留白竖屏方式
@property int nMarginHeadEx;
@property int nMarginTailEx;

//分割线
@property int nSeperator;
@property unsigned long nSeperatorColor;

//选中序号
@property int nSelectIndex;
-(BOOL) HaveTabBarItem;
-(void) LoadTabBarItem;
//根据配置的名称获取对应的索引，用于跳转
-(int)GetTabItemIndexByName:(NSString*)nsName;
//根据配置的ID获取对应的索引，用于跳转
-(int)GetTabItemIndexByID:(unsigned int)nsID;

@end

extern tztTabBarProfile    *g_ptztTabBarProfile;