/*************************************************************
* Copyright (c)2009, 杭州中焯信息技术股份有限公司
* All rights reserved.
*
* 文件名称:		tztUIButton
* 文件标识:
* 摘要说明:		自定义按钮控件
* 
* 当前版本:	2.0
* 作    者:	yinjp
* 更新日期:	
* 整理修改:	
*
***************************************************************/


#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <QuartzCore/QuartzCore.h>
#import "tztUIBaseViewDelegate.h"

@class tztUIButton;
@protocol tztUIButtonDelegate
@optional
-(void)OnButtonClick:(id)sender;
-(BOOL)OnCheckData:(id)sender;//检测数据
@end

@protocol tztUIBaseViewDelegate;
//tag|按钮类型|区域|title|textAlignment|font|backimage|image|需检测数据|valueimage|imageAlignment|
@interface tztUIButton : UIButton <tztUIBaseViewDelegate>
{
    UIButton* _imagebtn;
    UIButton* _valuebtn;
    
    NSString* _imagebtnname;
    int  _image;
    CGFloat _fontsize;
	//是否需要对页面数据进行校验
	BOOL	 _tztcheckdate;
	//代理
	id	_tztdelegate;
    NSString* _tzttagcode;
    float    _fCellWidth;
    float    _nHeight;
}
@property (nonatomic,retain) NSString* tzttagcode;
@property (nonatomic,retain)NSString* imagebtnname;
@property (nonatomic,assign)id<tztUIButtonDelegate> tztdelegate;
@property BOOL	tztcheckdate;
- (id)initWithProperty:(NSString*)strProperty withCellWidth_:(float)fWidth;
- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
@end
