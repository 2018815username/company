//
//  tztSysInitVC.h
//  tztmodel
//  初始化
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC.h"
#import "tztAppInit.h"

@protocol tztAppInitDelegate;
@interface tztSysInitVC : tztBaseVC
{
    id<tztAppInitDelegate> _tztdelegate;
}
@property (nonatomic,assign) id<tztAppInitDelegate> tztdelegate;

+ (tztSysInitVC *)sharedInit;
+ (void)show;
+ (void)hide;
@end
