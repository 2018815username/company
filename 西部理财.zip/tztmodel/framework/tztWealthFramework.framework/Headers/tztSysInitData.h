//
//  tztSysInitData.h
//  tztmodel
//
//  Created by yangares on 14-9-4.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface tztSysInitData : NSObject
//更新配置文件
+ (void)tztUpdateBundle;
//服务器均衡功能
+ (void)onJHAction:(void (^)(void))completion;
@end
