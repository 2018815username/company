//
//  tztUITextField.h
//  tztMobileApp
//
//  Created by yangdl on 13-2-22.
//  Copyright (c) 2013年 投资堂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztUIBaseViewDelegate.h"

@protocol tztUITextFieldDelegate;
@protocol tztUIBaseViewDelegate;
@interface tztUITextField : UITextField <tztUIBaseViewDelegate>
{
    BOOL _tztcheckdate;
    BOOL _tztsendaction;
    int _maxlen;
    id _tztdelegate;
    BOOL _tztalignment;
    int _tztKeyboardType;
    int _tztdotvalue;
    NSString* _tzttagcode;
}
@property (nonatomic,retain) NSString* tzttagcode;
@property int maxlen;
@property BOOL tztcheckdate;
@property BOOL tztsendaction;
@property BOOL tztalignment;
@property int  tztKeyboardType;
@property int  tztdotvalue;
@property (nonatomic, assign) id<tztUIBaseViewTextDelegate> tztdelegate;
- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
@end

@class TZTUITextField;
@protocol tztSysKeyboardDelegate;
@interface	TZTUITextField:tztUITextField<UITextFieldDelegate>
{
	BOOL bNeedCheck;
	int  nNumberofRow;
	id	m_pDelegate;
}
@property  BOOL bNeedCheck;
@property	int nNumberofRow;
@property (nonatomic,retain)id<tztSysKeyboardDelegate> m_pDelegate;
@end