//
//  tztBaseVC_Web.h
//  tztmodel
//
//  Created by yangares on 14-9-3.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC.h"
#import "tztHTTPWebView.h"
@interface tztBaseWebView : tztHTTPWebView
{
    NSString*       _strURL;
    int             _ntztReqNo;
}
@property(nonatomic,retain)NSString     *strURL;
- (tztHTTPWebViewLoadType)ontztWebURL:(UIWebView*)tztWebView strURL:(NSString *)strUrl WithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
- (void)setWebURL:(NSString *)strURL;
- (void)setLocalWebURL:(NSString*)strURL;
@end


@interface tztBaseVC_Web : tztBaseVC<tztHTTPWebViewDelegate>
{
    tztBaseWebView* _webView;
    NSString*       _strURL;
    BOOL _bHaveTitle;
    BOOL _bHaveTabBar;
    NSMutableDictionary* _webInfo;
}
@property(nonatomic,retain)NSString     *strURL;
@property(nonatomic,retain)NSMutableDictionary  *webInfo;
@property(nonatomic,retain)tztBaseWebView     *webView;
- (void)LoadLayoutView;
- (void)onSetWebDict:(NSMutableDictionary*)pDict;
- (void)setURL;
- (void)setWebURL:(NSString *)strURL;
//直接加载静态网页格式
- (void)LoadHtmlData:(NSString*)nsHTML;
- (void)setLocalWebURL:(NSString*)strURL;
- (void)CleanWebURL;

- (BOOL)IsHaveWebView;
//页面调用功能号处理 可派生处理 即 http://action:nAction/?strParams
- (void)OnAjaxMsg:(int)nAction withParams:(NSString*)strParams;

- (void)tztMsgBoxBlock:(NSMutableDictionary*)pDict block:(void (^)(void))block;
+ (id)tztAllocWebVC;
- (void)tztStringByEvaluatingJavaScriptFromString:(NSString*)strJs;
@end
