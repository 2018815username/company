//
//  tztSystemdefine.h
//  tztMobileApp
//
//  Created by yangares on 13-6-20.
//
//

#import <Foundation/Foundation.h>

#import <tztMobileBase/tztMobileBase.h>
#import <tztMobileBase/tztBase.h>

#ifndef tzt_NoControls
#import "tztUIControlsInfo.h"
#endif

#import "tztStockType.h"

#ifndef tztProtocol
#define tzt2013Protocol
#endif

#define tzt_Inner_Version @"20141014[001]"

#define COMM_ERR_NO_EXIT1      -204007  //时间戳错误
#define COMM_ERR_NO_EXIT2      -204009  //超时
#define COMM_ERR_NO_EXIT3      -207001  //密码错误
#define COMM_ERR_NO_EXIT4      -204001  //无效在线客户号

#define TZTMaxAccountType 11 //普通交易 融资融券交易
#define TZTMaxAccount 11 //多账号最大账号数
//
//#define L_(s) NSLocalizedString(s, nil)
//#define L_2(s, c) NSLocalizedString(s, c)
#define KDGREED(x) ((x)  * M_PI * 2)

#ifdef Support_EXE_VERSION
#define UseAnimated 1
#else
#define UseAnimated 0
#endif

#define TZTUIBaseInterfaceUsePNG        (1)     //是否使用图片作为界面素材 < 0 标示不使用PNG素材

//设置基类配置值
FOUNDATION_EXPORT void tztSetBasedef();
FOUNDATION_EXPORT BOOL validateMobile(NSString* mobile);
//
FOUNDATION_EXPORT NSString* GetTitleByID(int nMsgID);
//
FOUNDATION_EXPORT NSString* tztdecimalNumberByDividingBy(NSString* nsValue,int nNumber);
//
FOUNDATION_EXPORT UIViewController* gettztHaveViewContrller(Class vcClass,int nVcKind,NSString* nVcType, BOOL* bPush,BOOL bCreate);
//
FOUNDATION_EXPORT BOOL validateMobile(NSString* mobile);
NSString* tztScreenImage(NSString* imageName);
//用于获取字符串中对应key的值
/*
 此方法只处理可以将对应字符串(nsSrc)通过指定分隔符(nsMainSep、nsSubSep)后，获取对应key(nsKey)的值
 */
FOUNDATION_EXPORT NSString* tztRightInStringWithKey(NSString* nsSrc, NSString* nsKey, NSString* nsMainSep, NSString* nsSubSep);
void initappsys();

extern int          g_nScreenWidth;
extern int          g_nScreenHeight;
extern int          g_nToolbarHeight;

extern int         g_nJYBackBlackColor;
extern int         g_nHQBackBlackColor;
extern NSString     *g_nsdeviceToken;
extern int          g_nTradeListType;//zxl 20130719 当前交易列表类型（国泰用户不同的交易界面查看用户信息后返回当前交易类型界面）
extern NSString     *g_nsPeople;
extern NSString     *g_nsContact;
extern BOOL        g_bShowLock;
extern BOOL         g_nHaveDtPassword;
extern NSMutableDictionary *g_pDictLoginInfo;

extern NSString* g_nsUserCardID;        //资金理财身份证号码
extern NSString* g_nsUserInquiryPW;     //资金理财查询密码
extern int      g_nJyTypeCount;//zxl 20131012 交易界面中类型数量用户不同的交易界面区分展示不同
extern NSMutableArray      *g_ayTradeRights;
