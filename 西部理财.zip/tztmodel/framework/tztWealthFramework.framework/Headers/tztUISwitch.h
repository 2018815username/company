/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：NSObject+TZTSub.h
 * 文件标识：
 * 摘    要：按钮
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.02.29
 *
 * 备    注：
 *
 * 修改记录：
 * 
 *******************************************************************************/

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "tztUIBaseViewDelegate.h"

@protocol tztUIBaseViewDelegate;
@interface tztUISwitch : UIButton<tztUIBaseViewDelegate>
{
    BOOL _switched;
    //状态记录
	BOOL _checked;
    BOOL _tztcheckdate;
    NSString *_yestitle;
    NSString *_notitle;
    UIImage   *_noImage; //否 图片
    UIImage   *_yesImage;//是 图片
    NSString* _tzttagcode;
    id _tztdelegate;
    CGFloat _fontSize;
    id      _tzttarget;
    SEL     _tztaction;
    BOOL    _bUnderLine;
    NSString *_nsUnderLinseColor;
}
@property (nonatomic,assign) id<tztUIBaseViewCheckDelegate> tztdelegate;
@property (nonatomic,retain) NSString* tzttagcode;
@property (nonatomic) BOOL switched;
@property (nonatomic) BOOL checked;
@property (nonatomic,retain) NSString* yestitle;
@property (nonatomic,retain) NSString* notitle;
@property (nonatomic,retain) UIImage* noImage;
@property (nonatomic,retain) UIImage* yesImage;
@property BOOL tztcheckdate;
@property (nonatomic) CGFloat fontSize;
@property (nonatomic, assign) id tzttarget;
@property (nonatomic) SEL tztaction;
@property BOOL bUnderLine;
@property (nonatomic, retain)NSString* nsUnderLineColor;

- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (BOOL)onCheckdata;
- (void)checkboxButton:(id)sender;
@end

