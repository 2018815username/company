/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        工具栏更多显示view
 * 文件标识:        
 * 摘要说明:        
 * 
 * 当前版本:        2.0
 * 作    者:       yinjp
 * 更新日期:            
 * 整理修改:	
 *
 ***************************************************************/

#import <UIKit/UIKit.h>
#import "TZTUIBaseView.h"
#import "tztUINineGridView.h"

typedef enum
{
    tztBarMoreBottom    = 1 << 0,    //显示在底部 默认（default）
    tztBarMoreTop       = 1 << 1,    //显示在顶部
    tztBarMoreLeft      = 1 << 2,    //显示在左侧
    tztBarMoreRight     = 1 << 3,    //显示在右侧
}tztBarMoreViewPos;

typedef enum
{
    tztShowType_Grid = 0,   //  宫格显示（default）
    tztShowType_List = 1,   //  列表显示
}tztBarMoreShowType;

@interface tztBarMoreView : TZTUIBaseView<tztNineGridViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UITableView*            _pTableView;
    tztUINineGridView*      _pNineGridView;
    NSMutableArray*         _ayGrid;
    
    tztBarMoreViewPos       _nPosition;  //显示位置
    
    CGFloat                 _fCellHeight;   //单行高度
    CGSize                  _szOffset;       //偏移量
    CGFloat                 _fMenuWidth;    //显示宽度
    
    UIColor*                _bgColor;      //背景色
    int                     _nRowCount;     //行数
    int                     _nColCount;     //列数
    tztBarMoreShowType      _nShowType;
    UIColor*                _clSeporater;
    UIColor*                _clText;
}

@property(nonatomic, retain)UITableView*        pTableView;
@property(nonatomic, retain)tztUINineGridView*  pNineGridView;
@property(nonatomic) tztBarMoreViewPos          nPosition;
@property(nonatomic, retain)UIColor*            bgColor;
@property(nonatomic) CGFloat                    fCellHeight;
@property(nonatomic) CGSize                     szOffset;
@property(nonatomic) CGFloat                    fMenuWidth;
@property(nonatomic) int                        nRowCount;
@property(nonatomic) int                        nColCount;
@property(nonatomic) tztBarMoreShowType         nShowType;
@property(nonatomic,retain)UIColor*             clSeporater;
@property(nonatomic,retain)UIColor*             clText;

-(id)initWithShowType:(tztBarMoreShowType)showType;
-(void)SetAyGridCell:(NSArray*)ayGridCell;
-(void)setShowFrame:(CGRect)showFrame;
-(void)hideMoreBar;
@end
