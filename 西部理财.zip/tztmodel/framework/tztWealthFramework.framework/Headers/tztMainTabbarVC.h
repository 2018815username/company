//
//  tztMainTabbarVC.h
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztMainSideVC.h"
#import "tztTabBarView.h"

@interface tztMainTabbarVC : UITabBarController<UITabBarControllerDelegate, UIPopoverControllerDelegate, PPRevealSideViewControllerDelegate, UIGestureRecognizerDelegate, tztTabBarViewDelegate>
{
    //Pop 管理类
	UIPopoverController* _tztPopVC;
    tztUINavigationController* _tztLeftNavVC;
    tztUINavigationController* _tztRightNavVC;
    tztMainSideVC* _tztLeftSideVC;
    tztMainSideVC* _tztRightSideVC;
    tztTabBarView* _tztTabBarView;
}
@property (nonatomic,retain) tztTabBarView* tztTabBarView;
- (void)initSideViewController;
//根据配置的ID获取对应的索引，用于跳转
- (int)GetTabItemIndexByID:(unsigned int)nsID;
//根据配置的名称获取对应的索引，用于跳转
- (int)GetTabItemIndexByName:(NSString*)nsName;

- (void)setTabBarIndex:(int)nBarIndex options_:(NSDictionary*)options;

- (void)setTabBarIndex:(int)nBarIndex withBadge:(NSString*)strBadge;
- (void)setTabBarId:(int)nBarID withBadge:(NSString*)strBadge;
- (void)setTabBarName:(NSString*)strBarName withBadge:(NSString*)strBadge;
- (void)onRootTab:(int)nTab;
@end
