//
//  tztAppDelegate.h
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztAppInit.h"

@interface tztAppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, retain) UIWindow *window;
@end
