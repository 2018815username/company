//
//  tztUIVCBaseView.h
//  tztMobileApp
//
//  Created by yangdl on 13-2-23.
//  Copyright (c) 2013年 投资堂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztUIBaseControlsView.h"
#import "tztUIControlsInfo.h"
#import "TZTUIDatePicker.h"


@interface tztUIVCBaseView : UIScrollView<tztSysKeyboardDelegate, tztUIButtonDelegate , UIActionSheetDelegate>
{
    NSString* _strAction;//当前请求功能号
    NSString* _tableConfig;//配置文件名
    NSMutableArray* _tablelist;
    id        _tztDelegate;
    CGSize    _tableShowSize;
    NSMutableDictionary* _tableControls;
    UIDatePicker       *tztDatePicker;
    int     _nXMargin;
    int     _nYMargin;
@private
    CGFloat keyboardHeight;//键盘显示偏移高度
}
@property (nonatomic,retain)NSString* tableConfig;
@property (nonatomic,assign)id        tztDelegate;
@property (nonatomic,retain)UIDatePicker       *tztDatePicker;
@property (nonatomic,assign)BOOL      isAMonthAgo;      // 是否把时间提前一个月
@property (nonatomic,assign)BOOL      isTomorrowBegin;  // 是否从明天开始
@property (nonatomic,assign)BOOL      isTodayEnd;       // 是否今天结束
@property (nonatomic)int nXMargin;
@property (nonatomic)int nYMargin;
//获取数据显示区域
- (CGSize)getTableShowSize;
//关闭系统键盘
+(BOOL)OnCloseKeybord:(UIView*)pView;
-(BOOL)CheckInput;//校验输入
-(void)OnRefreshTableView;
//根据某行的Image来设置是否隐藏
-(void)SetImageHidenFlag:(NSString *)ImageStr bShow_:(BOOL)Show;
-(UIView*)getCellWithFlag:(NSString *)imageStr;

-(NSMutableArray*)getBaseControlsWithtableConfig:(NSString *)nsConfig;
-(UIView*)getViewWithTag:(int)nTag;
//清空界面控件的数据
-(void)clearControlData;

//设置label文本
-(void)setLabelText:(NSString*)nsLabel withTag_:(int)nTag;
//获取label文本
-(NSString*)GetLabelText:(int)nTag;

//自定义编辑框
//设置小数点位数
-(void)setEditorDotValue:(int)nDotValue withTag_:(int)nTag;
-(void)setEditorEnable:(BOOL)bEnable withTag_:(int)nTag;
-(void)setEditorText:(NSString*)nsText nsPlaceholder_:(NSString*)nsPlaceholder withTag_:(int)nTag;
-(NSString*)GetEidtorText:(int)nTag;
-(void)setEditorBecomeFirstResponder:(int)nTag;
-(void)setEditorResignFirstResponder:(int)nTag;
//checkButton
-(void)setCheckBoxValue:(BOOL)bChecked withTag_:(int)nTag;
-(BOOL)getCheckBoxValue:(int)nTag;

//button
-(void)setButtonTitle:(NSString*)nsTitle clText_:(UIColor*)clText forState_:(UIControlState)nState withTag_:(int)nTag;
-(NSString*)getButtonTitle:(int)nTag forState_:(UIControlState)nState;

//下拉
//combox控件可编辑的时候,调用
-(void)setComBoxTextField:(int)nTag;
-(void)setComBoxData:(NSMutableArray*)ayTitle ayContent_:(NSMutableArray*)ayContent AndIndex_:(int)nIndex withTag_:(int)nTag;
-(void)setComBoxData:(NSMutableArray*)ayTitle ayContent_:(NSMutableArray*)ayContent AndIndex_:(int)nIndex withTag_:(int)nTag bDrop_:(BOOL)bDrop;
-(void)setComBoxText:(NSString*)nsTitle withTag_:(int)nTag;
-(int)getComBoxSelctedIndex:(int)nTag;
-(UIView*)getComBoxViewWith:(int)nTag;
-(NSString*)getComBoxText:(int)nTag;
-(void)setComBoxPlaceholder:(NSString*)nsInfo withTag_:(int)nTag;

-(void)setButtonBGImage:(UIImage *)Image withTag_:(int)nTag;
//下拉框显示类型设置
-(void)setComBoxShowType:(tztDroplistViewType)type withTag_:(int)nTag;
//switch

//textview

@end
