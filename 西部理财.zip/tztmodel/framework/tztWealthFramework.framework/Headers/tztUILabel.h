//
//  tztUILable.h
//  tztMobileApp
//
//  Created by yangdl on 13-2-22.
//  Copyright (c) 2013年 投资堂. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "tztUIBaseViewDelegate.h"

@protocol tztUIBaseViewDelegate;

@interface tztUILabel : UILabel<tztUIBaseViewDelegate>
{
    NSString* _tzttagcode;//
    float     _fCellWidth;//整行的宽度，用于百分比配置界面 一行多个控件
    UIEdgeInsets _insets;
}
@property (nonatomic,retain) NSString* tzttagcode;
- (id)initWithProperty:(NSString*)strProperty withCellWidth_:(float)fWidth;
- (id)initWithProperty:(NSString*)strProperty;
- (void)setProperty:(NSString*)strProperty;
- (void)setUIEdgeInsets:(UIEdgeInsets)insets;
@end
