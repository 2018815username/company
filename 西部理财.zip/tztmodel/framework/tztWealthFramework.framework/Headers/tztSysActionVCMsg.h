//
//  tztSysActionVCMsg.h
//  tztmodel
//
//  Created by yangares on 14-9-11.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface tztSysActionVCMsg : NSObject

+ (void)tztOpenURL:(NSString*)strURL;
@end
FOUNDATION_EXPORT void tztOpenURL(NSString* strURL);