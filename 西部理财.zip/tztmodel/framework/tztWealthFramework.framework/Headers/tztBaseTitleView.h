//
//  tztBaseTitleView.h
//  tztmodel
//
//  Created by yangares on 14-8-27.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum tztTitleShowType
{
	tztTitleNormal = 0,//普通模式
	tztTitleUpDown = 1 << 0, //上下模式
	tztTitleLeftRight = 1 << 1, //左右模式
}tztTitleShowType;

typedef enum tztTitleBtnType
{
	tztBtnSearchStock = 0,//个股搜索
	tztBtnFont = 1, //修改字体
    tztBtnSign = 2, //订阅
    tztBtnEdit = 3, //修改、编辑
	tztBtnKH = 4, //开户
    tztBtnOnline = 5, //在线客服
    tztBtnFilter = 6, //筛选
    tztBtnFilterIcon = 7, //筛选图标
    tztBtnLogoAbout = 8,//logo 关于
    tztBtnHide = 9,//不显示
    tztBtnReturn = 10,//返回前一页面
    tztBtnClose = 11,//退出流程
    tztBtnMap = 15,//地图
    tztBtnClear = 16,//一键清除 调用JS  @“clearKey();”
    tztBtnUserIcon = 98,//自定义图片
    tztBtnUserText = 99 //自定义文字 (不超过4个汉字)
}tztTitleBtnType;

@protocol tztTitleViewDelegate <NSObject>
@end

@interface tztBaseTitleView : UIView
{
    id _tztdelegate;
    tztTitleShowType _showType;
    UIButton* _leftBtn;
    UIButton* _rightBtn;
    UIButton* _preBtn;
    UIButton* _nextBtn;
    UIButton* _preHideBtn;
    UIButton* _nextHideBtn;
    
    UIButton* _btn1;
    UIButton* _btn2;
    UIButton* _btn3;
    UIButton* _btn4;
    
    UILabel* _centerTitle;
    UILabel* _topTitle;
    UILabel* _bottomTitle;
    UILabel* _leftTitle;
    UILabel* _rightTitle;
    
    UIImageView* _backImage;
    
    NSString* _leftType;
    NSString* _rightType;
}
@property (nonatomic, assign) id<tztTitleViewDelegate> tztdelegate;
- (void)initSubView;
- (void)setTitleShowType:(tztTitleShowType)showType;
//前后按钮类型
- (void)setTitlePreNextHide:(BOOL)bHide;
//左侧按钮类型
- (void)setTitleLeftType:(NSString*)strType;
- (int)getTitleLeftType;
//右侧按钮类型
- (void)setTitleRightType:(NSString*)strType;
- (int)getTitleRightType;
- (void)replaceTitleLeftType:(int)ntarget with:(int)nreplace;
- (void)replaceTitleRightType:(int)ntarget with:(int)nreplace;

//标题
- (void)setTitle:(NSString*)strTitle;
- (void)setLeftBtnText:(NSString*)strText;
- (void)setRightBtnText:(NSString*)strText;
- (void)setLeftUrl:(NSString*)strUrl jsfun:(NSString*)strJS;
- (void)setRightUrl:(NSString*)strUrl jsfun:(NSString*)strJS;
@end
