//
//  NumberKeyboard.h
//  medcalc
//
//  Created by Pascal Pfiffner on 03.09.08.
//	Copyright 2009 MedCalc. All rights reserved.
//  This sourcecode is released under the Apache License, Version 2.0
//  http://www.apache.org/licenses/LICENSE-2.0.html
//  
//  A custom keyboard that allows to input numerical values and change units
// 

#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>

typedef enum tztKeyboardViewType
{
    tztKeyboardViewTypeNon = 0,
    tztKeyboardViewIsNumber = 1,            /*输入值是数值*/
    tztKeyboardViewNOABC = 1 << 1,          /*不允许ABC*/
    tztKeyboardViewNODot = 1 << 2,          /*不允许(.)*/
    tztKeyBoardViewIsSys = 1 << 3,          /*不允许切换到自定义键盘*/
}tztKeyboardViewType;

@protocol tztKeyboardViewDelegate;
@interface tztKeyboardView : UIView<UIInputViewAudioFeedback>
{
	id<UITextInput> _textView;
    UIButton* _customButton;
    tztKeyboardViewType _keyboardViewType;
    int         _tztdotvalue;
}
@property (strong) id<UITextInput> textView;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *characterKeys;
@property (nonatomic)tztKeyboardViewType keyboardViewType;
@property int tztdotvalue;

-(IBAction)onButtonPressed:(id)sender;
- (void)addCustomButton:(NSString *)name title:(NSString *)title;
- (void)removeCustomButton;
+(tztKeyboardView *)shareKeyboardView;
@end