//
//  tztBaseVC_LoginWeb.h
//  tztmodel
//
//  Created by yangares on 14-9-9.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztBaseVC_Web.h"

@interface tztBaseVC_LoginWeb : tztBaseVC_Web
{
    int _nLoginType;//默认交易
    int _nLoginKind;//默认强权限登陆
    tztBaseVC_Web* _tztbaseVC_web;
    NSMutableDictionary* _loginWebInfo;
}
@property(nonatomic,retain)tztBaseVC_Web  *tztbaseVC_web;
@property(nonatomic,retain)NSMutableDictionary  *loginWebInfo;
- (void)OnLoginBack;
@end
