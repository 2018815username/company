/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztMoblieStockComm.h
 * 文件标识：
 * 摘    要：通讯调度相关对象 加入通讯对象、删除通讯对象 发送请求
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.02.29
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/

#import <Foundation/Foundation.h>
#import "tztGCDDataSocket.h"


//2011协议 读取通讯数据协议字典时使用
#define TZTFormatReq @"req"
#define TZTFormatAns @"ans"
#define TZTFormatUnicode   @"unicode"
#define TZTFormatGBKcode   @"gbk"

@interface tztMoblieStockComm :NSObject <tztSocketDataDelegate>
{
    tztGCDDataSocket* _tztGCDDataSocket;
    int _ntranstype; //服务器类别
    BOOL _bCanSend;
    NSMutableArray* _ayObjList;//对象列表
    NSDictionary* _reqAns; //2011协议 通讯数据协议字典
    
    dispatch_source_t _sendTimer;
    CGFloat  _fTimeCount;//计数
    int _recount;//重连次数
    BOOL _bOpenSSL;
}
//通讯管理静态对象
+ (tztMoblieStockComm *)getShareInstance:(int)nSession;
+ (tztMoblieStockComm *)getInstance:(int)nSession;
+ (void)freeShareInstance:(int)nSession;

+ (tztMoblieStockComm *)getShareInstance;
+ (tztMoblieStockComm *)getInstance;
+ (void)freeShareInstance;

+ (tztMoblieStockComm *)getSharehqInstance;
+ (tztMoblieStockComm *)gethqInstance;
+ (void)freeSharehqInstance;

+ (tztMoblieStockComm *)getSharejhInstance;
+ (tztMoblieStockComm *)getjhInstance;
+ (void)freeSharejhInstance;

//华西独立资讯连接
+ (tztMoblieStockComm *)getSharezxInstance;
+ (tztMoblieStockComm *)getzxInstance;
+ (void)freeSharezxInstance;

//开户单独连接
+ (tztMoblieStockComm *)getSharekhInstance;
+ (tztMoblieStockComm *)getkhInstance;
+ (void)freeSharekhInstance;

//清空所有连接
+ (void)freeAllInstanceSocket;
+ (void)freeAllCommInstance;
//重连连接
+ (void)getAllInstance;

- (void)onInitGCDDataSocketWithBlock:(void (^)(void))completion;
- (void)onInitGCDDataSocket;
- (void)freeSocketComm;
- (void)setOpenSSL:(BOOL)bSSL;
- (void)onChangeHostPort:(NSNotification*)notifaction;
- (BOOL)setStockHostPort;
- (void)setStockHostPort:(NSString*)nsHost nPort_:(UInt32)nPort;
//加入通讯调度列表
- (void)addObj:(id<tztSocketDataDelegate>)obj;
//从调度列表删除对象
- (void)removeObj:(id<tztSocketDataDelegate>)obj;
//发送数据 参数:请求参数列\参数默认值\参数数据
- (NSUInteger)onSendDataAction:(NSString*)strAction withDictValue:(NSMutableDictionary *)sendvalue;
- (NSUInteger)onSendDataAction:(NSString*)strAction withDictValue:(NSMutableDictionary *)sendvalue bShowProcess:(BOOL)bShowProcess;
@end

