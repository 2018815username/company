/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztNewReqno.h
 * 文件标识：
 * 摘    要：Reqno组成 
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/


#import <Foundation/Foundation.h>

@interface tztNewReqno : NSObject
{
    long _iphonekey; //句柄
    int _reqno;      //序号
    int _tokenkind;  //token类型
    int _tokenindex; //token序号
    int _reqdefone; //自定义reqno属性
}
//reqno NSString
- (id)initwithString:(NSString *)strNewReqno;
//reqno NSString
+ (tztNewReqno *)reqnoWithString:(NSString *)strNewReqno;
//获取句柄key
- (void)setIphoneKey:(long)nkey;
- (long)getIphoneKey;
//获取序号
- (void)setReqno:(int)nreqo;
- (int)getReqno;
//获取token类型
- (void)setTokenKind:(int)nkind;
- (int)getTokenKind;
//获取token序号
- (void)setTokenIndex:(int)nindex;
- (int)getTokenIndex;
//获取自定义属性值
- (void)setReqdefOne:(int)nreqdefone;
- (int)getReqdefOne;
//获取Reqno NSString
- (NSString *)getReqnoValue;

//转换成reqno NSString
+ (NSString *)key:(long)nkey reqno:(int)nreqo;
//转换成reqno NSString
+ (NSString *)key:(long)nkey reqno:(int)nreqo tokenkind:(int)nkind tokenindex:(int)nindex;
//转换成reqno NSString
+ (NSString *)key:(long)nkey reqno:(int)nreqo tokenkind:(int)nkind tokenindex:(int)nindex reqdefone:(int)nreqdefone;

@end

FOUNDATION_EXPORT NSString* tztKeyReqno(long nKey,int nReqno);
FOUNDATION_EXPORT NSString* tztKeyReqnoToken(long nKey,int nReqno,int tokenkind,int tokenindex);
FOUNDATION_EXPORT NSString* tztKeyReqnoTokenOne(long nKey,int nReqno,int tokenkind,int tokenindex, int reqdefone);
FOUNDATION_EXPORT int tztGetReqno(NSString* strReqno);
FOUNDATION_EXPORT long tztGetIphoneKey(NSString* strReqno);