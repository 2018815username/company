//
//  tztBundleValue.h
//  tztbase
//
//  Created by yangares on 14-9-5.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>
#define tztScreen_Image(x) tztScreenImage(x)
void tztAppInitStrings(BOOL reload);

FOUNDATION_EXPORT NSString* tztScreenImage(NSString* imageName);
FOUNDATION_EXPORT NSBundle* tztAppStringBundle(NSString* strSys);
FOUNDATION_EXPORT NSString* tztAppStringValue(NSString* strSys,NSString* strKey,NSString* strDefault);
FOUNDATION_EXPORT int tztAppStringInt(NSString* strSys,NSString* strKey,int nDefault);
FOUNDATION_EXPORT NSString* tztAppSysValueWithDefault(NSString* strKey,NSString* strDefault);
FOUNDATION_EXPORT int tztAppSysIntValueWithDefault(NSString* strKey,int nDefault);
FOUNDATION_EXPORT NSString* tztAppSysValue(NSString* strKey);
FOUNDATION_EXPORT int tztAppSysIntValue(NSString* strKey);

@interface NSString (tztappprivate)
- (NSString*)tztAppStringValue:(NSString*)strSys;
- (int)tztAppStringInt:(NSString*)strSys;
- (NSString*)tztAppStringValue:(NSString*)strSys value:(NSString*)strValue;
- (int)tztAppStringInt:(NSString*)strSys value:(int)nValue;
- (NSMutableArray *)tztSeparatedByString:(NSString *)separator;
@end
