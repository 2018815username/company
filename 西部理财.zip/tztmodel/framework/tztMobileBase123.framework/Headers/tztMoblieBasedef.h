/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztSystemdef.h
 * 文件标识：
 * 摘    要：系统宏定义
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 * 
 *******************************************************************************/

#import <Foundation/Foundation.h>
#include <unistd.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/sockio.h>
#include <net/if.h>
#include <errno.h>
#include <net/if_dl.h>
#include <ctype.h>

// tolower
#include <stdlib.h>
// free

#include <stdio.h>
// sprintf

#include <memory.h>
// memset

#include <string.h>
// strcpy

#include <math.h>
// fabs
// pow
// sqrt
#include <time.h>
#include <stdarg.h>

#import "tztNSLog.h"

#define NSStringEncodingGBK 0x80000632

#define tztProtocol2013 2013//使用2013协议

#ifndef tztProtocol2013
#define tztProtocol2011 2011//使用2011协议
#endif

#define TZT_OPENSSL
//
#ifdef TZT_OPENSSL  //启用 OpenSLL 需要openssl动态库
#undef TZT_OPENSSL
#endif


#ifndef TZT_SupportZip //通讯压缩
#define TZT_SupportZip
#endif

#ifdef TZT_HQServer //支持行情服务器
#undef TZT_HQServer
#endif

#define tztHTTPAction @"http://action:"
#define tztHTTPStrSep tztAppStringValue(tztappstringshttp,@"tztapp_httpsep",@"&&")
//特殊标识 是否重发请求
#define tztIphoneReSend  @"tztIphoneReSend"
//特殊标识 交易类型
#define tztTokenType   @"tokentype"
//请求URL标识
#define tztIphoneREQUSTURL @"TZTREQUESTURL"
//请求URL参数 标识
#define tztIphoneREQUSTPARAM @"TZTREQUESTPARAM"
//请求URL 校验标识
#define tztIphoneREQUSTCRC @"TZTREQUESTCRC"

#define tztIphoneSignature @"signature"
#define tztIphonefiledata @"tztfiledata"
#define tztIphoneOriginal  @"original"

#define tztXMargin (5)
#define tztYMargin (5)


//交易类别
typedef enum tztTradeAccountType
{
    TZTAccountPTType = 0, //普通交易
	TZTAccountRZRQType = 1,//融资融券交易
	TZTAccountQHType = 2, //期货交易
	TZTAccountHKType = 3,//港股交易
    
    TZTAccountCommLoginType = 10,//通讯密码登录
}tztTradeAccountType;


#define ISNSStringValid(x) (x != NULL && [x length] > 0)

#define TZTStringToIndex(x,y){if(ISNSStringValid(x)) {y = [x intValue];} else { y = -1;} }

#define ISMobileCodeValid(x) (x != NULL && [x length] == 11)

#define ISEmailValid(x) (x != NULL && [[NSPredicate predicateWithFormat:@"SELF MATCHES %@", @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"] evaluateWithObject:x])

#define TZTScreenWidth [[UIScreen mainScreen] bounds].size.width
#define TZTScreenHeight [[UIScreen mainScreen] bounds].size.height

#define TZTNavbarHeight 44
#define TZTStatuBarHeight 20
#define TZTToolBarHeight 44

//不带底部工具栏界面表格的最大显示高度
#define TZTValidHeightNoToolBar (TZTScreenHeight - TZTStatuBarHeight - TZTNavbarHeight)
//带底部工具栏界面表格的最大显示高度
#define TZTValidHeightWithToolBar (TZTScreenHeight - TZTStatuBarHeight - TZTNavbarHeight - TZTToolBarHeight)

//统一字体
#define tztUIBaseViewTextBoldFont(fontsize) [UIFont fontWithName:@"HelveticaNeue-Bold" size:((fontsize > 0)?fontsize:15.f)]
#define tztUIBaseViewTextFont(fontsize) [UIFont fontWithName:@"HelveticaNeue" size:((fontsize > 0)?fontsize:15.f)]
//像素转换成字体
#define tztUIBaseViewTextFontWithPx(pxsize) tztUIBaseViewTextFont((pxsize*72/96))

//Notification 定义
//均衡初始化
#define TZTNotifi_OnInitFinish          @"TZT_OnInitFinish"
#define TZTNotifi_OnConnectFail         @"TZTSysOnConnectFail"
#define TZTNotifi_OnJhActionFail        @"TZTSysJhActionFail"
#define TZTNotifi_OnFinishLoad          @"TZTNotifi_OnFinishLoad"
#define tztTabbarStatusFile             @"tztTabbarStatusFile"

//用户校验失败
#define TZTNotifi_CheckUserLoginFail        @"TZTNotifi_CheckUserLoginFail"
//设置服务器地址和端口
#define TZTNotifi_OnSetServerAddPort        @"TZTNotifi_OnSetServerAddPort"
//获取服务器地址和端口
#define TZTNotifi_OnGetServerAddPort        @"TZTNotifi_OnGetServerAddPort"
//打开文档
#define TZTNotifi_OpenDocument              @"TZTNotifi_OpenDocument"
//登录状态变更
#define TZTNotifi_ChangeLoginState          @"TZTNotifi_ChangeLoginState"
//
#define TZTNotifi_ChangeShortCut            @"TZTNotifi_ChangeShortCut"
//修改底部tabbar显示状态
#define TZTNotifi_ChangeTabBarStatus        @"TZTNotifi_ChangeTabBarStatus"

#import "NSData+Base64.h"
#import "NSObject+TZTPrivate.h"
#import "tztSystemFunction.h"
#import "NSString+tztHttpPrivate.h"
#import "tztBase.h"

extern short g_ntztProtocol; //通讯数据协议 目前支持2011、2013两种协议 
extern BOOL  g_btztEncode; //新加密方式
extern NSString *g_nsJhAction; //均衡功能号
extern NSString *g_nsUpVersion; //升级版本号
extern NSString *g_nsOnLineAction;//心跳功能号
extern NSString *g_nsBundlename; //自定义bundle名称
extern int g_tztLogLevel;
extern int g_newHeartBeat;

extern NSString     *g_nsLogMobile; //登录手机号
extern int          g_nLogVolume;   //登录号

extern int   g_ntztHaveBtnOK;//网页alert是否带确定按钮
extern NSString*   g_nsMessageBoxTitle;//对话框标题

extern int   g_Http_MAX_AGE;

extern int   g_nSkinType;//0或空－默认 1-蓝白 2-红白

extern int   g_nOpenAccountType;//开户单独通道

#if TARGET_OS_IPHONE
extern BOOL g_bChangeNav;
extern tztUINavigationController*  g_navigationController;
extern tztUINavigationController*  g_CallNavigationController;
#endif

FOUNDATION_EXPORT void tztMobileBaseInit();
