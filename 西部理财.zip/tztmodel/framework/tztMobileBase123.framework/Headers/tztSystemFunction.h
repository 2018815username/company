/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztSystemFunction.h
 * 文件标识：
 * 摘    要：系统级函数
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2013.04.24
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/
#ifndef _TZTMOBILEBASE_tztSystemFunction_H
#define _TZTMOBILEBASE_tztSystemFunction_H

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString* GetTztBaseSDKVer();

FOUNDATION_EXPORT BOOL tztcompress(const char* pZipData,unsigned long* ZipLen, char* pUnZipData,int lOrigLen);

FOUNDATION_EXPORT BOOL tztcompress2(const char* pZipData,unsigned long* ZipLen, char* pUnZipData,NSUInteger lOrigLen);

FOUNDATION_EXPORT BOOL tztUncompress(const char* pZipData,long ZipLen, char* pUnZipData,int lOrigLen);

FOUNDATION_EXPORT void DesConvert(const char* key,unsigned char* inp,unsigned char*outp, NSUInteger len);
FOUNDATION_EXPORT long doubletolong(double fValue);

FOUNDATION_EXPORT NSString* GetTztBundlePath(NSString* fileName,NSString* filetype, NSString* filedir);
FOUNDATION_EXPORT NSString* GetTztBundlePlistPath(NSString* fileName);

FOUNDATION_EXPORT NSString* GetDocumentPath(NSString* fileName,BOOL bCreate);
FOUNDATION_EXPORT BOOL writeApplicationAryData(NSArray* data,NSString* fileName);
FOUNDATION_EXPORT NSArray* readApplicationAryData(NSString* fileName);
FOUNDATION_EXPORT BOOL writeApplicationDictData(NSDictionary* data,NSString* fileName);
FOUNDATION_EXPORT NSDictionary* readApplicationDictData(NSString* fileName);

//在列表中查找对应数据 参数:列表数据 string:查找数据
//返回值:－1:不存在;其他:列表序号
FOUNDATION_EXPORT int FindStringByArray(NSArray* ayList ,NSString* strString);
//合并两个列表生成新列表 参数:第一个列表 Sencond:第二个列表 NewAy:新生成列表
FOUNDATION_EXPORT BOOL MargenStringArray(NSMutableArray* ayFirst,NSMutableArray* aySecond,NSMutableArray* ayNew);

FOUNDATION_EXPORT NSString* GetPathWithListName(NSString* strFile,BOOL bCreate);
FOUNDATION_EXPORT BOOL SetDictByListName(NSDictionary* data,NSString* strFile);
FOUNDATION_EXPORT NSMutableDictionary* GetDictByListName(NSString* strFile);
FOUNDATION_EXPORT BOOL SetArrayByListName(NSArray* data,NSString* strFile);
FOUNDATION_EXPORT NSMutableArray* GetArrayByListName(NSString* strFile);

FOUNDATION_EXPORT long doubletolong(double fValue);
FOUNDATION_EXPORT NSString* TimeToFormatString(NSString* NsFormat,NSTimeInterval time);
FOUNDATION_EXPORT int TZTGetCurrentTime();
FOUNDATION_EXPORT int TZTGetCurrentDate();
FOUNDATION_EXPORT NSTimeInterval tztStringToTime(int nYear,int nMonth, int nDay,int nHour, int nMin,int nSec, int  nDST);
FOUNDATION_EXPORT int GetFormatTime(NSString* NsFormat,NSTimeInterval time);

FOUNDATION_EXPORT void tztWriteLog(NSString* strlog,BOOL bLog);
FOUNDATION_EXPORT NSString *tztExtractFileNameWithoutExtension(const char *filePath, BOOL copy);
FOUNDATION_EXPORT NSComparisonResult compareServerDateCount(NSMutableDictionary *firstValue, NSMutableDictionary *secondValue, void *context);
FOUNDATION_EXPORT id tztGetDataInArrayByIndex(NSArray* data, int index);
FOUNDATION_EXPORT void tztCopyAjaxDataFromBundle(NSString* bundleName, NSString* nsFloder);
FOUNDATION_EXPORT void tztGetAjaxFileCrc(NSString* strPath, NSMutableDictionary* ayFileCrc);

FOUNDATION_EXPORT void tztSetUserData(NSString* strKey,NSString* strValue);
FOUNDATION_EXPORT NSString* tztGetUserData(NSString* strKey);
#endif