//
//  tztNSLog.h
//  tztMobileApp
//
//  Created by yangares on 13-5-18.
//
//

#ifndef tztMobileBase_tztNSLog_h
#define tztMobileBase_tztNSLog_h

//#define TZTLOG //记录日志

#define TZTLOG_FLAG_ERROR    (1 << 0)  // 0...0001
#define TZTLOG_FLAG_WARN     (1 << 1)  // 0...0010
#define TZTLOG_FLAG_INFO     (1 << 2)  // 0...0100
#define TZTLOG_FLAG_VERBOSE  (1 << 3)  // 0...1000

#define TZTLOG_LEVEL_ERROR   (TZTLOG_FLAG_ERROR)                                                    // 0...0001
#define TZTLOG_LEVEL_WARN    (TZTLOG_FLAG_ERROR | TZTLOG_FLAG_WARN)                                    // 0...0011
#define TZTLOG_LEVEL_INFO    (TZTLOG_FLAG_ERROR | TZTLOG_FLAG_WARN | TZTLOG_FLAG_INFO)                    // 0...0111
#define TZTLOG_LEVEL_VERBOSE (TZTLOG_FLAG_ERROR | TZTLOG_FLAG_WARN | TZTLOG_FLAG_INFO | TZTLOG_FLAG_VERBOSE) // 0...1111

#define TZTLOG_ERROR   (g_tztLogLevel & TZTLOG_FLAG_ERROR)
#define TZTLOG_WARN    (g_tztLogLevel & TZTLOG_FLAG_WARN)
#define TZTLOG_INFO    (g_tztLogLevel & TZTLOG_FLAG_INFO)
#define TZTLOG_VERBOSE (g_tztLogLevel & TZTLOG_FLAG_VERBOSE)

//上传错误信息至服务器
#define TZTLogErrorUp(format, ...) if(1) { NSString* strFile = tztExtractFileNameWithoutExtension(__FILE__,YES);\
                    NSString* strFunction = tztExtractFileNameWithoutExtension(__FUNCTION__,YES);\
                    NSString* strInfo = [NSString stringWithFormat:@"File=%@\r\nFunction=%@\r\nLine=%d\r\n",strFile,strFunction,__LINE__]; \
                    NSString* strLog = [strInfo stringByAppendingFormat:format, ## __VA_ARGS__];\
                    [tztNewMSParse UpLoadLogInfo:strLog]; \
                    tztWriteLog(strLog,TRUE); \
                    [strFunction release];\
                    [strFile release];\
                                    }
#define TZTLogTest(x) {\
    g_tztLogLevel = TZTLOG_LEVEL_ERROR;\
    NSString* strFile = tztExtractFileNameWithoutExtension(__FILE__,YES);\
    NSString* strFunction = tztExtractFileNameWithoutExtension(__FUNCTION__,YES);\
    NSLog(@"File=%@\nFunction=%@\nLine=%d\n %@",strFile,strFunction,__LINE__,x); \
                        }

#define TZTLogError(format, ...) if(TZTLOG_ERROR) { \
                    NSString* strFile = tztExtractFileNameWithoutExtension(__FILE__,YES);\
                    NSString* strFunction = tztExtractFileNameWithoutExtension(__FUNCTION__,YES);\
                    NSString* strInfo = [NSString stringWithFormat:@"File=%@\r\nFunction=%@\r\nLine=%d\r\n",strFile,strFunction,__LINE__]; \
                    NSString* strLog = [strInfo stringByAppendingFormat:format, ## __VA_ARGS__];\
                    tztWriteLog(strLog,TRUE); \
                    [strFunction release];\
                    [strFile release];\
            }
#define TZTLogWarn(format, ...)  if(TZTLOG_WARN) { NSLog(format, ## __VA_ARGS__); }
#define TZTLogInfo(format, ...)  if(TZTLOG_INFO) { NSLog(format, ## __VA_ARGS__); }
#define TZTLogVerbose(format, ...) if(TZTLOG_VERBOSE) { NSLog(format, ## __VA_ARGS__);}

#define TZTNSLog(format, ...) TZTLogVerbose(format, ## __VA_ARGS__)
#endif
