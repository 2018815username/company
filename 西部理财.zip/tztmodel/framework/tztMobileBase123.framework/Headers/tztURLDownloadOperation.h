#import <Foundation/Foundation.h>


@interface tztURLDownloadOperation : NSOperation
- (id)initWithURL:(NSURL*)url;
@property (nonatomic, readonly) NSError* error;
@property (nonatomic, strong) NSData* data;
@property (nonatomic, copy) void (^progressCallback) (float);
@end