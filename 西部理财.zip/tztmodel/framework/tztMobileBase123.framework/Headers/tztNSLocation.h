//
//  tztNSLocation.h
//  tztMobileApp_HTSC
//
//  Created by yangares on 13-12-10.
//
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>

@interface tztNSLocation : NSObject<CLLocationManagerDelegate>
{
    NSString* _strGpsX;
    NSString* _strGpsY;
    BOOL _bGetOk;
    CLLocationManager* _clManager;
    BOOL _bHiddenTips;
}
@property (nonatomic,retain) NSString* strGpsX;
@property (nonatomic,retain) NSString* strGpsY;
@property BOOL bHiddenTips;
@property BOOL bGetOk;
- (void)getLocation:(void (^)(NSString* strGpsX,NSString* strGpsY))completion;
+ (void)initShareClass;
+ (void)freeShareClass;
+ (tztNSLocation*)getShareClass;
- (void)stopUpdatingLocation;
- (void)startUpdatingLocation;
@end
