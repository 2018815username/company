/*************************************************************
 *	Copyright (c)2009, 杭州中焯信息技术有限公司
 *	All rights reserved.
 *
 *	文件名称：	TZTServerListDeal.h
 *	文件标识：	
 *	摘	  要：	服务器地址
 *              增加了服务器类型扩展功能
 *	当前版本：	3.0
 *	作	  者：	yangdl
 *	更新日期：	
 *
 ***************************************************************/

#import <Foundation/Foundation.h>
@interface TZTServerListDeal : NSObject
{
	NSString*       _strJYAdd;			// 交易地址
	NSString*       _strHQAdd;          // 行情地址
    NSString*       _strRZAdd;          // 认证地址
    NSString*       _strJHAdd;          // 均衡地址
    NSString*       _strZXAdd;          // 资讯地址
    NSString*       _strKHAdd;          // 开户地址
    
    
	int             _nJYPort;			// 交易端口
    int             _nHQPort;           // 行情端口
    int             _nRZPort;           // 认证端口
    int             _nJHPort;           // 均衡端口
    int             _nZXPort;           // 资讯端口
    int             _nKHPort;           // 开户端口
    
	BOOL            _bForce;			// 是否强制地址

	NSMutableArray* _ayAddList;			//服务器地址列表
	NSMutableArray* _ayPortList;			//端口列表
    
	NSMutableDictionary* _ayLocList;		//本地地址列表
	NSMutableDictionary* _ayList;			//服务器地址列表
	
	NSMutableArray* _ayUserAddList;			//用户自定义服务器列表
	NSMutableArray* _ayUserPortList;		//用户自定义端口列表
    
    NSMutableArray* _ayJHAddList;           //均衡服务器列表
    
    NSString* _strUpdateAdd;    //升级地址
    NSString* _strUpdateMsg;    //升级提示信息
    int       _nUpdateSign;    //升级类型
    
    int _nSessionMaxIndex;
    int _nJHActive; //是否开启均衡
    
    NSMutableDictionary* _tztServerInfo;//当前通讯通道使用服务器信息 当前服务器、当前端口、服务器列表
    
    dispatch_source_t _sendTimer;
    __block BOOL _bJHLoop;
    __block int _nJHCount;
    __block NSInteger _nJHMax;
}
@property (nonatomic, retain) NSString*     strJYAdd;			// 交易地址
@property (nonatomic, retain) NSString*     strHQAdd;           // 行情地址
@property (nonatomic, retain) NSString*     strRZAdd;           // 认证地址
@property (nonatomic, retain) NSString*     strJHAdd;           // 均衡地址
@property (nonatomic, retain) NSString*     strZXAdd;           // 资讯地址
@property (nonatomic, retain) NSString*     strKHAdd;           // 开户地址
@property (nonatomic) int                   nJYPort;			// 交易端口
@property (nonatomic) int                   nHQPort;            // 行情端口
@property (nonatomic) int                   nRZPort;            // 认证端口
@property (nonatomic) int                   nJHPort;            // 均衡端口
@property (nonatomic) int                   nZXPort;            // 均衡端口
@property (nonatomic) int                   nKHPort;            // 开户端口

@property BOOL                              bForce; // 是否强制地址

@property (nonatomic, retain) NSMutableDictionary* ayLocList;		//本地列表
@property (nonatomic, retain) NSMutableDictionary* ayList;			//服务器列表
@property (nonatomic, retain) NSMutableArray* ayAddList;			//服务器地址列表
@property (nonatomic, retain) NSMutableArray* ayPortList;			//端口列表

@property (nonatomic, retain) NSMutableArray* ayUserAddList;		//用户自定义服务器列表
@property (nonatomic, retain) NSMutableArray* ayUserPortList;		//用户自定义端口列表

@property (nonatomic, retain) NSMutableArray* ayJHAddList;			//均衡服务器列表

@property (nonatomic, retain) NSString* strUpdateAdd;    //升级地址
@property (nonatomic, retain) NSString* strUpdateMsg;    //升级提示信息
@property int       nUpdateSign;    //升级类型

+(void)initShareClass;
+(void)freeShareClass;
+(TZTServerListDeal*)getShareClass;
//保存或读取服务器地址信息
-(BOOL) SaveAndLoadServerList:(BOOL) bSave;
//系统初始化数据
-(void) SystemDefault;

//设置服务器地址和端口  服务器类型 地址  端口
- (void)SetServerInfo:(int)nSession address:(NSString*)strAdd port:(int)nPort;
//设置服务器地址 服务器类型  地址
- (void)SetAddressInfo:(int)nSession address:(NSString*)strAdd;
//获取服务器地址  服务器类型
- (NSString*)GetAddressInfo:(int)nSession;
//设置服务器端口 服务器类型 端口
- (void)SetPortInfo:(int)nSession port:(int)nPort;
//获取服务器端口
- (int)GetPortInfo:(int)nSession;

// 设置为下一个服务器地址 服务器类型  TRUE 随机 FALSE 取下一个
- (BOOL)GetNextAddress:(int)nSession bRand_:(BOOL)bRand;
//设置统一的服务器地址
- (void)SetAllAddress:(NSString*)strAdd;
//设置统一的端口
- (void)SetAllPort:(int)nPort;

//添加服务器地址
- (void)AddAddressInfo:(int)nSession address:(NSString*)strAdd;
//删除服务器地址
- (BOOL)RemoveAddressInfo:(int)nSession address:(NSString*)strAdd;
//服务器列表数
- (NSUInteger)AddressInfoCount:(int)nSession;

// 设置交易地址
-(void) SetJYAddress:(NSString*)strJyAdd;
//获取当前交易地址
-(NSString*) GetJYAddress;
// 设置行情地址
-(void) SetHQAddress:(NSString*)strHQAdd;
//获取当前行情地址
-(NSString*) GetHQAddress;
//设置认证地址
-(void) SetRZAddress:(NSString*)strRZAdd;
//设置资讯地址
-(void) SetZXAddress:(NSString*)strZXAdd;
//设置均衡地址
-(void) SetJHAddress:(NSString*)strJHAdd;
//设置开户地址
-(void) SetKHAddress:(NSString*)strKHAdd;

//获取开户地址
-(NSString*) GetKHAddress;
//获取认证地址
-(NSString*) GetRZAddress;
//获取当前均衡地址
-(NSString*) GetJHAddress;
//获取资讯地址
-(NSString*) GetZXAddress;
// 设置交易端口
-(void) SetJYPort:(int)nPort;
//获取当前交易端口
-(int) GetJyPort;
// 设置行情端口
-(void) SetHQPort:(int)nPort;
//获取当前行情端口
-(int) GetHQPort;
//设置认证端口
-(void) SetRZPort:(int)nPort;
//获取认证端口
-(int) GetRZPort;
//获取当前均衡端口
-(int) GetJHPort;
//获取资讯端口
-(int) GetZXPort;
-(void)SetZXPort:(int)nPort;
//获取开户端口
-(int) GetKHPort;
//设置开户端口
-(void)SetKHPort:(int)nPort;
//将服务器地址添加服务器列表
-(void) AddAddress:(NSString*)strAdd;
//删除服务器地址
-(BOOL) RemoveAddress:(NSString*)strAdd;

//服务器列表数
-(NSUInteger)GetListCount;

//添加端口
- (void)AddPort:(int)strPort;
//删除端口
- (BOOL)RemovePort:(int)strPort;
//端口列表数
-(NSUInteger)GetPortCount;

-(void) SetServerList:(NSString*)strServerList;
-(void) SetLocList:(NSString*)strLocList;
-(void) SetServerList:(NSString *)strServerList LocList:(NSString*)strLocList;
//设置均衡服务器列表
-(void)SetTztJHServer:(NSString*)tztJhServer;

+(void) SetJHSysDate:(NSInteger)nSysDate;
+(NSInteger) GetJHSysDate;
-(BOOL) DealServerList:(NSString*)strServerList Aydict:(NSMutableDictionary*)aydict;

//服务器设置确认
- (BOOL)SetServerOK;
//服务器设置确认 服务器类型
- (BOOL)SetServerOK:(int)ntranstype;
//调用均衡功能
- (void)onSendJHAction:(void (^)(void))completion;
@end


