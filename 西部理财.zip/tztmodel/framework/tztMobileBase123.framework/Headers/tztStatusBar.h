//
//  tztStatusBar.h
//  tztbase
//
//  Created by King on 14-3-7.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>

@class tztStatusBar;

@protocol tztStatusBarDelegate <NSObject>
@optional
-(void)tztStatusBarClicked:(tztStatusBar*)statusBar;
@end

@interface tztStatusBar : UIView<tztStatusBarDelegate>
@property(nonatomic, retain)NSDictionary*       tztUserInfo;
+(void)tztShowMessageInStatusBar:(NSString*)nsString    //显示内容
                        bgColor_:(UIColor*)bgColor      //背景色
                       txtColor_:(UIColor*)txtColor     //文本色
                       fTimeOut_:(CGFloat)fTime         //显示时间
                       delegate_:(id)delegate;          //回调处理使用

+(void)tztShowMessageInStatusBar:(NSString *)nsString
                        bgColor_:(UIColor *)bgColor
                       txtColor_:(UIColor *)txtColor
                       fTimeOut_:(CGFloat)fTime
                       delegate_:(id)delegate
                      nPosition_:(int)nPosition;//增加位置 default 0-顶部状态栏 1-底部显示（推送消息显示）

+(void)tztShowMessageInStatus:(NSString*)nsStatus;

+(void)tztShowPushInfoInStatusBar:(NSDictionary *)userInfo bgColor_:(UIColor *)bgColor txtColor_:(UIColor *)txtColor fTimeOut_:(CGFloat)fTime delegate_:(id)delegate nPosition_:(int)nPosition;
@end
