/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        tztHTTPWebView.h
 * 文件标识:        webview基类
 * 摘要说明:        只处理webview加载、显示逻辑，具体业务请各自派生处理。
 *
 * 当前版本:        2.0
 * 作    者:       yangdl
 * 更新日期:
 * 整理修改:
 *
 ***************************************************************/

typedef NS_ENUM(NSInteger, tztHTTPWebViewLoadType) {
    tztHTTPWebViewTrue = 1,  //Load True
    tztHTTPWebViewFalse = 1 << 1, //Load FALSE
    tztHTTPWebViewContinue = 1 << 2, //继续加载
    tztHTTPWebViewBreak = 1 << 3, //中断加载
};

#import <UIKit/UIKit.h>
@class tztUIWebView;

@protocol tztUIWebViewDelegate <NSObject>
@optional
- (void) webView:(tztUIWebView*)webView didReceive:(int)nReces totals:(int)nTotals;
@end

@interface tztUIWebView: UIWebView
{
    id<tztUIWebViewDelegate> _tztdelegate;
    int _ntotals;
    int _nreces;
}
@property (nonatomic, assign) int ntotals;
@property (nonatomic, assign) int nreces;
@property (nonatomic,assign) id<tztUIWebViewDelegate> tztdelegate;
@end

@class UIProgressView;

@interface tztUIWebViewProgressBar : UIProgressView {
	UIColor *_tintColor;
    NSTimer *_animationTimer;
}
- (tztUIWebViewProgressBar *)initWithFrame:(CGRect)frame;
- (void)setProgress:(CGFloat)value animated:(BOOL)animated;
@end

@protocol tztHTTPWebViewDelegate;
@protocol takingPhotoDelegate;
@protocol BaseViewControllerDelegate;
@protocol CreateP10;

@interface tztHTTPWebView : UIView <UIWebViewDelegate,tztUIWebViewDelegate>
{
    id   _tztDelegate;
    BOOL _bGoBack;
    NSString* _strJsGoBack;
    BOOL _bounces;//
    BOOL _bnewviews; //
    BOOL _bblackground;//
    UIColor *_clBackground;
    CGFloat _fAlpha;
    BOOL _bNotDelete;
    BOOL _bScalesPageToFit;
}
@property(nonatomic)  BOOL   bounces; 
@property(nonatomic)  BOOL   bnewviews;
@property(nonatomic)  BOOL   bblackground;
@property(nonatomic,retain)  NSString   *strJsGoBack;
@property(nonatomic,retain)  UIColor    *clBackground;
@property (nonatomic) CGFloat   fAlpha;
@property(nonatomic,assign)id<tztHTTPWebViewDelegate>tztDelegate;
@property(nonatomic)  BOOL   bNotDelete;
@property(nonatomic)  BOOL   bScalesPageToFit;
//设置URL
-(void)setWebURL:(NSString*)strURL;
//设置本地URL
-(void)setLocalWebURL:(NSString*)strURL;
//设置HTML
-(void)LoadHtmlData:(NSString*)strHTML;
//返回前一页
-(BOOL)OnReturnBack;
//页面可返回
-(BOOL)canReturnBack;
//获取网页标题
-(NSString*)getWebTitle;
//初始化页面数据
- (void)initdata;
//关闭当前页面
-(void)closeCurHTTPWebView;
//关闭所有页面
-(void)closeAllHTTPWebView;
//关闭指定webview以外的其他所有view， 若返回TRUE，表示指定的webview存在，返回false，则是全部关闭了
-(BOOL)closeHttpWebViewWithOut:(UIWebView*)webView;
//回到第一个webview，并关闭后面打开的所有webview
-(void)returnRootWebView;
-(void)returnRootWebViewEx:(BOOL)bFlag;
//获取最新显示的页面的URL
-(NSString*)getCurWebViewUrl;
//获取当前的webview
-(UIWebView*)getCurWebView;

//返回指定url对应webview，不存在，返回NULL
-(UIWebView*)webViewWithURL:(NSString*)nsURL;
//
-(void)scrollToTop;
//
-(BOOL)IsHaveWebView;
//刷新制定位置web，nIndex==-1,刷新全部
-(void)RefreshWebView:(int)nIndex;

-(void)stopLoad;
//处理webview url
-(tztHTTPWebViewLoadType)ontztWebURL:(UIWebView*)tztWebView strURL:(NSString *)strUrl WithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
//执行页面js
-(void)tztStringByEvaluatingJavaScriptFromString:(NSString*)str;
//根据状态 设置页面URL
- (void)tztSetNextUrl:(BOOL)bsucess;
//
-(NSMutableArray*)GetAyWebViews;
@end

@protocol tztHTTPWebViewDelegate <NSObject>
@optional
-(BOOL)tztWebViewIsRoot:(tztHTTPWebView*)webView;
-(BOOL)tztWebViewCanGoBack:(tztHTTPWebView*)webView;
-(void)tztWebView:(tztHTTPWebView *)webView withTitle:(NSString *)title;
-(void)tztWebView:(tztHTTPWebView *)webView addSubView:(UIWebView *)subview;//新增webview
-(void)tztWebViewDidFinishLoad:(tztHTTPWebView *)webView fail:(BOOL)bfail;//页面加载完毕 成功或失败
//处理webview url
-(tztHTTPWebViewLoadType)tztWebView:(tztHTTPWebView *)webView withMsg:(NSString *)msg WithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType;
//拍照
-(void)showCamera:(NSString*)strUrl;
@end
