//
//  tztappdefine.h
//  tztbase
//
//  Created by yangares on 14-9-7.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <Foundation/Foundation.h>
#define NewObject(x)        [[x alloc]init]
#define NewObjectAutoD(x)   [[[x alloc]init]autorelease]

#define DelObject(x)        {if (x) {[x release];x=nil;}}
#define NilObject(x)        {if (x) {x=nil;}}
#define Obj_RELEASE(x)      [x release]
#define Obj_AUTORELEASE(x)  [x autorelease]

#define	BegAutoReleaseObj()	NSAutoreleasePool* autoPool = NewObject(NSAutoreleasePool)
#define	EndAutoReleaseObj()	DelObject(autoPool)

#if TARGET_OS_IPHONE
//是IPAD
#define IS_TZTIPAD  (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad)
//是模拟器
#define IS_TZTSimulator TARGET_IPHONE_SIMULATOR
//IOS版本号
#define IS_TZTIOS(x) ([[UIDevice currentDevice].systemVersion intValue] >= x)
//是IPHONE5分辨率
#define IS_TZTIphone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)
#else
#define IS_TZTIPAD NO
#define IS_TZTSimulator NO
#define IS_TZTIOS(x) NO
#define IS_TZTIphone5 NO
#endif

//服务器配置文件名
#define tztappstringserver @"tztappserver"
#define tztappstringssys @"tztappsys"
#define tztappstringshttp @"tztapphttp"

//通讯事务类别 
typedef enum tztSessionType
{
    tztSession_ExchangeHQ = 1 <<  0,        // mob行情服务器
	tztSession_Exchange = 1 << 1,           // 交易
    tztSession_ExchangeZX = 1 <<  2,        // 资讯
	tztSession_ExchangeJH = 1 <<  3,        // 均衡
    tztSession_ExchangeRZ = 1 <<  4,        // 认证
    tztSession_ExchangeKH = 1 <<  5,        // 开户
}tztSessionType;

#define tztSession_ALL  (tztSession_ExchangeHQ|tztSession_Exchange|tztSession_ExchangeRZ|tztSession_ExchangeJH|tztSession_ExchangeZX|tztSession_ExchangeKH)

#define tztSessionType_IS(x,y) ((x & y) == y)

FOUNDATION_EXPORT int tztSessionMaxIndex();
FOUNDATION_EXPORT int tztIndexOfSession(int nSession);
FOUNDATION_EXPORT int tztSessionOfIndex(int nIndex);
FOUNDATION_EXPORT NSString* tztSessionKey(int nSession);

FOUNDATION_EXPORT void tztUpdateBundle(void (^block)(NSInteger,NSInteger));
BOOL onDownLoadZipFile(NSString* strZip ,NSString* strPath);