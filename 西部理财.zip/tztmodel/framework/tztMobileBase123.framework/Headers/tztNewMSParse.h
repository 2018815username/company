/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：tztNewMSParse.h
 * 文件标识：
 * 摘    要：数据处理
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 *
 *******************************************************************************/

#import <Foundation/Foundation.h>

@interface tztNewMSParse : NSObject
{
	NSMutableDictionary		*_dictvalue;			//所有数据    
    NSDictionary            *_paramvalue;
}
@property(nonatomic,retain) NSMutableDictionary     *dictvalue;
@property(nonatomic,retain) NSDictionary            *paramvalue;

//设置字典内容
- (void)setActionAns2011:(NSDictionary*)paramDict withData:(NSData*)recvdata;
- (void)setActionAns2013:(NSData*)recvdata;
//直接获取二进制数据
- (NSData*)GetNSData:(NSString*)strKey;
//通过base64解码获取数据
- (NSData*)GetNSDataBase64:(NSString*)strKey;
//通过字段名称获取相应的值
- (NSString *)GetValueData:(NSString*)strKey;
//通过字段名称获取相应的值
- (int)GetIntByName:(NSString*)strKey;
//通过字段名称获取相应的值
- (NSString*)GetByName:(NSString*)strKey;
//通过字段名称获取相应的值(中文)
- (NSString*)GetByNameUnicode:(NSString*)strKey;
- (NSString*)GetByNameGBK:(NSString*)strKey;
- (NSArray*)GetArrayByName:(NSString *)strKey;

//获取请求号Reqno
- (int)GetReqno;
- (NSString*)GetToken;
//获取错误号ErrorNo
- (int)GetErrorNo;
//获取错误信息
- (NSString *)GetErrorMessage;
//获取功能号
- (int)GetAction;
//判断是否是某一功能号
- (int)IsAction:(NSString*)strAction;
//是交易登录
- (int)IsAllJyLogin;
//判断是否是数据当前界面
- (int)IsIphoneKey:(long)nKey reqno:(int)nReqno;

- (NSDictionary*)GetJsonData;

//上传日志信息
+(void)UpLoadLogInfo:(NSString*)strLog;
- (BOOL)WriteParse:(NSString *)strPath;
- (void)ReadParse:(NSString *)strPath;
@end
