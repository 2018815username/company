/*******************************************************************************
 * Copyright (c)2012, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称：NSObject+TZTPrivate.h
 * 文件标识：
 * 摘    要：自定义拓展函数
 *
 * 当前版本：
 * 作    者：yangdl
 * 完成日期：2012.12.12
 *
 * 备    注：
 *
 * 修改记录：
 * 
 *******************************************************************************/

#import <Foundation/Foundation.h>
#if TARGET_OS_IPHONE
#import "TZTUIMessageBox.h"
#endif

#define tztLogMobile @"com.tzt.logmobile"
#define tztLogPass @"com.tzt.logpass"

#define tztUniqueID  @"com.tzt.uniqueid"

@interface NSObject (tztPrivate)
- (id)tztperformSelector:(NSString *)aSelectorName;
- (id)tztperformSelector:(NSString *)aSelectorName withObject:(id)object;
- (id)tztperformSelector:(NSString *)aSelectorName withObject:(id)object1 withObject:(id)object2;
@end

@interface NSData (tztPrivate)
+ (NSData *)tztencodeddata:(NSData *)data;
+ (NSData *)tztdecodeddata:(const char *)data length:(NSUInteger)nLength;
@end

@interface NSMutableDictionary (tztPrivate)
- (void)removeTztObjectForKey:(id)aKey;
- (void)setObject:(id)anObject forUpperKey:(id)aKey;
- (void)setValue:(id)anObject forUpperKey:(id)aKey;
- (void)setTztValue:(id)value forKey:(NSString *)key;
- (void)setTztObject:(id)anObject forKey:(id)aKey;
- (void)settztProperty:(NSString*)strproperty;
- (NSString*)gettztProperty;
@end

@interface NSDictionary (tztPrivate)
- (id)tztObjectForKey:(id)aKey;
- (id)tztValueForKey:(NSString *)key;
- (id)tztValuedefault:(NSString*)value forKey:(NSString *)key;
@end

@interface NSMutableArray(tztPrivate)
- (void)appendstrArray:(NSArray *)otherArray;
- (void)moveObjectFromIndex:(NSUInteger)fromIndex toIndex:(NSUInteger)toIndex;
@end


@interface NSDate(tztPrivate)
+ (NSTimeInterval)timeIntervalSinceToday;
@end

#if TARGET_OS_IPHONE
extern NSMutableArray *g_ayPushedViewController;

@interface tztUINavigationController : UINavigationController
{
    int              _nPageID;
    BOOL            transiting;
}
@property int nPageID;
- (id)initWithRootViewController:(UIViewController *)rootViewController;
- (NSArray*)popToRootViewControllerAnimated:(BOOL)animated;
- (UIViewController*)popViewControllerAnimated:(BOOL)animated;
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated;
@end

#define tztVcShowTypeRoot (-3) //是Root
#define tztVcShowTypeSame (-2) //所有都相同
#define tztVcShowTypeDif  (-1) //所有都不相同
@interface UIViewController(tztPrivate)
- (void)setVcShowType:(NSString*)nShowType;
- (void)setVcShowKind:(int)nShowKind;
- (NSString*)getVcShowType;
- (int)getVcShowKind;
- (BOOL)isKindofVcKind:(int)nVcKind VcType:(NSString*)nVcType;
- (int)getTztTradeLoginSign;
- (void)setTztTradeLoginSign:(int)nNeedLogin;
-(void)SetToolbarHiddens:(BOOL)bHide;
-(void)SetHidesBottomBarWhenPushed:(BOOL)bHiden;
@end


@interface UIColor (tztPrivate)
//数值转颜色 
+ (UIColor *)colorWithChar:(char)RGB;
//数值转颜色 如 0xFFFFFF
+ (UIColor *)colorWithRGBULong:(unsigned long)RGB;
//字符串转颜色 如"255,255,255"
+ (UIColor *)colorXORWithTztRGBStr:(NSString *)RGB;
+ (UIColor *)colorWithTztRGBStr:(NSString *)RGB;
- (BOOL)getTztRed:(CGFloat *)red green:(CGFloat *)green blue:(CGFloat *)blue alpha:(CGFloat *)alpha;
+ (UIColor *)colorXORUIColor:(UIColor*)color;
//颜色值转数值 
- (unsigned long)colorToRGBULong;
//颜色值转字符串
- (NSString*)colorToRGBStr;
@end

@interface UIImage (tztPrivate)
+ (UIImage *)imageTztNamed:(NSString *)name withAdd:(NSString*)strAdd;
+ (UIImage *)imageTztNamed:(NSString *)name;
+ (UIImage *)tztCreateImageWithColor:(UIColor *)color;
@end

@interface UIView (tztPrivate)

- (void)setTztIndex:(int)nIndex;
- (void)setTztName:(NSString*)nsName;

-(NSString*)getTztName;
-(int)getTztIndex;

- (CGFloat)gettztwindowy:(UIView*)topView;
- (CGFloat)gettztwindowx:(UIView*)topView;


-(TZTUIMessageBox*) showMessageBox:(NSString *)nsString nType_:(int)nType delegate_:(id)delegate;
-(TZTUIMessageBox*) showMessageBox:(NSString *)nsString nType_:(int)nType nTag_:(int)nTag;
-(TZTUIMessageBox*) showMessageBox:(NSString*)nsString nType_:(int)nType nTag_:(int)nTag delegate_:(id)delegate;
-(TZTUIMessageBox*) showMessageBox:(NSString *)nsString nType_:(int)nType nTag_:(int)nTag delegate_:(id)delegate withTitle_:(NSString*)nsTitle;
-(TZTUIMessageBox*) showMessageBox:(NSString *)nsString nType_:(int)nType nTag_:(int)nTag delegate_:(id)delegate withTitle_:(NSString*)nsTitle nsOK_:(NSString*)nsOK nsCancel_:(NSString*)nsCacel;
//增加是否采用动画效果，默认使用
-(TZTUIMessageBox*) showMessageBox:(NSString *)nsString nType_:(int)nType nTag_:(int)nTag delegate_:(id)delegate withTitle_:(NSString*)nsTitle nsOK_:(NSString*)nsOK nsCancel_:(NSString*)nsCacel UseAnimated:(BOOL)bUseAnimated;

- (void)tztShowPhoneList:(NSString*)telphone;
//
//- (void)addToolBar:(UIView *)pView;
//- (NSMutableArray*)GetAyToolBar;
//- (void)removeAllToolBar;
@end

FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBox(NSString* strMsg);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageTitle(NSString* strMsg,NSString* strTitle);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlock(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType,void (^block)(NSInteger));
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlockWithDelegate(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType, id delegate, void (^block)(NSInteger));
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlockAndClose(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType, id delegate, BOOL bHasClose, void (^block)(NSInteger));

//增加动画弹出效果
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBoxAnimated(NSString* strMsg, BOOL bUseAnimated);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageTitleAnimated(NSString* strMsg,NSString* strTitle, BOOL bUseAnimated);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlockAnimated(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType,void (^block)(NSInteger), BOOL bUseAnimated);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlockWithDelegateAnimated(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType, id delegate, void (^block)(NSInteger), BOOL bUseAnimated);
FOUNDATION_EXPORT TZTUIMessageBox* tztAfxMessageBlockAndCloseAnimated(NSString* strMsg,NSString* strTitle, NSArray* ayBtn, int nType, id delegate, BOOL bHasClose, void (^block)(NSInteger), BOOL bUseAnimated);


@interface UIButton (tztPrivate)
//设置按钮标题
- (void)setTztTitle:(NSString*)title;

- (void)setTztTitleEx:(NSString*)title;

- (void)setAllStateTitle:(NSString *)title;
//设置按钮标题颜色
- (void)setTztTitleColor:(UIColor *)color;
- (void)setAllStateTitleColor:(UIColor *)color;
//设置按钮底图
- (void)setTztBackgroundImage:(UIImage *)image;
//设置按钮图片
- (void)setTztImage:(UIImage *)image;
@end

@interface UILabel(tztPrivate)
- (void)alignTop;
- (void)alignBottom;
@end

@interface UIImageView (tztPrivate)
//下载图片
- (void)loadImageFromURL:(NSString*)strURL completion:(void (^)(void))completion;
//不带crc
- (void)setImageFromUrlEx:(NSString*)urlString atFile:(NSString*)file;
- (void)setImageFromUrlEx:(NSString*)urlString atFile:(NSString*)file completion:(void(^)(void))completion;
//带crc
- (void)setImageFromUrl:(NSString*)urlString atFile:(NSString*)file;    
- (void)setImageFromUrl:(NSString*)urlString atFile:(NSString*)file
             completion:(void (^)(void))completion;
- (void)setImageFromUrlForHT:(NSString*)urlString atFile:(NSString*)file
             completion:(void (^)(void))completion;
@end

@interface tztKeyChain : NSObject
+ (NSMutableDictionary *)getKeychainQuery:(NSString *)service;
+ (void)save:(NSString *)service data:(id)data;
+ (void)saveEx:(NSString*)service data:(id)data bFile_:(BOOL)bFile;
+ (id)load:(NSString *)service;
+ (id)loadEx:(NSString *)service bFile_:(BOOL)bFile;
+ (void)delete:(NSString *)service;
@end

@interface UIDevice(tztPrivate)
+(NSMutableDictionary*)tztDeviceInfo;
@end

//#ifndef __IPHONE_7_0
@interface UIWebView (tztPrivate)<UIAlertViewDelegate>
- (void)webView:(UIWebView *)sender runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame;
- (BOOL)webView:(UIWebView *)sender runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(id)frame;
@end
//#endif

#endif
//消息传递类
@interface TZTUIMessage : NSObject
{
    NSUInteger    m_nMsgType;
    NSUInteger    m_wParam;
    NSUInteger    m_lParam;
    //保留字段
    NSUInteger    m_lRev1;
    NSUInteger    m_lRev2;
}
@property    NSUInteger    m_nMsgType;
@property    NSUInteger    m_wParam;
@property    NSUInteger    m_lParam;
@property    NSUInteger    m_lRev1;
@property    NSUInteger    m_lRev2;
@end

