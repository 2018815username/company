/*
 
 显示帮助引导图片
 
 */

#import <UIKit/UIKit.h>

@interface tztUIHelperImageView : UIView
+(void)tztShowHelperView:(NSString*)nsImageName forClass_:(NSString*)nsClassName;
+(void)tztHelperViewDismiss;
@end
