//
//  tztCallAppDelegate.h
//  tztAppCallModel
//
//  Created by yangares on 14-11-7.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface tztCallAppDelegate : UIResponder <UIApplicationDelegate, UITabBarControllerDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UITabBarController *tabBarController;

@end
