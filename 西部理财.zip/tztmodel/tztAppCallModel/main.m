//
//  main.m
//  tztAppCallModel
//
//  Created by yangares on 14-11-7.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "tztCallAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([tztCallAppDelegate class]));
    }
}
