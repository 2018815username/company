//
//  tztFirstViewController.m
//  tztAppCallModel
//
//  Created by yangares on 14-11-7.
//  Copyright (c) 2014年 yangares. All rights reserved.
//

#import "tztFirstViewController.h"
#import <tztWealthFramework/tztAppInit.h>

@interface tztFirstViewController ()

@end

@implementation tztFirstViewController
@synthesize window;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"First", @"First");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    UIButton* btnCall = [UIButton buttonWithType:(UIButtonTypeRoundedRect)];
    [btnCall setFrame:CGRectMake(100, 100, 120, 35)];
    [btnCall setTztTitleEx:@"华鑫商城"];
    [self.view addSubview:btnCall];
    [btnCall addTarget:self action:@selector(onClickCall:) forControlEvents:UIControlEventTouchUpInside];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)onClickCall:(id)sender
{
    //UIWindow* _window = [UIApplication sharedApplication];
    UINavigationController* pNav = self.navigationController;
    NSMutableDictionary* tztCallSDKOptions = [NSMutableDictionary dictionaryWithObjectsAndKeys:self.window,@"UIWindow",pNav,@"UINavigationController",self,@"calldelegate",@"56809019",@"JYAccount",@"交易密码",@"jypassword",@"通讯密码",@"Commpassword", nil];
    NSDictionary* launchOptions = [NSDictionary dictionaryWithObjectsAndKeys:tztCallSDKOptions,@"tztCallSDKOptions", nil];
    [[tztAppInit sharedtztAppInit] tztInitApp:launchOptions];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
