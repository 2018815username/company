/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        tztSysLoginView
 * 文件标识:
 * 摘要说明:        系统登录view
 *
 * 当前版本:        1.0
 * 作    者:       Yinjp
 * 更新日期:        2014-01-28
 * 整理修改:
 *
 ***************************************************************/

#import "tztSysLoginView.h"
#import "tztAppInit.h"

@interface tztSysLoginView ()<UITextFieldDelegate,tztHTTPSendDataDelegate>
{
    UIView      *_pHeaderView;
    UILabel     *_pHeaderLabel;
    UIImageView *_pHeaderImageView;
    UIButton    *_pBtnRegist;
    UIImageView *_pImageView;
    UInt16      _ntztReqno;
    BOOL _bAutoLogin;
}

@end

@implementation tztSysLoginView
@synthesize tztDelegate = _tztDelegate;
@synthesize pBackView = _pBackView;
@synthesize pMobileText = _pMobileText;
@synthesize pPasswordText = _pPasswordText;
@synthesize pBtnForget = _pBtnForget;
@synthesize pBtnLogin = _pBtnLogin;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _ntztReqno = 0;
        _bAutoLogin = FALSE;
    }
    return self;
}

-(void)setFrame:(CGRect)frame
{
    if (CGRectIsEmpty(frame) || CGRectIsNull(frame))
        return;
    
    [super setFrame:frame];
    //读取用户信息
    CGRect rcFrame = self.bounds;
    rcFrame.origin.x += 30;
    rcFrame.size.width -= 60;
    rcFrame.origin.y += 70;
    
    CGRect rcMobile = rcFrame;
    rcMobile.size.height = 40;
    if (_pMobileText == NULL)
    {
        _pMobileText = [[UITextField alloc] initWithFrame:rcMobile];
        _pMobileText.delegate = self;
        _pMobileText.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pMobileText.leftViewMode = UITextFieldViewModeAlways;
        _pMobileText.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pMobileText.rightViewMode = UITextFieldViewModeAlways;
        _pMobileText.clearButtonMode = UITextFieldViewModeWhileEditing;
        _pMobileText.background = [UIImage imageTztNamed:@"tztTradeUserTextBG@2x"];
        _pMobileText.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _pMobileText.placeholder = @"请输入手机号码";
        _pMobileText.keyboardType = UIKeyboardTypePhonePad;
        [self addSubview:_pMobileText];
        [_pMobileText release];
    }
    else
    {
        _pMobileText.frame = rcMobile;
    }
    
    rcMobile.origin.y += rcMobile.size.height + 15;

    if (_pPasswordText == NULL)
    {
        _pPasswordText = [[UITextField alloc] initWithFrame:rcMobile];
        _pPasswordText.leftView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pPasswordText.leftViewMode = UITextFieldViewModeAlways;
        _pPasswordText.rightView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 20, 40)] autorelease];
        _pPasswordText.rightViewMode = UITextFieldViewModeAlways;
        _pPasswordText.clearButtonMode = UITextFieldViewModeWhileEditing;
        _pPasswordText.background = [UIImage imageTztNamed:@"tztTradePassTextBG@2x"];
        _pPasswordText.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
        _pPasswordText.keyboardType = UIKeyboardTypeNumbersAndPunctuation;
        _pPasswordText.secureTextEntry = YES;
        _pPasswordText.placeholder = @"请输入验证码";
        [self addSubview:_pPasswordText];
        [_pPasswordText release];
    }
    else
    {
        _pPasswordText.frame = rcMobile;
    }
    
    
    CGRect rcForget = rcMobile;
    rcForget.origin.y += rcMobile.size.height + 15;
    rcForget.size.width = (rcMobile.size.width - 40) / 2;
    
    UIImage *pImage = [UIImage imageTztNamed:@"tztMsgBtnCancel@2x"];
    if (_pBtnForget == NULL)
    {
        _pBtnForget = [UIButton buttonWithType:UIButtonTypeCustom];
        _pBtnForget.frame = rcForget;
        [_pBtnForget setBackgroundImage:pImage forState:UIControlStateNormal];
        [_pBtnForget addTarget:self action:@selector(OnForgetPass:) forControlEvents:UIControlEventTouchUpInside];
        [_pBtnForget setTztTitle:@"用户注册"];
        [_pBtnForget setTztTitleColor:[UIColor blackColor]];
        [self addSubview:_pBtnForget];
    }
    else
    {
        _pBtnForget.frame = rcForget;
    }
    
    CGRect rcLogin = rcForget;
    rcLogin.origin.x += (rcMobile.size.width - 40) / 2 + 40;
    if (_pBtnLogin == NULL)
    {
        _pBtnLogin = [UIButton buttonWithType:UIButtonTypeCustom];
        _pBtnLogin.frame = rcLogin;
        [_pBtnLogin addTarget:self
                       action:@selector(onSendLogin)
             forControlEvents:UIControlEventTouchUpInside];
        [_pBtnLogin setBackgroundImage:[UIImage imageTztNamed:@"tztMsgBtnOk@2x"] forState:UIControlStateNormal];
        [_pBtnLogin setTztTitle:@"立即登录"];
        [self addSubview:_pBtnLogin];
    }
    else
    {
        _pBtnLogin.frame = rcLogin;
    }
    
    
    CGRect rcBack = self.bounds;
    rcBack.origin.y += 20;
    rcBack.origin.x += 20;
    rcBack.size.width -= 40;
    rcBack.size.height = rcLogin.origin.y + rcLogin.size.height + 80 - rcFrame.origin.y;
    
    if (_pBackView == NULL)
    {
        _pBackView = [[UIView alloc] initWithFrame:rcBack];
        _pBackView.backgroundColor = [UIColor clearColor];
        _pBackView.layer.borderWidth = 1.0f;
        _pBackView.layer.borderColor = [UIColor colorWithTztRGBStr:@"227,227,227"].CGColor;
        [self addSubview:_pBackView];
        [self sendSubviewToBack:_pBackView];
        [_pBackView release];
    }
    else
    {
        _pBackView.frame = rcBack;
    }
    
    CGRect rc = rcBack;
    rc.size.height = 3;
    if (_pHeaderView == NULL)
    {
        _pHeaderView = [[UIView alloc] initWithFrame:rc];
        _pHeaderView.backgroundColor = [UIColor colorWithTztRGBStr:@"254,110,93"];
        [self addSubview:_pHeaderView];
        [_pHeaderView release];
    }
    else
    {
        _pHeaderView.frame = rc;
    }
    
    CGRect rcImageView = rcBack;
    rcImageView.origin.x += 5;
    rcImageView.origin.y += 5;
    rcImageView.size = CGSizeMake(40, 40);
    
    UIImage *pImage1 = [UIImage imageTztNamed:@"tztSysLoginIcon@2x"];
    if (pImage1 && pImage1.size.width > 0 && pImage1.size.height > 0)
    {
        rcImageView.origin.x += (rcImageView.size.width - pImage1.size.width) / 2;
        rcImageView.origin.y += (rcImageView.size.height - pImage1.size.height) / 2;
        rcImageView.size = pImage1.size;
    }
    
    if (_pHeaderImageView == NULL)
    {
        _pHeaderImageView = [[UIImageView alloc] initWithFrame:rcImageView];
        [_pHeaderImageView setImage:pImage1];
        [self addSubview:_pHeaderImageView];
        [_pHeaderImageView release];
    }
    else
    {
        _pHeaderImageView.frame = rcImageView;
    }
    
    CGRect rcLabel = rcBack;
    rcLabel.origin.x = rcImageView.origin.x + rcImageView.size.width + 10;
    rcLabel.size.width = (rcBack.size.width) / 2 - rcLabel.origin.x;
    rcLabel.origin.y = rcImageView.origin.y;
    rcLabel.size.height = rcImageView.size.height;
    if (_pHeaderLabel == NULL)
    {
        _pHeaderLabel = [[UILabel alloc] initWithFrame:rcLabel];
        _pHeaderLabel.text = @"用户登录";
        _pHeaderLabel.adjustsFontSizeToFitWidth = YES;
        _pHeaderLabel.textColor = [UIColor colorWithTztRGBStr:@"254,110,93"];
        [self addSubview:_pHeaderLabel];
        [_pHeaderLabel release];
    }
    else
    {
        _pHeaderLabel.frame = rcLabel;
    }
    
    CGRect rcRegist = rcLabel;
    rcRegist.size.width = 100;
    rcRegist.origin.x = rcBack.size.width - rcRegist.size.width;
    
    UIImage *pImageRegist = [UIImage imageTztNamed:@"tztSysRegist@2x"];
    if (pImageRegist && pImageRegist.size.width > 0 && pImageRegist.size.height > 0)
    {
        rcRegist.origin.x = rcBack.size.width - pImageRegist.size.width;
        rcRegist.origin.y += (rcRegist.size.height-pImageRegist.size.height)/2;
        rcRegist.size = pImageRegist.size;
    }
    
    if (_pImageView == NULL)
    {
        _pImageView = [[UIImageView alloc] initWithFrame:self.bounds];
        [_pImageView setImage:[UIImage imageTztNamed:tztScreen_Image(@"Default.png")]];
        [self addSubview:_pImageView];
        _pImageView.hidden = NO;
    }
    else
    {
        _pImageView.frame = self.bounds;
    }
    [self bringSubviewToFront:_pImageView];
    _pImageView.hidden = YES;
    
    NSString* strMobileCode = [tztKeyChain load:tztLogMobile];
    if(strMobileCode && strMobileCode.length > 0)
        [_pMobileText setText:strMobileCode];
}

-(void)OnForgetPass:(id)sender
{
    return;
}

-(void)setControlEnable:(BOOL)bEnable
{
    _pMobileText.enabled = bEnable;
    _pBtnLogin.enabled = bEnable;
    _pPasswordText.enabled = bEnable;
    if(_pImageView)
    {
        _pImageView.userInteractionEnabled = !bEnable;
        if(_bAutoLogin){
            _pImageView.hidden = NO;
        }else{
            _pImageView.hidden = YES;
        }
    }
}

-(void)OnAutoLogin
{
    NSString* strMobileCode = [tztKeyChain load:tztLogMobile];
    if(strMobileCode && strMobileCode.length > 0)
        [_pMobileText setText:strMobileCode];
    
    NSString *strPass = [tztKeyChain load:tztLogPass];
    if(strMobileCode && strMobileCode.length > 0 && strPass && strPass.length > 0){
        [_pPasswordText setText:strPass];
        _pImageView.hidden = NO;
        _bAutoLogin = TRUE;
        [self onSendLogin];
    }
    
    return;
}

-(void)setMobile:(NSString*)strMobileCode pass:(NSString*)strPass
{
    if(strMobileCode)
        [_pMobileText setText:strMobileCode];
    if(strPass)
        [_pPasswordText setText:strPass];
}

- (void)onSendLogin
{
    [_pMobileText resignFirstResponder];
    [_pPasswordText resignFirstResponder];
    
    NSString *strMobile = _pMobileText.text;
    NSString *strPass = _pPasswordText.text;
    
    if (strMobile == NULL || strMobile.length < 1)
    {
        tztAfxMessageTitle(@"请输入登录账号!", @"登录提示");
        return;
    }
    
    if (strPass == NULL || strPass.length < 1)
    {
        tztAfxMessageTitle(@"请输入登录验证码!", @"登录提示");
        return;
    }
    
    [self setControlEnable:FALSE];
    NSString* strSend = tztAppSysValueWithDefault(@"tztapp_sysloginsend", @"action=40100&login_type=1&MobileCode=($MobileCode)&password=($PassWord)&Version=($UpVersion)");
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($MobileCode)" withString:strMobile];
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($PassWord)" withString:strPass];

    strSend = [strSend stringByReplacingOccurrencesOfString:@"($UpVersion)" withString:(g_nsUpVersion ? g_nsUpVersion : @"")];
    
    strSend = [strSend stringByReplacingOccurrencesOfString:@"($DeviceToken)" withString:(g_nsdeviceToken ? g_nsdeviceToken : @"")];
    
    NSMutableDictionary *sendvalue = [strSend tztNSMutableDictionarySeparatedByString:@"&"];
    
    _ntztReqno++;
    if (_ntztReqno >= UINT16_MAX)
        _ntztReqno = 1;
    NSString *strReqno = tztKeyReqno((long)self, _ntztReqno);
    [sendvalue setTztValue:strReqno forKey:@"Reqno"];
    
    [sendvalue setTztObject:tztAppSysValueWithDefault(@"tztapp_sysloginaction", @"40100") forKey:@"Action"];
    tztHTTPSendData* sendHttpData = [[[tztHTTPSendData alloc] initWithSendData:sendvalue] autorelease];
    sendHttpData.tztdelegate = self;
    [sendHttpData socketSendData:[tztMoblieStockComm getShareInstance:tztSession_ExchangeZX]];
}

-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    [_pMobileText resignFirstResponder];
    [_pPasswordText resignFirstResponder];
}

- (void)onSenddataError:(NSMutableDictionary*)sendData type:(int)nType
{
    _bAutoLogin = FALSE;
    [self setControlEnable:TRUE];
}

- (UInt32)OnCommNotify:(UInt32)wParam lParam_:(UInt32)lParam
{
    tztNewMSParse *pParse = (tztNewMSParse*)wParam;
    if (pParse == NULL)
        return 0;
    NSString* strLogin = tztAppSysValueWithDefault(@"tztapp_sysloginaction", @"40100");
    if([pParse IsAction:strLogin]){
        [self setControlEnable:TRUE];
        NSString* strErrMsg = [pParse GetErrorMessage];
        if ([pParse GetErrorNo] < 0)
        {
            [[tztHTTPData getShareInstance] tztperformSelector:@"clearTztLoginOfType:" withObject:@"0"];
            tztAfxMessageBox(strErrMsg);
            return 0;
        }
        if(strErrMsg && strErrMsg.length > 0){
            tztAfxMessageBox(strErrMsg);
        }
        
        [[tztHTTPData getShareInstance] setlocalValue:@"jyloginflag" withValue:@"1"];
        [[tztHTTPData getShareInstance] setlocalValue:@"mobilecode" withValue:_pMobileText.text];
        [tztKeyChain save:tztLogMobile data: _pMobileText.text];
        [tztKeyChain save:tztLogPass data: _pPasswordText.text];
        [[tztAppInit sharedtztAppInit] tztUniqueidLogin:_pMobileText.text branch:@""];
        if(_tztDelegate){
            [_tztDelegate tztperformSelector:@"OnCloseBack"];
        }
    }
    return 0;
}
@end
