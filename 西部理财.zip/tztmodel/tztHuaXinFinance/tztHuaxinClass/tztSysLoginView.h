/*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        tztSysLoginView
 * 文件标识:
 * 摘要说明:        系统登录view
 *
 * 当前版本:        1.0
 * 作    者:       Yinjp
 * 更新日期:        2014-01-28
 * 整理修改:
 *
 ***************************************************************/

#import <UIKit/UIKit.h>
@interface tztSysLoginView : UIView
{
    
}

@property(nonatomic,retain)id       tztDelegate;
@property(nonatomic,retain)UIView   *pBackView;
@property(nonatomic,retain)UITextField  *pMobileText;
@property(nonatomic,retain)UITextField  *pPasswordText;
@property(nonatomic,retain)UIButton     *pBtnForget;
@property(nonatomic,retain)UIButton     *pBtnLogin;
-(void)OnAutoLogin;
-(void)setMobile:(NSString*)strMobileCode pass:(NSString*)strPass;
@end
