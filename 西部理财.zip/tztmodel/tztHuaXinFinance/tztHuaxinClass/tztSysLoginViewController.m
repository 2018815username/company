 /*************************************************************
 * Copyright (c)2009, 杭州中焯信息技术股份有限公司
 * All rights reserved.
 *
 * 文件名称:        tztSysLoginViewController
 * 文件标识:
 * 摘要说明:
 *
 * 当前版本:        1.0
 * 作    者:       Yinjp
 * 更新日期:        2014-01-28
 * 整理修改:
 *
 ***************************************************************/


#import "tztSysLoginViewController.h"

@interface tztSysLoginViewController ()

@end

@implementation tztSysLoginViewController
@synthesize pSysLoginView = _pSysLoginView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [_pSysLoginView OnAutoLogin];
}

- (void)viewWillAppear:(BOOL)animated
{
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void)LoadLayoutView
{
    [super LoadLayoutView];
    _webView.hidden = YES;
    [self.view setBackgroundColor:[UIColor whiteColor]];
    CGRect rcFrame = self.view.frame;
    CGRect rcLogin = rcFrame;
    rcLogin.origin.y += _tztTitleView.frame.size.height;
    rcLogin.size.height -= _tztTitleView.frame.size.height;
    
    if (_pSysLoginView == NULL)
    {
        _pSysLoginView = [[tztSysLoginView alloc] init];
        _pSysLoginView.tztDelegate = self;
        _pSysLoginView.frame = rcLogin;
        [self.view addSubview:_pSysLoginView];
        [_pSysLoginView release];
    }
    else
        _pSysLoginView.frame = rcLogin;
    [self.view bringSubviewToFront:_tztTitleView];
}
@end
